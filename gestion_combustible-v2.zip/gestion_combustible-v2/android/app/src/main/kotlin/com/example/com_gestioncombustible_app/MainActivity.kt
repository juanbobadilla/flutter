package com.example.com_gestioncombustible_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
