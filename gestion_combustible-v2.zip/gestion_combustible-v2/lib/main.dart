import 'package:com_gestioncombustible_app/app_control_obra/provider/menu1/menu1Provider.dart';
import 'package:com_gestioncombustible_app/app_control_obra/provider/menu2/menu2Provider.dart';
import 'package:com_gestioncombustible_app/app_control_obra/provider/menu3/menu3Provider.dart';
import 'package:com_gestioncombustible_app/app_control_obra/provider/menu4/menu4Provider.dart';
import 'package:com_gestioncombustible_app/app_control_obra/view/menu1.dart';
import 'package:com_gestioncombustible_app/app_control_obra/view/menu3.dart';
import 'package:com_gestioncombustible_app/app_control_obra/view/menu4.dart';
import 'package:com_gestioncombustible_app/app_control_obra/view/tabs/tabs.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/contenedor_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/egreso_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/ingreso_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/listado_historial_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/stock_puntos_tanqueo_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/transferencia_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/views/contenedor_ingreso_egresos_tranferencia/contenedor/contenedor_view.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/views/home/home_view.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/views/listado_historial/listado_historial_view.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/views/login/login_view.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/views/stock_punto_tanqueo/stock_punto_tanqueo_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

void main() {

 /*  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarBrightness: Brightness.light
    )
  ); */

  runApp(const StateMyApp());
}

/* class MyApp extends StatefulWidget{
  const MyApp({super.key});

  @override
  State<MyApp>createState(){
    return StateMyAPP();
  }
} */

class StateMyApp extends StatelessWidget{
  const StateMyApp({super.key});

  @override
  Widget build(BuildContext context) {

    return MultiProvider(
      providers: [ 
        //providers de gestion combustible
        ChangeNotifierProvider(create: (context) => LoginProvider()),
        ChangeNotifierProvider(create: (context) => SincronizarProvider()),
        ChangeNotifierProvider(create: (context) => ContenedorProvider()),
        ChangeNotifierProvider(create: (context) => IngresoProvider()),
        ChangeNotifierProvider(create: (context) => EgresoProvider()),
        ChangeNotifierProvider(create: (context) => ListadoHistorialProvider()),
        ChangeNotifierProvider(create: (context) => TransferenciaProvider()),
        ChangeNotifierProvider(create: (context) => StockPuntosTanqueoProvider()),
        //providers de control de obra
        ChangeNotifierProvider(create: (context) => Menu1Provider()),
        ChangeNotifierProvider(create: (context) => Menu2Provider()),
        ChangeNotifierProvider(create: (context) => Menu3Provider()),
        ChangeNotifierProvider(create: (context) => Menu4Provider()),

      ],
      child: const MyApp()
    );
    /* return MyApp(); */
  }

}

class MyApp extends StatelessWidget{
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
         GlobalMaterialLocalizations.delegate
       ],
       supportedLocales: const [
         Locale('es'),
       ],
      title: 'GestionCombustible',
      initialRoute: 'Login',
      routes: {
        //rutas de gestion de combustible
        'Home':(context) => const Home(),
        'Login': (context) => Login(),
        'StockPuntoTanqueo': (context) => StockPuntoTanqueo(),
        'formularioIngesoEgresoTransferencia': (context) => Principal(),
        'listadoHitorial': (context) => ListadoHistorial(),
        //rutas de control de obra
        'Menu1':(context) => const Menu1(),
        'Menu3':(context) => const Menu3(),
        'Tabs':(context) => const Tabs(),
        'Menu4':(context) => const Menu4(),
      },
    );
    
  }
}