import 'package:flutter/material.dart';

class RutasController {

  /*
   * @method irPagina
   * @funcionalidad Se encarga de redirigir al usuario cuando presiona una tarjeta.
   */
  irPagina(BuildContext context, nombreRuta){
    return Navigator.pushNamed(context, nombreRuta);

  }

    /*
   * @method irPaginaConParamentros
   * @funcionalidad Se encarga de redirigir al usuario cuando presiona una tarjeta.
   */
  irPaginaTabConParamentros(
    BuildContext context, 
    nombreRuta, 
    id, 
    lengthTab,
    initialIndex,
    proyecto,
    ordenTrabajo
    ){
    return Navigator.pushNamed(context, nombreRuta, arguments: ScreenArgumentsTab(
        id, 
        lengthTab,
        initialIndex,
        proyecto,
        ordenTrabajo
      ),);

  }

  /*
   * @method volverPagina
   * @funcionalidad Se encarga de devolver a la pagina anterior
   */
  volverPagina(BuildContext context){
    return Navigator.pop(context, true);
  }

}

class ScreenArgumentsTab {
  final int? id;
  final int lengthTab;
  final int initialIndex;
  final String? proyecto;
  final String? ordenTrabajo;

  ScreenArgumentsTab(
    this.id, 
    this.lengthTab,
    this.initialIndex,
    this.proyecto,
    this.ordenTrabajo
  );
}