import 'dart:convert';

import 'package:com_gestioncombustible_app/app_control_obra/model/conexion_model.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';

class Menu2Provider extends ChangeNotifier{

  List<dynamic>? idReporteDiarioCreado;
  DateTime date = DateTime.now();
  TimeOfDay horaInicial = TimeOfDay.now();
  TimeOfDay horaFinal = TimeOfDay.now();
  bool checkSolLluvia = false;
  String? nombreProyecto;
  String? nombreOrdenTrabajo;
  String? colaborador;
  String? equipo;
  String? nombreInterventor;
  String? residente;
  String? novedades; 

  //List<dynamic> allInterventores = [];

  /*
  @method: asginarFecha
  @funcionamiento: Se encarga de asignar la fecha
  */
  asignarFecha(fecha){
    if (fecha == null){
      return;
    }else{
      date=fecha;
    }
    notifyListeners();
  }

  /*
  @method: estadoCheckSolLLuvia
  @funcionamiento: Se encarga de cambiar el check del sol al de lluvia
  */
  estadoCheckSolLLuvia(estado){
    checkSolLluvia = !estado;
    notifyListeners();
  }

  /*
   * @method: asignarTiempoInicial
   * @funcionamiento: Se encarga de asignar la hora inicial
   */
  asignarTiempoInicial(tiempo){
    if(tiempo == null){
      horaInicial = TimeOfDay.now();
    }else{
      horaInicial = tiempo;
    }
    notifyListeners();
  }

  /*
   * @method: asignarTiempoFinal
   * @funcionamiento: Se encarga de asignar la hora final
   */
  asignarTiempoFinal(tiempo){
    //print(tiempo);
    if(tiempo == null){
      horaFinal = TimeOfDay.now();
    }else{
      horaFinal = tiempo;
    }
    notifyListeners();
  }

  /*
   * @method: asignarColaborador
   * @funcionamiento: Se encarga de asignar el colaborador
   */
  asignarColaborador(valor){
    colaborador = valor;
    notifyListeners();
  }

    /*
   * @method: asignarEquipo
   * @funcionamiento: Se encarga de asignar el equipo
   */
  asignarEquipo(valor){
    equipo = valor;
    notifyListeners();
  }

  
 /*  obtenerInterventores()async{

    allInterventores.clear();

    List<Map<String, Object>> intervetores = [
      {
        'id':1,
        'nombre':'interventor1'
      },
      {
        'id':2,
        'nombre':'interventor2'
      }
    ] ;

    for (var i = 0; i < intervetores.length; i++) {
      allInterventores.add("${ intervetores[i]['id'] } ${intervetores[i]['nombre']}");
    }

  } */

  /*
  *@method asignarInterventor
  *@funcionalidad: Se encarga de asignar al interventor
  */
  asignarInterventor(valor){
    nombreInterventor = valor;
    notifyListeners();
  }

  /*
  *@method asignarResidente
  *@funcionalidad: Se encarga de asignar al residente
  */
  asignarResidente(valor){
    residente = valor;
    notifyListeners();
  }

  /*
   * @method: asignarNovedades
   * @funcionamiento: Se encarga de asignar novedades
   */
  asignarNovedades(valor){
    novedades = valor;
    notifyListeners();
  }

  /*
  *@method: guardarReporteDiario
  @funcionalidad Se encarga de guardar el formulario de reporte diario
  */
  Future<bool> guardarReporteDiario()async{

    //estados de la tarjeta
    /*
    0- local-abierto
    1- local-cerrado
    2- en servidor
    */

    Map<String, Object> dato = {
      'fecha':date.toString(),
      'tiempo':checkSolLluvia == false ? 0 : 1,
      'tiempoInicial':'${horaInicial.hour}:${horaInicial.minute}',
      'tiempoFinal':'${horaFinal.hour}:${horaFinal.minute}',
      'nombreProyecto': nombreProyecto.toString(),
      'nombreOrdenTrabajo': nombreOrdenTrabajo.toString(),
      'colaborador': colaborador.toString(),
      'equipo': equipo.toString(),
      'interventorNombre': nombreInterventor.toString(),
      'residente': residente.toString(),
      'novedades': novedades.toString(),
      'estadoTarjeta': 0.toString()
    };

    //print(jsonEncode(dato));

    var respuesta = await DBControlObra.insertarReporteDiario(
      date.toString(),
      checkSolLluvia == false ? 0 : 1, 
      '${horaInicial.hour}:${horaInicial.minute}', 
      '${horaFinal.hour}:${horaFinal.minute}', 
      nombreProyecto.toString(), 
      nombreOrdenTrabajo.toString(), 
      colaborador.toString(), 
      equipo.toString(), 
      nombreInterventor.toString(), 
      residente.toString(),
      novedades.toString(),
      0.toString()
      );
    
    idReporteDiarioCreado = await DBControlObra.obtenerUltimoIdReporteDiario();

    return respuesta;
  }

  /*
   @method: reiniciarValores
   @funcionaminento: reinicia los valores del formulario
   */
  reiniciarValores(){
    checkSolLluvia = false;
    nombreProyecto = null;
    nombreOrdenTrabajo = null;
    colaborador = null;
    equipo = null;
    nombreInterventor = null;
    residente= null;
    novedades = null;
    notifyListeners();
  }



 

}