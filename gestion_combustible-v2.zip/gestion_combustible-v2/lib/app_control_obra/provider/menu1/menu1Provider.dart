import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';

class Menu1Provider extends ChangeNotifier{

  DateTime date = DateTime.now();
  String? proyectoSeleccionado;
  int? proyectoSeleccionadoId;
  String? ordenTrabajoSeleccionado;
  int? ordenTrabajoSeleccionadoId;

  List<dynamic> allProyectos = [] ;
  List<dynamic> allOrdenTrabajos = [];
  

  obtenerProyectos()async{

    allProyectos.clear();

    List<Map<String, Object>> proyectos = [
      {
        'id':1,
        'nombre':'proyecto Hocol'
      },
      {
        'id':2,
        'nombre':'proyecto cañada'
      }
    ] ;

    for (var i = 0; i < proyectos.length; i++) {
      allProyectos.add("${ proyectos[i]['id'] } ${proyectos[i]['nombre']}");
    }

  }


  obtenerOrdenTrabajo()async{

    allOrdenTrabajos.clear();

    List<Map<String, Object>> ordenTrabajo = [
      {
        'id':1,
        'nombre':'OT123'
      },
      {
        'id':2,
        'nombre':'OT456'
      }
    ] ;

    for (var i = 0; i < ordenTrabajo.length; i++) {
      allOrdenTrabajos.add("${ ordenTrabajo[i]['id'] } ${ordenTrabajo[i]['nombre']}");
    }

  }

  /*
  @method: asginarFecha
  @funcionamiento: Se encarga de asignar la fecha
  */
  asignarFecha(fecha){
    if (fecha == null){
      return;
    }else{
      date=fecha;
    }
    notifyListeners();
  }

  /*
  @method: asignarProyecto
  @funcionamiento: Se encarga de asignar el proyecto
  */
  asignarProyecto(proyecto){
    if(proyecto == null){
      proyectoSeleccionado = null;
      proyectoSeleccionadoId = null;
    }else{
      proyectoSeleccionado = proyecto.toString();
      var idTemporal = proyecto.split(' ');
      proyectoSeleccionadoId =  int.parse(idTemporal[0]);
    }
    notifyListeners();
  }

   /*
  @method: asginarOrdenTrabajo
  @funcionamiento: Se encarga de asignar la orden de trabajo
  */
  asginarOrdenTrabajo(ordenTrabajo){
    if(ordenTrabajo == null){
      ordenTrabajoSeleccionado = null;
      ordenTrabajoSeleccionadoId = null;
    }else{
      ordenTrabajoSeleccionado = ordenTrabajo.toString();
      var idTemporal = ordenTrabajo.split(' ');
      ordenTrabajoSeleccionadoId =  int.parse(idTemporal[0]);
    }
    notifyListeners();
  }

  /*
   @method: reiniciarValores
   @funcionaminento: reinicia los valores del formulario
   */
  reiniciarValores(){
    proyectoSeleccionado = null;
    ordenTrabajoSeleccionado = null;
    proyectoSeleccionadoId = null;
    ordenTrabajoSeleccionadoId = null;
    notifyListeners();
  }

}