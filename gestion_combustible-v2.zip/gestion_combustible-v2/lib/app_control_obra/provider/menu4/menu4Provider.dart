import 'package:com_gestioncombustible_app/app_control_obra/model/conexion_model.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';

class Menu4Provider extends ChangeNotifier{

  DateTime date = DateTime.now();
  String proyectoSeleccionado = "";
  String ordenTrabajoSeleccionado = "";
  List<dynamic> resportes = [];
  /*
  @method: asginarFecha
  @funcionamiento: Se encarga de asignar la fecha
  */
  asignarFecha(fecha){
    if (fecha == null){
      return;
    }else{
      date=fecha;
    }
    notifyListeners();
  }

  obtenerTodosReporteDiarios()async{
    resportes = await DBControlObra.obtenerReporteDiario();
    notifyListeners();
  }

}