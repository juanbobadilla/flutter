
import 'dart:io';
import 'dart:convert';
import 'dart:developer' as developer;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class Menu3Provider extends ChangeNotifier{

  int? idReporteDiario;
  DateTime date = DateTime.now();
  String? nombreActividad;
  int? actividadId;
  String? novedades;
  double cantidadEjecutada = 0;
  String? abcisaInicial;
  String? abcisaFinal;
  String? nombreInsumo;
  int? insumoId;
  String? nombreOrigen;
  int? origenId;
  double cantidad = 0;

  List<dynamic> allActividades = [];
  List<dynamic> allInsumos = [];
  List<dynamic> allOrigen = [];
  List< Map<String, Object>> listaInsumos = [];
  
  String base64stringImagen1 = "";
  String nombreImagen1 = "";
  var imagen1 = null;
  String extensionImagen1 = "";

  String base64stringImagen2 = "";
  String nombreImagen2 = "";
  var imagen2 = null;
  String extensionImagen2 = "";
  
  String mensajeAdjuntoDocumentos = "";

  bool mostrarFormulario = false;

  getIdReporteDiario(id){
    if(id == 'null'){
      id = null;
    }else{
      idReporteDiario = int.parse(id);
    }
    //notifyListeners();
  }

  /*
   *@method cambiarFormulario
   @funcionalidad Cambia el formulario una vez se guarda la actividad
   */
  cambiarFormulario(){
    mostrarFormulario = !mostrarFormulario;
    notifyListeners();
  }

  /*
  @method: asginarFecha
  @funcionamiento: Se encarga de asignar la fecha
  */
  asignarFecha(fecha){
    if (fecha == null){
      return;
    }else{
      date=fecha;
    }
    notifyListeners();
  }

    /*
   *@method: obtenerOrigen
   *@funcionalidad: Se encarga de cargar los origenes
   */
  agregarInsumo(){
    var nombreTemporalInsumo;
    var origenTemporalInsumo;

    if(nombreInsumo != null || nombreInsumo != '' || nombreOrigen != null || nombreOrigen ==''){
      var insumoTemporal = nombreInsumo?.split(' ');
      nombreTemporalInsumo =  insumoTemporal?[1];

      var origenTemporal = nombreOrigen?.split(' ');
      origenTemporalInsumo =  origenTemporal?[1];
    }
    
    Map<String, Object> insumo =
      {
        'insumo': nombreTemporalInsumo.toString(),
        'cantidad': cantidad.toString(),
        'origen':origenTemporalInsumo.toString(),
      };

    listaInsumos.add(insumo);

    print(listaInsumos);
    reiniciarFormularioInsumos();
    notifyListeners();

  }


    /*
  *@method asignarOrigen
  *@funcionalidad: Se encarga de asignar el origen a sus variables
  */
  asignarOrigen(valor){
    print(valor);
    if(valor == null){
      nombreOrigen = null;
      origenId = null;
    }else{
      nombreOrigen = valor.toString();
      var idTemporal = valor.split(' ');
      origenId =  int.parse(idTemporal[0]);
    }
    //notifyListeners();
  }

  /*
   *@method: obtenerOrigen
   *@funcionalidad: Se encarga de cargar los origenes
   */
  obtenerOrigen()async{

    allOrigen.clear();

    List<Map<String, Object>> origen = [
      {
        'id':1,
        'nombre':'origen1'
      },
      {
        'id':2,
        'nombre':'origen2'
      }
    ] ;

    for (var i = 0; i < origen.length; i++) {
      allOrigen.add("${ origen[i]['id'] } ${origen[i]['nombre']}");
    }

  }


  /*
  *@method asignarInsumo
  *@funcionalidad: Se encarga de asignar el insumo a las variables
  */
  asignarInsumo(valor){
    print(valor);
    if(valor == null){
      nombreInsumo = null;
      insumoId = null;
    }else{
      nombreInsumo = valor.toString();
      var idTemporal = valor.split(' ');
      insumoId =  int.parse(idTemporal[0]);
    }
    //notifyListeners();
  }

  /*
   *@method: obtenerInsumos
   *@funcionalidad: Se encarga de cargar los insumos en el formulario
   */
  obtenerInsumos()async{

    allInsumos.clear();

    List<Map<String, Object>> insumo = [
      {
        'id':1,
        'nombre':'insumo1'
      },
      {
        'id':2,
        'nombre':'insumo2'
      }
    ] ;

    for (var i = 0; i < insumo.length; i++) {
      allInsumos.add("${ insumo[i]['id'] } ${insumo[i]['nombre']}");
    }

  }

  /*
  @method: asignarCantidad
  @funcionamiento: Se encarga de asignar la cantidad a la variable
  */
  asignarCantidad(valor){
    if(valor.isEmpty){
      cantidad = 0;
    }else{
      cantidad = double.parse(valor);
    }
    //notifyListeners();
  }

  /*
  @method: asignarAbcisaFinal
  @funcionamiento: Se encarga de asignar la abcisa final a su variable
  */
  asignarAbcisaFinal(valor){
    abcisaFinal = valor;
    //notifyListeners();
  }

  /*
  @method: asingarAbcisaInicial
  @funcionamiento: Se encarga de asignar la abcisa inicial a su variable
  */
  asignarAbcisaInicial(valor){
    abcisaInicial = valor;
    //notifyListeners();
  }


  /*
  @method: asingarCantidadEjecutada
  @funcionamiento: Se encarga de asignar la cantidad ejecutada a su variable
  */
  asignarCantidadEjecutada(valor){
    if(valor.isEmpty){
      cantidadEjecutada = 0;
    }else{
      cantidadEjecutada = double.parse(valor);
    }
    //notifyListeners();
  }

  /*
  @method: asignarNovedad
  @funcionamiento: Se encarga de asignar las novedades a la varibale
  */
  asignarNovedad(valor){
    novedades = valor;
    //notifyListeners();
  }

  /*
  *@method asignarActividad
  *@funcionalidad: Se encarga de asignar la actividad a las variables
  */
  asignarActividad(valor){
    print(valor);
    if(valor == null){
      nombreActividad = null;
      actividadId = null;
    }else{
      nombreActividad = valor.toString();
      var idTemporal = valor.split(' ');
      actividadId =  int.parse(idTemporal[0]);
    }
   // notifyListeners();
  }

  /*
   *@method: obtenerActividades
   *@funcionalidad: Se encarga de cargar las actividades en el formulario
   */
  obtenerActividades()async{

    allActividades.clear();

    List<Map<String, Object>> actividades = [
      {
        'id':1,
        'nombre':'actividad1'
      },
      {
        'id':2,
        'nombre':'actividad2'
      }
    ] ;

    for (var i = 0; i < actividades.length; i++) {
      allActividades.add("${ actividades[i]['id'] } ${actividades[i]['nombre']}");
    }

  }

  guardarActividades(){
    Map<String, Object> actividades =
      {
        'idReporteDiario': idReporteDiario.toString(),
        'actividad': actividadId.toString() ,
        'novedad': novedades.toString(),
        'unidadMedida': 'm3',
        'cantidadEjecutada': cantidadEjecutada.toString(),
        'abcisaInicial': abcisaInicial.toString(),
        'abcisaFinal': abcisaFinal.toString(),
        'insumos': listaInsumos,
        'imagen1': base64stringImagen1,
        'extension1': extensionImagen1,
        'imagen2': base64stringImagen2,
        'extension2': extensionImagen2
      };
    //primero se debe guardar las actividades para luego retornar el id
    //segundo se vuelve a recorrer el json y nos ubicamos en los insumos
    //los cuales van hacer recorridos para guardarlos juntos con el id anterior.
    var jsonString = actividades.toString();
    developer.log(jsonEncode(actividades));

  }

  /*
   * @method seleccionarImagen1
   * @funcionalidad se encarga de adjuntar la imagen seleccionada o tomada desde la camara
   */
  seleccionarImagen1(opcion, context) async {
    final ImagePicker imgpicker = ImagePicker();
    String imagepath = "";

    switch (opcion) {
      case 0:
        try {
          var archivoSeleccionado = await imgpicker.pickImage(
              source: ImageSource.camera,
              maxWidth: 1080,
              maxHeight: 720,
              imageQuality: 80);

          if (archivoSeleccionado != null) {
            imagepath = archivoSeleccionado.path;
            nombreImagen1 = archivoSeleccionado.name;

            var informacionImagen = [];
            informacionImagen = archivoSeleccionado.name.split('.');
            extensionImagen1 = informacionImagen[1];
            File imagefile = File(imagepath); //convert Path to File
            Uint8List imagebytes =
                await imagefile.readAsBytes(); //convert to bytes
            base64stringImagen1 = base64.encode(imagebytes); //convert bytes to base64 string
            
            //developer.log(base64stringImagen1.toString());

            //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

            imagen1 = base64.decode(base64stringImagen1);
            developer.log(imagen1.toString());

            Navigator.pop(context);

            mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
            notifyListeners();
            return true;
          } else {
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }
        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos =
              "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;
      case 1:
        try {
          var archivoSeleccionado = await imgpicker.pickImage(
              source: ImageSource.gallery,
              maxWidth: 1080,
              maxHeight: 720,
              imageQuality: 80);

          if (archivoSeleccionado != null) {
            var informacionImagen = [];

            informacionImagen = archivoSeleccionado.name.split('.');

            if (informacionImagen[1] == "jpg" ||
                informacionImagen[1] == "png") {
              imagepath = archivoSeleccionado.path;
              nombreImagen1 = archivoSeleccionado.name;
              extensionImagen1 = informacionImagen[1];

              File imagefile = File(imagepath); //convert Path to File
              Uint8List imagebytes =
                  await imagefile.readAsBytes(); //convert to bytes
              base64stringImagen1 =
                  base64.encode(imagebytes); //convert bytes to base64 string

              //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

              imagen1 = base64.decode(base64stringImagen1);

              Navigator.pop(context);
              mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
              notifyListeners();
              return true;
            } else {
              Navigator.pop(context);
              mensajeAdjuntoDocumentos =
                  "La imagen seleccionada tiene que ser de formato jpg.";
              notifyListeners();
              return false;
            }
          } else {
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }
        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos =
              "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;

      default:
    }
  }

    /*
   * @method seleccionarImagen2
   * @funcionalidad se encarga de adjuntar la imagen seleccionada o tomada desde la camara
   */
  seleccionarImagen2(opcion, context) async {
    final ImagePicker imgpicker = ImagePicker();
    String imagepath = "";

    switch (opcion) {
      case 0:
        try {
          var archivoSeleccionado = await imgpicker.pickImage(
              source: ImageSource.camera,
              maxWidth: 1080,
              maxHeight: 720,
              imageQuality: 80);

          if (archivoSeleccionado != null) {
            imagepath = archivoSeleccionado.path;
            nombreImagen2 = archivoSeleccionado.name;

            var informacionImagen = [];
            informacionImagen = archivoSeleccionado.name.split('.');
            extensionImagen2 = informacionImagen[1];
            File imagefile = File(imagepath); //convert Path to File
            Uint8List imagebytes =
                await imagefile.readAsBytes(); //convert to bytes
            base64stringImagen2 = base64.encode(imagebytes); //convert bytes to base64 string
            
            //developer.log(base64stringImagen1.toString());

            //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

            imagen2 = base64.decode(base64stringImagen2);
            developer.log(imagen2.toString());

            Navigator.pop(context);

            mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
            notifyListeners();
            return true;
          } else {
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }
        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos =
              "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;
      case 1:
        try {
          var archivoSeleccionado = await imgpicker.pickImage(
              source: ImageSource.gallery,
              maxWidth: 1080,
              maxHeight: 720,
              imageQuality: 80);

          if (archivoSeleccionado != null) {
            var informacionImagen = [];

            informacionImagen = archivoSeleccionado.name.split('.');

            if (informacionImagen[1] == "jpg" ||
                informacionImagen[1] == "png") {
              imagepath = archivoSeleccionado.path;
              nombreImagen2 = archivoSeleccionado.name;
              extensionImagen2 = informacionImagen[1];

              File imagefile = File(imagepath); //convert Path to File
              Uint8List imagebytes =
                  await imagefile.readAsBytes(); //convert to bytes
              base64stringImagen2 =
                  base64.encode(imagebytes); //convert bytes to base64 string

              //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

              imagen2 = base64.decode(base64stringImagen2);

              Navigator.pop(context);
              mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
              notifyListeners();
              return true;
            } else {
              Navigator.pop(context);
              mensajeAdjuntoDocumentos =
                  "La imagen seleccionada tiene que ser de formato jpg.";
              notifyListeners();
              return false;
            }
          } else {
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }
        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos =
              "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;

      default:
    }
  }

  /*
   * @method eliminarImagen1
   * @funcionalidad Se enecarga de eliminar la foto alctualmente agregada
   */
  eliminarImagen1(){
    base64stringImagen1 = "";
    nombreImagen1 = "";
    imagen1 = null;
    extensionImagen1 = "";
    //notifyListeners();
  }

  /*
   * @method eliminarImagen2
   * @funcionalidad Se enecarga de eliminar la foto alctualmente agregada
   */
  eliminarImagen2(){
    base64stringImagen2 = "";
    nombreImagen2 = "";
    imagen2 = null;
    extensionImagen2 = "";
    //notifyListeners();
  }

  reiniciarTodosFormulario(){
    nombreActividad = null;
    actividadId = null;
    novedades = null;
    cantidadEjecutada = 0;
    abcisaInicial = null;
    abcisaFinal = null;
    nombreInsumo = null;
    insumoId = null;
    nombreOrigen = null;
    origenId = null;
    cantidad = 0;
    listaInsumos = [];
    eliminarImagen1();
    eliminarImagen2();
    notifyListeners();
  }

    reiniciarFormularioInsumos(){
    nombreInsumo = null;
    insumoId = null;
    nombreOrigen = null;
    origenId = null;
    cantidad = 0;
  }
 

}