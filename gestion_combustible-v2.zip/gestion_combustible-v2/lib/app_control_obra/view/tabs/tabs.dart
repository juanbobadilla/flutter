import 'package:com_gestioncombustible_app/app_control_obra/controller/rutas.dart';
import 'package:com_gestioncombustible_app/app_control_obra/view/menu2.dart';
import 'package:com_gestioncombustible_app/app_control_obra/view/menu3.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/controller/home/home_controller.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Tabs extends StatefulWidget {
  const Tabs({ super.key });

  @override
  State<Tabs> createState() => TabsState();
}

class TabsState extends State<Tabs> {
  
  var homeController = RutasController();

  @override
  Widget build(BuildContext context) {
    
    final parametros = ModalRoute.of(context)!.settings.arguments as ScreenArgumentsTab;
    
     

    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) {
            return alertaSalir(context);
          },
        );
        return shouldPop!;
      },
      child: DefaultTabController(
        length: parametros.lengthTab, 
        initialIndex: parametros.initialIndex,
        child: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            backgroundColor: Color.fromARGB(255, 0, 77, 150),
            iconTheme: const IconThemeData(color: Color.fromARGB(255, 242, 103, 33)),
            centerTitle: true,
            title: Text(
              'NOMBRE APP',
              style: GoogleFonts.quicksand(
                  color: Color.fromARGB(255, 255, 255, 255),
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                )
              //style: TextStyle(color: Color.fromARGB(255, 30, 42, 120), fontSize: 20.0),
            ),
            actions: const [
              Image(
                width: 45,
                image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
                fit: BoxFit.fitWidth, 
              ),
              SizedBox(width: 5,)
            ],
            bottom: const PreferredSize(//Tabs
              preferredSize:  Size.fromHeight(100),
              child:  TabBar(
                isScrollable: true,
                  tabs: <Widget> [
                    Tab(
                        icon: Image(
                          image: AssetImage("lib/app_control_obra/sources/reporte.png"),
                          width: 25,               
                          ),
                        text: 'Reporte diario'
                      ),
                     Tab(
                      icon: Image(
                        image: AssetImage("lib/app_control_obra/sources/comprobacionLista.png"),
                        width: 25,
                        ),
                      text: 'Actividades',
                    ),
                  ]
                ),
            )
          ),
          body: TabBarView(
                children: [
                    Menu2(proyecto: parametros.proyecto.toString(), ordenTrabajo: parametros.ordenTrabajo.toString() ),
                    Menu3(id: parametros.id.toString(), proyecto: parametros.proyecto?.toString(), ordenTrabajo: parametros.ordenTrabajo?.toString()),
                 ]
            ),
          drawer: menuLateral(context),
          bottomNavigationBar: CurvedNavigationBar(
            index: 0,
            onTap: (index){
              if(index == 0){
                homeController.irPagina(context, 'Home');
              }
              if(index == 1){
                homeController.irPagina(context, 'Menu4');
              }
            },
            animationDuration : Duration(milliseconds: 300),
            height:52,
            buttonBackgroundColor:Color.fromARGB(255, 242, 103, 34),
            backgroundColor: Color.fromARGB(255, 250, 250, 250),
            color: Color.fromARGB(255, 0, 77, 150),
            items: const [
              Icon( //ICONO
                    Icons.home,
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
              Icon(
                  Icons.menu,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
            ],
           ),
          ),
        ),
    );
  }
}

Widget menuLateral(BuildContext context){

    //importo el provider
    final sincronizarProvider = Provider.of<SincronizarProvider>(context);

    var usuario = context.watch<LoginProvider>().nombreUsuario;
    var documento = context.watch<LoginProvider>().documento;
    var cargo = context.watch<LoginProvider>().cargo;

    return Drawer(
        child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
            //icono y datos del usuario
            Container(
              height: 200.0,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Color.fromARGB(27, 0, 0, 0)
                  )
                )
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Image(
                    width: 65,
                    image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
                    fit: BoxFit.cover, 
                    ),
                  SizedBox(height: 10),
                  Text(usuario.toString(), textAlign: TextAlign.center ,style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w500)),
                  //const SizedBox(height: 5),
                  //Text(documento.toString(), style: const TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.bold),),
                  const SizedBox(height: 5),
                  Text(cargo.toString(), style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w400))
                ],
              ),
            ),
            
            Column(//CUERPO DEL DRAWER
              children: <Widget>[
                SizedBox(//BOTON DE COPIA DE SEGURIDAD
                    width: double.infinity,
                    child: TextButton.icon(
                        style: ButtonStyle(
                            overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                            padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                            alignment: Alignment.centerLeft 
                        ),
                        onPressed: (){
                          sincronizarProvider.descargarDatosLocales();
                        }, 
                        icon: const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/copia.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Copia de seguridad', style: TextStyle( color: Colors.black, fontSize: 20.0, fontWeight: FontWeight.w300 ),)
                  
                      ),
                  ),

                SizedBox(//BOTON DE SINCRONIZAR
                  width: double.infinity,
                    child: TextButton.icon(
                       style: ButtonStyle(
                          overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                          padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                          alignment: Alignment.centerLeft 
                        ),
                        onPressed: ()async{
                          var respuesta = await sincronizarProvider.importarLosDatos();
                          respuesta == 200 ?
                          alerta(context, "Sincronizado completo", true) : 
                          alerta(context, "Recuerde que para sincronizar necesita estar conectado a una red.", false);
                        }, 
                        icon: sincronizarProvider.loadingPeticion == true ? 
                        Container(
                          padding: const EdgeInsets.all(1),
                          width: 20,
                          height: 20,
                          child: const CircularProgressIndicator(
                            color: Colors.amber,
                            strokeWidth: 3,
                          )
                        ) : const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/sincronizar.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Sincronizar', style: TextStyle( color: Colors.black, fontSize: 20.0,fontWeight: FontWeight.w300 ),)
                
                      ),
                  ),

                SizedBox(//BOTON DE SALIR
                  width: double.infinity,
                   child: TextButton.icon(
                    style: ButtonStyle(
                      overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                      padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                      alignment: Alignment.centerLeft 
                    ),
                      onPressed: (){
                        Navigator.of(context).pushNamedAndRemoveUntil('Login', (Route<dynamic> route) => false);
                      }, 
                      icon: const Image(
                              width: 15,
                              image: AssetImage("lib/app_gestion_combustible/sources/salir_app/salir.png"),
                              fit: BoxFit.cover,
                              ), 
                      label: const Text('Salir', style: TextStyle( color: Colors.black, fontSize: 20.0 , fontWeight: FontWeight.w300),)
                 
                      ),
                 ),
              ],
            ),
          ],
        ),
      );
  }

Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

Widget alertaSalir (BuildContext context){
    return AlertDialog(
              //title: const Text('¿ Desea salir de la aplicación ?', textAlign: TextAlign.center,),
              actionsAlignment: MainAxisAlignment.center,
              content: Container(
                height: 100,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset('lib/app_gestion_combustible/sources/salir_app/question.png', height: 60),
                      SizedBox(height: 20),
                      const Text(
                        '¿ Desea salir del formulario actual ?', 
                        textAlign: TextAlign.center, 
                        style: TextStyle( color: Colors.black54 )
                      ),
                    ],
                  ),
              ),
              actions: [
                TextButton(
                  style: const ButtonStyle( 
                    backgroundColor: MaterialStatePropertyAll<Color>(Color.fromARGB(255, 243, 121, 21)),
                  ),
                  onPressed: () {
                    //Navigator.pop(context, true);
                    Navigator.of(context).pushNamedAndRemoveUntil('Menu1', (Route<dynamic> route) => false);
                  },
                  child: const Text('SI', style: TextStyle( color: Colors.white )),
                ),
              ],
            );
  }
