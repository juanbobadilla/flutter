import 'package:com_gestioncombustible_app/app_control_obra/controller/rutas.dart';
import 'package:com_gestioncombustible_app/app_control_obra/provider/menu1/menu1Provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

class Menu1 extends StatefulWidget{
  const Menu1({super.key});

  @override
  State<Menu1> createState() => StateMenu1();
}


class StateMenu1 extends State<Menu1>{

  var homeController = RutasController();

  final keyFormulario = GlobalKey<FormState>();
  /* final keyDropdownProyecto = GlobalKey<FormFieldState>();
  final keyDropdownOrdenTrabajo = GlobalKey<FormFieldState>(); */

   @override
    void initState() {
      /* final loginProvider = Provider.of<LoginProvider>(context, listen: false);
      final sincronizarProvider = Provider.of<SincronizarProvider>(context, listen: false);

      loginProvider.obtenerSesion();
      sincronizarProvider.obtenerSesion(); */
      final menu1Provider = Provider.of<Menu1Provider>(context, listen: false);
      //menu1Provider.obtenerProyectos();
      menu1Provider.obtenerOrdenTrabajo();
    
      super.initState();
    }

  @override
  Widget build(BuildContext context) {

    //importo el provider
    final menu1Provider  = Provider.of<Menu1Provider>(context);
    
    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) {
            return alertaSalir(context);
          },
        );
        return shouldPop!;
      },
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            backgroundColor: Colors.white,
            iconTheme: const IconThemeData(color: Color.fromARGB(255, 242, 103, 33)),
            centerTitle: true,
            title: Text(
              'NOMBRE APP',
              style: GoogleFonts.quicksand(
                  color: const Color.fromARGB(255, 35, 35, 35),
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                )
              //style: TextStyle(color: Color.fromARGB(255, 30, 42, 120), fontSize: 20.0),
            ),
            actions: const [
              Image(
                width: 45,
                image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
                fit: BoxFit.fitWidth, 
              ),
              SizedBox(width: 5,)
            ],
          ),
          drawer: menuLateral(context),
          body: Form(
            key: keyFormulario,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
    
                Padding(//CALENDARIO
                  padding: const EdgeInsets.only(left: 40, right: 0, top: 20),
                  child: GestureDetector(
                    onTap: () async{
                      
                      DateTime? newDate = await showDatePicker(
                        context: context,
                        initialDate: menu1Provider.date,
                        firstDate: DateTime(1900),
                        lastDate: DateTime(2030),
                      );
    
                      menu1Provider.asignarFecha(newDate);
    
                    },
                    child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Align(//IMAGEN DEL CALENDARIO
                            alignment: Alignment.centerLeft,
                            child: Stack(
                              alignment: AlignmentDirectional.bottomCenter,
                              children: <Widget>[              
                                const Image(
                                  image: AssetImage("lib/app_control_obra/sources/calendario.png",),
                                  width: 50,
                                  ),
                                Text(
                                  "${menu1Provider.date.day}",
                                  style: TextStyle( fontSize: 30 ),
                                  ),
                              ],
                            ),
                          ),
                          Container(//CONTENEDOR DE TEXTO
                            padding: const EdgeInsets.only(left: 20, right: 20, top: 1, bottom: 2),
                            decoration: const BoxDecoration(
                              color: Colors.transparent,
                              border:  Border(
                                top: BorderSide( color: Colors.black ),
                                bottom: BorderSide( color: Colors.black ),
                                right: BorderSide( color: Colors.black ),
                              )
                            ),
                            child: Text(
                              DateFormat('MMM').format(menu1Provider.date) == 'Jan' ? 'Enero' : 
                              DateFormat('MMM').format(menu1Provider.date) == 'Feb' ? 'Febrero' :
                              DateFormat('MMM').format(menu1Provider.date) == 'Mar' ? 'Marzo': 
                              DateFormat('MMM').format(menu1Provider.date) == 'Apr' ? 'Abril': 
                              DateFormat('MMM').format(menu1Provider.date) == 'May' ? 'Mayo' : 
                              DateFormat('MMM').format(menu1Provider.date) == 'Jun' ? 'Junio': 
                              DateFormat('MMM').format(menu1Provider.date) == 'Jul' ? 'Julio':
                              DateFormat('MMM').format(menu1Provider.date) == 'Aug' ? 'Agosto':
                              DateFormat('MMM').format(menu1Provider.date) == 'Sep' ? 'Septiembre': 
                              DateFormat('MMM').format(menu1Provider.date) == 'Oct' ? 'Octubre':
                              DateFormat('MMM').format(menu1Provider.date) == 'Nov' ? 'Noviembre': 
                              DateFormat('MMM').format(menu1Provider.date) == 'Dec' ? 'Diciembre':
                              '',
                              //"${menu1Provider.date.day}-${menu1Provider.date.month}-${menu1Provider.date.year}",
                              style: GoogleFonts.quicksand(
                                  color: const Color.fromARGB(255, 35, 35, 35),
                                  fontSize: 20,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                          )
                        ],
                      ),
                  ),
                ),
                
                const SizedBox(height: 50),//ESPACIO
    
                /* Padding(//LABEL SUPERIOR PROYECTOS
                padding:const EdgeInsets.only(left: 40, bottom: 4),
                            child: Text(
                              "Proyecto",
                              style: GoogleFonts.quicksand(
                                color: Color.fromARGB(255, 8, 8, 8),
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                height: 2
                                )
                              ),
                          ),
    
                Padding( //SELECT DE PROYECTOS
                  padding: const EdgeInsets.only(left: 40, right: 40),
                  child: Container(
                    decoration: const  BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(20)),
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(102, 0, 0, 0),
                                  blurRadius: 7,
                                  spreadRadius: 0,
                                  offset: const Offset(0, 8)
                                )
                              ]
                            ),
                    child: DropdownSearch(
                                    selectedItem: menu1Provider.proyectoSeleccionado,
                                    validator: (value) {
                                      if(value == null || value == ''){
                                        return "Este campo es requerido";
                                      }
                                    },
                                    items: menu1Provider.allProyectos,
                                    mode : Mode.MENU,
                                    showSearchBox: true, 
                                    showClearButton: true,
                                    dropdownSearchDecoration:  InputDecoration(
                                      filled: true,
                                      fillColor: Colors.white,
                                      border:OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(20),
                                        borderSide: BorderSide.none
                                      ),
                                      hintText: 'Seleccionar proyecto',
                                      hintStyle: const TextStyle(
                                        color: Color.fromARGB(255, 160, 159, 153),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                        letterSpacing: 1.3,
                                        fontFamily: 'quicksand'
                                      ),
                                      errorBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(20),
                                          borderSide: const BorderSide(
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          width: 2
                                        )
                                      ) ,
                                      errorStyle: const TextStyle( 
                                        color: Color.fromARGB(255, 255, 0, 0),
                                        letterSpacing: 1,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 15
                                        )
                                    ),
                                    
                                    onChanged: (e) {
                                      menu1Provider.asignarProyecto(e);
                                    },
                                  ),
                  ),
                  ),
    
                const SizedBox(height: 20),//ESPACIO
    
                Padding(//LABEL SUPERIOR ORDEN DE TRABAJO
                padding:const EdgeInsets.only(left: 40, bottom: 4),
                            child: Text(
                              "Orden de trabajo",
                              style: GoogleFonts.quicksand(
                                color: Color.fromARGB(255, 8, 8, 8),
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                height: 2
                                )
                              ),
                          ), */
    
                Padding( //SELECT DE ORDEN DE TRABAJO
                  padding: const EdgeInsets.only(left: 40, right: 40),
                  child: Container(
                    decoration: const  BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(20)),
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(102, 0, 0, 0),
                                  blurRadius: 7,
                                  spreadRadius: 0,
                                  offset: const Offset(0, 8)
                                )
                              ]
                            ),
                    child: DropdownSearch(
                                    selectedItem: menu1Provider.ordenTrabajoSeleccionado,
                                    validator: (value) {
                                      if(value == null || value ==""){
                                        return "Este campo es requerido";
                                      }
                                    },
    
                                    mode : Mode.MENU,
                                    showSearchBox: true,
                                    items: menu1Provider.allOrdenTrabajos,
                                    showClearButton: true,
                                    dropdownSearchDecoration:  InputDecoration(
                                      filled: true,
                                      fillColor: Colors.white,
                                      border:OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(20),
                                        borderSide: BorderSide.none
                                      ),
                                      hintText: 'Seleccionar orden de trabajo',
                                      hintStyle: const TextStyle(
                                        color: Color.fromARGB(255, 160, 159, 153),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                        letterSpacing: 1.3,
                                        fontFamily: 'quicksand'
                                      ),
                                      errorBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(20),
                                            borderSide: const BorderSide(
                                            color: Color.fromARGB(255, 255, 0, 0),
                                            width: 2
                                          )
                                        ) ,
                                        errorStyle: const TextStyle( 
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          letterSpacing: 1,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 15
                                          )
                                      
                                    ),
                                    
                                    onChanged: (e) {
                                      menu1Provider.asginarOrdenTrabajo(e);
                                    },
                                  ),
                  ),
                  ),
    
                const SizedBox(height: 100),//ESPACIO
    
                Center(//BOTON PARA NUEVO REPORTE
                  child: Padding(//BOTON PARA NUEVO REPORTE
                      padding: const EdgeInsets.only(),
                      child: TextButton.icon( // BOTON
                        onPressed: (){
                          if(keyFormulario.currentState!.validate()){
                            var proyectoTemporal = menu1Provider.proyectoSeleccionado?.substring(1); 
                            var ordenTrabajotemporal =  menu1Provider.ordenTrabajoSeleccionado?.substring(1);
                            homeController.irPaginaTabConParamentros(
                              context, 
                              "Tabs",
                              null,
                              2,
                              0,
                              proyectoTemporal, 
                              ordenTrabajotemporal
                              );
                            menu1Provider.reiniciarValores();
                          }else{
                            return;
                          }
                        }, 
                        icon: Container( //CONTENEDOR DEL ICONO
                          padding: const EdgeInsets.all(10),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white
                            ) ,
                            child: const Icon( //ICONO
                            size: 40,
                            FontAwesomeIcons.plus, 
                            color: Color.fromARGB(255, 242, 103, 34),
                          ),
                        ), 
                        label: Text(//TEXTO DEL BOTON
                          "Nuevo Reporte", 
                          style: GoogleFonts.quicksand(
                              color: const Color.fromARGB(255, 255, 255, 255),
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                            ), 
                        ),
                        style: ButtonStyle( //ESTILOS DEL BOTON
                          side: MaterialStateProperty.all( 
                            const BorderSide(
                            width: 1,
                            color: Color.fromARGB(13, 0, 0, 0),
                            ),
                          ),
                         shape: MaterialStateProperty.all(
                                        RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(100)
                                        )
                                      ),
                          elevation: MaterialStateProperty.all(10),
                          padding: MaterialStateProperty.all( const EdgeInsets.only( top: 0, bottom: 0 , right: 20)),
                          backgroundColor: MaterialStateProperty.all(const Color.fromARGB(255, 242, 103, 34))
                        ),
                      )
                    ),
                )
    
              ],
            ),
          ),
          bottomNavigationBar: CurvedNavigationBar(
            index: 0,
            onTap: (index){
              if(index == 0){
                homeController.irPagina(context, 'Home');
              }
              if(index == 1){
                homeController.irPagina(context, 'Menu4');
              }
            },
            animationDuration : Duration(milliseconds: 300),
            height:52,
            buttonBackgroundColor:Color.fromARGB(255, 242, 103, 34),
            backgroundColor: Color.fromARGB(255, 250, 250, 250),
            color: Color.fromARGB(255, 0, 77, 150),
            items: const [
              Icon( //ICONO
                    Icons.home,
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
              Icon(
                  Icons.menu,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
            ],
           ),
    
        ),  
      ),
    );
  }
}

Widget menuLateral(BuildContext context){

    //importo el provider
    final sincronizarProvider = Provider.of<SincronizarProvider>(context);

    var usuario = context.watch<LoginProvider>().nombreUsuario;
    var documento = context.watch<LoginProvider>().documento;
    var cargo = context.watch<LoginProvider>().cargo;

    return Drawer(
        child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
            //icono y datos del usuario
            Container(
              height: 200.0,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Color.fromARGB(27, 0, 0, 0)
                  )
                )
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Image(
                    width: 65,
                    image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
                    fit: BoxFit.cover, 
                    ),
                  SizedBox(height: 10),
                  Text(usuario.toString(), textAlign: TextAlign.center ,style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w500)),
                  //const SizedBox(height: 5),
                  //Text(documento.toString(), style: const TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.bold),),
                  const SizedBox(height: 5),
                  Text(cargo.toString(), style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w400))
                ],
              ),
            ),
            
            Column(//CUERPO DEL DRAWER
              children: <Widget>[
                SizedBox(//BOTON DE COPIA DE SEGURIDAD
                    width: double.infinity,
                    child: TextButton.icon(
                        style: ButtonStyle(
                            overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                            padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                            alignment: Alignment.centerLeft 
                        ),
                        onPressed: (){
                          sincronizarProvider.descargarDatosLocales();
                        }, 
                        icon: const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/copia.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Copia de seguridad', style: TextStyle( color: Colors.black, fontSize: 20.0, fontWeight: FontWeight.w300 ),)
                  
                      ),
                  ),

                SizedBox(//BOTON DE SINCRONIZAR
                  width: double.infinity,
                    child: TextButton.icon(
                       style: ButtonStyle(
                          overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                          padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                          alignment: Alignment.centerLeft 
                        ),
                        onPressed: ()async{
                          var respuesta = await sincronizarProvider.importarLosDatos();
                          respuesta == 200 ?
                          alerta(context, "Sincronizado completo", true) : 
                          alerta(context, "Recuerde que para sincronizar necesita estar conectado a una red.", false);
                        }, 
                        icon: sincronizarProvider.loadingPeticion == true ? 
                        Container(
                          padding: const EdgeInsets.all(1),
                          width: 20,
                          height: 20,
                          child: const CircularProgressIndicator(
                            color: Colors.amber,
                            strokeWidth: 3,
                          )
                        ) : const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/sincronizar.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Sincronizar', style: TextStyle( color: Colors.black, fontSize: 20.0,fontWeight: FontWeight.w300 ),)
                
                      ),
                  ),

                SizedBox(//BOTON DE SALIR
                  width: double.infinity,
                   child: TextButton.icon(
                    style: ButtonStyle(
                      overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                      padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                      alignment: Alignment.centerLeft 
                    ),
                      onPressed: (){
                        Navigator.of(context).pushNamedAndRemoveUntil('Login', (Route<dynamic> route) => false);
                      }, 
                      icon: const Image(
                              width: 15,
                              image: AssetImage("lib/app_gestion_combustible/sources/salir_app/salir.png"),
                              fit: BoxFit.cover,
                              ), 
                      label: const Text('Salir', style: TextStyle( color: Colors.black, fontSize: 20.0 , fontWeight: FontWeight.w300),)
                 
                      ),
                 ),
              ],
            ),
          ],
        ),
      );
  }

Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

Widget alertaSalir (BuildContext context){
    return AlertDialog(
              //title: const Text('¿ Desea salir de la aplicación ?', textAlign: TextAlign.center,),
              actionsAlignment: MainAxisAlignment.center,
              content: Container(
                height: 100,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset('lib/app_gestion_combustible/sources/salir_app/question.png', height: 60),
                      SizedBox(height: 20),
                      const Text(
                        '¿ Desea salir del formulario actual ?', 
                        textAlign: TextAlign.center, 
                        style: TextStyle( color: Colors.black54 )
                      ),
                    ],
                  ),
              ),
              actions: [
                TextButton(
                  style: const ButtonStyle( 
                    backgroundColor: MaterialStatePropertyAll<Color>(Color.fromARGB(255, 243, 121, 21)),
                  ),
                  onPressed: () {
                    //Navigator.pop(context, true);
                    Navigator.of(context).pushNamedAndRemoveUntil('Home', (Route<dynamic> route) => false);
                  },
                  child: const Text('SI', style: TextStyle( color: Colors.white )),
                ),
              ],
            );
  }


