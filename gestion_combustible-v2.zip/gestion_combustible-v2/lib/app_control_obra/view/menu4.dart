import 'package:com_gestioncombustible_app/app_control_obra/controller/rutas.dart';
import 'package:com_gestioncombustible_app/app_control_obra/provider/menu4/menu4Provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/controller/home/home_controller.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:dropdown_search/dropdown_search.dart';
import "package:flutter/material.dart";
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class Menu4 extends StatefulWidget {
  const Menu4({ super.key });

  @override
  State<Menu4> createState() => _Menu4State();
}

class _Menu4State extends State<Menu4> {

  final keyFormulario = GlobalKey<FormState>();
  var homeController = RutasController();

  @override
    void initState() {
      final menu4Provider = Provider.of<Menu4Provider>(context, listen: false);
      menu4Provider.obtenerTodosReporteDiarios();
      super.initState();
    }


  @override
  Widget build(BuildContext context) {

    final menu4Provider  = Provider.of<Menu4Provider>(context);

    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) {
            return alertaSalir(context);
          },
        );
        return shouldPop!;
      },
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            backgroundColor: Colors.white,
            iconTheme: const IconThemeData(color: Color.fromARGB(255, 242, 103, 33)),
            centerTitle: true,
            title: Text(
              'NOMBRE APP',
              style: GoogleFonts.quicksand(
                  color: const Color.fromARGB(255, 35, 35, 35),
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                )
              //style: TextStyle(color: Color.fromARGB(255, 30, 42, 120), fontSize: 20.0),
            ),
            actions: const [
              Image(
                width: 45,
                image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
                fit: BoxFit.fitWidth, 
              ),
              SizedBox(width: 5,)
            ],
          ),
          drawer: menuLateral(context),
          body: Form(
            key: keyFormulario,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
    
                Padding(//CALENDARIO
                  padding: const EdgeInsets.only(left: 40, right: 0, top: 20),
                  child: GestureDetector(
                    onTap: () async{
                      
                      DateTime? newDate = await showDatePicker(
                        context: context,
                        initialDate: menu4Provider.date,
                        firstDate: DateTime(1900),
                        lastDate: DateTime(2030),
                      );
    
                      menu4Provider.asignarFecha(newDate);
    
                    },
                    child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Align(//IMAGEN DEL CALENDARIO
                            alignment: Alignment.centerLeft,
                            child: Stack(
                              alignment: AlignmentDirectional.bottomCenter,
                              children: <Widget>[              
                                const Image(
                                  image: AssetImage("lib/app_control_obra/sources/calendario.png",),
                                  width: 50,
                                  ),
                                Text(
                                  "${menu4Provider.date.day}",
                                  style: TextStyle( fontSize: 30 ),
                                  ),
                              ],
                            ),
                          ),
                          Container(//CONTENEDOR DE TEXTO
                            padding: const EdgeInsets.only(left: 20, right: 20, top: 1, bottom: 2),
                            decoration: const BoxDecoration(
                              color: Colors.transparent,
                              border:  Border(
                                top: BorderSide( color: Colors.black ),
                                bottom: BorderSide( color: Colors.black ),
                                right: BorderSide( color: Colors.black ),
                              )
                            ),
                            child: Text(
                              DateFormat('MMM').format(menu4Provider.date) == 'Jan' ? 'Enero' : 
                              DateFormat('MMM').format(menu4Provider.date) == 'Feb' ? 'Febrero' :
                              DateFormat('MMM').format(menu4Provider.date) == 'Mar' ? 'Marzo': 
                              DateFormat('MMM').format(menu4Provider.date) == 'Apr' ? 'Abril': 
                              DateFormat('MMM').format(menu4Provider.date) == 'May' ? 'Mayo' : 
                              DateFormat('MMM').format(menu4Provider.date) == 'Jun' ? 'Junio': 
                              DateFormat('MMM').format(menu4Provider.date) == 'Jul' ? 'Julio':
                              DateFormat('MMM').format(menu4Provider.date) == 'Aug' ? 'Agosto':
                              DateFormat('MMM').format(menu4Provider.date) == 'Sep' ? 'Septiembre': 
                              DateFormat('MMM').format(menu4Provider.date) == 'Oct' ? 'Octubre':
                              DateFormat('MMM').format(menu4Provider.date) == 'Nov' ? 'Noviembre': 
                              DateFormat('MMM').format(menu4Provider.date) == 'Dec' ? 'Diciembre':
                              '',
                              //"${menu1Provider.date.day}-${menu1Provider.date.month}-${menu1Provider.date.year}",
                              style: GoogleFonts.quicksand(
                                  color: const Color.fromARGB(255, 35, 35, 35),
                                  fontSize: 20,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                          )
                        ],
                      ),
                  ),
                ),
                const SizedBox(height: 40,),
                Center(//TEXTO
                              child: Padding(
                              padding: const EdgeInsets.only(left: 40, right: 40),
                              child: Text(
                                "HISTORIAL",
                                style: GoogleFonts.quicksand(
                                  color: Color.fromARGB(255, 242, 103, 34),
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                const SizedBox(height: 20,),
    
                Expanded(//LISTA DE TARJETAS
                  child: ListView(
                    children: context.watch<Menu4Provider>().resportes.map((item) => tarjeta(item)).toList(),
                    ),  /*  Padding(//TARJETA
    
    
                      Padding(//TARJETA
                        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                        child: Card(
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                            side: BorderSide(
                              color: Color.fromARGB(255, 242, 158, 56),
                            ),
                            borderRadius:  BorderRadius.all(Radius.circular(12)),
                          ),
                          child:  Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
    
                              Padding(//TITULO E ICONO DE LA TARJETA
                                padding:const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(//TEXTO
                                      "OT123 - TOY AMBIENTAL",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        decoration: TextDecoration.underline
                                        )
                                      ),
                                    const Icon(//ICONO
                                      FontAwesomeIcons.shareNodes,
                                      color: Color.fromARGB(255, 0, 77, 150),)
                                  ],
                                ), 
                              ),
    
                              Padding(//FECHA
                                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                                child: Text(//FECHA
                                      "18/01/2023",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        )
                                    ),
                                
                                 ),
    
                              Padding(//ACTIVIDADES Y CONTAINER DE ESTADO
                                padding: EdgeInsets.only(left: 15, right: 15, top: 5, bottom: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    
                                    Text(//TITULO
                                      "Actividades: 5",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        )
                                    ),
    
                                    SizedBox(width: 5,),
    
                                    Flexible(//CONTAINER
                                      child: Container(
                                        width: 120,
                                        padding: EdgeInsets.all(5),
                                        decoration: BoxDecoration(
                                          color: Color.fromARGB(255, 33, 149, 81),
                                          borderRadius: BorderRadius.circular(10)
                                        ),
                                        child: Text(
                                          textAlign: TextAlign.center,
                                          "En servidor",
                                          style: GoogleFonts.quicksand(
                                            color: Color.fromARGB(255, 255, 255, 255),
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                            )
                                          ),
                                      )
                                    ),
                                  ],
                                )
                              ),
    
                             
                          ],
                          ),
                        ),
                      ),
     */
                  ),
                const SizedBox(height: 20,),
    
              ]
            ),
          ),
          bottomNavigationBar: CurvedNavigationBar(
            index: 0,
            onTap: (index){
              if(index == 0){
                homeController.irPagina(context, 'Home');
              }
            },
            animationDuration : Duration(milliseconds: 300),
            height:52,
            buttonBackgroundColor:Color.fromARGB(255, 242, 103, 34),
            backgroundColor: Color.fromARGB(255, 250, 250, 250),
            color: Color.fromARGB(255, 0, 77, 150),
            items: const [
              Icon( //ICONO
                    Icons.home,
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
            ],
           ),
       
        )
        
      ),
    );
  }

  Widget tarjeta(item){
    print(item);

    return Padding(//TARJETA
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                      child: Card(
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                          side: BorderSide(
                            color: Color.fromARGB(255, 242, 158, 56),
                          ),
                          borderRadius:  BorderRadius.all(Radius.circular(12)),
                        ),
                        child:  Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                            Padding(//TITULO E ICONO DE LA TARJETA
                              padding:const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(//TEXTO
                                    item["nombreOrdenTrabajo"] +'-'+ item["nombreProyecto"],
                                    style: GoogleFonts.quicksand(
                                      color: Color.fromARGB(255, 26, 26, 26),
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      decoration: TextDecoration.underline
                                      )
                                    ),
                                  const Icon(//ICONO
                                    FontAwesomeIcons.arrowRightFromBracket,
                                    color: Colors.red,)
                                ],
                              ), 
                            ),

                            Padding(//FECHA
                              padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                              child: Text(//FECHA
                                    item["fecha"].toString().substring(0, 10),
                                    style: GoogleFonts.quicksand(
                                      color: Color.fromARGB(255, 26, 26, 26),
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      )
                                  ),
                              
                               ),

                            Padding(//ACTIVIDADES Y CONTAINER DE ESTADO
                              padding: EdgeInsets.only(left: 15, right: 15, top: 5, bottom: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  
                                  Text(//TITULO
                                    "Actividades: 5",
                                    style: GoogleFonts.quicksand(
                                      color: Color.fromARGB(255, 26, 26, 26),
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      )
                                  ),

                                  SizedBox(width: 5,),

                                  Flexible(//CONTAINER
                                    child: Container(
                                      width: 120,
                                      padding: EdgeInsets.all(5),
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 0, 77, 150),
                                        borderRadius: BorderRadius.circular(10)
                                      ),
                                      child: Text(
                                        textAlign: TextAlign.center,
                                        item["estadoTarjeta"].toString() == "0" ? "Local - Abierto": "otro",
                                        style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 255, 255, 255),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                          )
                                        ),
                                    )
                                  ),
                                ],
                              )
                            ),

                           
                        ],
                        ),
                      ),
                    );

  }

  Widget menuLateral(BuildContext context){

    //importo el provider
    final sincronizarProvider = Provider.of<SincronizarProvider>(context);

    var usuario = context.watch<LoginProvider>().nombreUsuario;
    var documento = context.watch<LoginProvider>().documento;
    var cargo = context.watch<LoginProvider>().cargo;

    return Drawer(
        child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
            //icono y datos del usuario
            Container(
              height: 200.0,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Color.fromARGB(27, 0, 0, 0)
                  )
                )
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Image(
                    width: 65,
                    image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
                    fit: BoxFit.cover, 
                    ),
                  SizedBox(height: 10),
                  Text(usuario.toString(), textAlign: TextAlign.center ,style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w500)),
                  //const SizedBox(height: 5),
                  //Text(documento.toString(), style: const TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.bold),),
                  const SizedBox(height: 5),
                  Text(cargo.toString(), style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w400))
                ],
              ),
            ),
            
            Column(//CUERPO DEL DRAWER
              children: <Widget>[
                SizedBox(//BOTON DE COPIA DE SEGURIDAD
                    width: double.infinity,
                    child: TextButton.icon(
                        style: ButtonStyle(
                            overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                            padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                            alignment: Alignment.centerLeft 
                        ),
                        onPressed: (){
                          sincronizarProvider.descargarDatosLocales();
                        }, 
                        icon: const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/copia.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Copia de seguridad', style: TextStyle( color: Colors.black, fontSize: 20.0, fontWeight: FontWeight.w300 ),)
                  
                      ),
                  ),

                SizedBox(//BOTON DE SINCRONIZAR
                  width: double.infinity,
                    child: TextButton.icon(
                       style: ButtonStyle(
                          overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                          padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                          alignment: Alignment.centerLeft 
                        ),
                        onPressed: ()async{
                          var respuesta = await sincronizarProvider.importarLosDatos();
                          respuesta == 200 ?
                          alerta(context, "Sincronizado completo", true) : 
                          alerta(context, "Recuerde que para sincronizar necesita estar conectado a una red.", false);
                        }, 
                        icon: sincronizarProvider.loadingPeticion == true ? 
                        Container(
                          padding: const EdgeInsets.all(1),
                          width: 20,
                          height: 20,
                          child: const CircularProgressIndicator(
                            color: Colors.amber,
                            strokeWidth: 3,
                          )
                        ) : const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/sincronizar.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Sincronizar', style: TextStyle( color: Colors.black, fontSize: 20.0,fontWeight: FontWeight.w300 ),)
                
                      ),
                  ),

                SizedBox(//BOTON DE SALIR
                  width: double.infinity,
                   child: TextButton.icon(
                    style: ButtonStyle(
                      overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                      padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                      alignment: Alignment.centerLeft 
                    ),
                      onPressed: (){
                        Navigator.of(context).pushNamedAndRemoveUntil('Login', (Route<dynamic> route) => false);
                      }, 
                      icon: const Image(
                              width: 15,
                              image: AssetImage("lib/app_gestion_combustible/sources/salir_app/salir.png"),
                              fit: BoxFit.cover,
                              ), 
                      label: const Text('Salir', style: TextStyle( color: Colors.black, fontSize: 20.0 , fontWeight: FontWeight.w300),)
                 
                      ),
                 ),
              ],
            ),
          ],
        ),
      );
  }

  Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  Widget alertaSalir (BuildContext context){
    return AlertDialog(
              //title: const Text('¿ Desea salir de la aplicación ?', textAlign: TextAlign.center,),
              actionsAlignment: MainAxisAlignment.center,
              content: Container(
                height: 100,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset('lib/app_gestion_combustible/sources/salir_app/question.png', height: 60),
                      SizedBox(height: 20),
                      const Text(
                        '¿ Desea agregar un nuevo reporte ?', 
                        textAlign: TextAlign.center, 
                        style: TextStyle( color: Colors.black54 )
                      ),
                    ],
                  ),
              ),
              actions: [
                TextButton(
                  style: const ButtonStyle( 
                    backgroundColor: MaterialStatePropertyAll<Color>(Color.fromARGB(255, 243, 121, 21)),
                  ),
                  onPressed: () {
                    //Navigator.pop(context, true);
                    Navigator.of(context).pushNamedAndRemoveUntil('Menu1', (Route<dynamic> route) => false);
                  },
                  child: const Text('SI', style: TextStyle( color: Colors.white )),
                ),
              ],
            );
  }

  
}



