import 'dart:async';

import 'package:com_gestioncombustible_app/app_control_obra/controller/rutas.dart';
import 'package:com_gestioncombustible_app/app_control_obra/provider/menu2/menu2Provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';


class Menu2 extends StatefulWidget {
  const Menu2({ super.key, this.id, required this.proyecto, required this.ordenTrabajo });

  final String? id;
  final String proyecto;
  final String ordenTrabajo;

  @override
  State<Menu2> createState() => Menu2State();
}

class Menu2State extends State<Menu2> {
  

  final keyFormulario = GlobalKey<FormState>();
  
  @override
  void initState(){

    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {
    
    //final parametros = ModalRoute.of(context)!.settings.arguments as ScreenArgumentsTab;
    final rutas = RutasController();
    //importo el provider
    final menu2Provider  = Provider.of<Menu2Provider>(context);
    menu2Provider.nombreProyecto = widget.proyecto.trim();
    menu2Provider.nombreOrdenTrabajo = widget.ordenTrabajo.trim();

    
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
         resizeToAvoidBottomInset: true,
          body: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                children:[
                Form(//INICIO DEL FORMULARIO
                  key:keyFormulario,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                        Row(//SECCION DEL CALENDARIO Y CHECK
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget> [
                            
                            Padding(//CALENDARIO

                              padding: const EdgeInsets.only(left: 40, right: 0, top: 20),
                              child: GestureDetector(
                                onTap: () async{
                                  
                                  DateTime? newDate = await showDatePicker(
                                    context: context,
                                    initialDate: menu2Provider.date,
                                    firstDate: DateTime(1900),
                                    lastDate: DateTime(2030),
                                  );

                                  menu2Provider.asignarFecha(newDate);

                                },
                                child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Align(//IMAGEN DEL CALENDARIO
                                        alignment: Alignment.centerLeft,
                                        child: Stack(
                                          alignment: AlignmentDirectional.bottomCenter,
                                          children: <Widget>[              
                                            const Image(
                                              image: AssetImage("lib/app_control_obra/sources/calendario.png",),
                                              width: 50,
                                              ),
                                            Text(
                                              "${menu2Provider.date.day}",
                                              style: const TextStyle( fontSize: 30 ),
                                              ),
                                          ],
                                        ),
                                      ),
                                      Container(//CONTENEDOR DE TEXTO
                                        padding: const EdgeInsets.only(left: 20, right: 20, top: 1, bottom: 2),
                                        decoration: const BoxDecoration(
                                          color: Colors.transparent,
                                          border:  Border(
                                            top: BorderSide( color: Colors.black ),
                                            bottom: BorderSide( color: Colors.black ),
                                            right: BorderSide( color: Colors.black ),
                                          )
                                        ),
                                        child: Text(
                                          DateFormat('MMM').format(menu2Provider.date) == 'Jan' ? 'Enero' : 
                                          DateFormat('MMM').format(menu2Provider.date) == 'Feb' ? 'Febrero' :
                                          DateFormat('MMM').format(menu2Provider.date) == 'Mar' ? 'Marzo': 
                                          DateFormat('MMM').format(menu2Provider.date) == 'Apr' ? 'Abril': 
                                          DateFormat('MMM').format(menu2Provider.date) == 'May' ? 'Mayo' : 
                                          DateFormat('MMM').format(menu2Provider.date) == 'Jun' ? 'Junio': 
                                          DateFormat('MMM').format(menu2Provider.date) == 'Jul' ? 'Julio':
                                          DateFormat('MMM').format(menu2Provider.date) == 'Aug' ? 'Agosto':
                                          DateFormat('MMM').format(menu2Provider.date) == 'Sep' ? 'Septiembre': 
                                          DateFormat('MMM').format(menu2Provider.date) == 'Oct' ? 'Octubre':
                                          DateFormat('MMM').format(menu2Provider.date) == 'Nov' ? 'Noviembre': 
                                          DateFormat('MMM').format(menu2Provider.date) == 'Dec' ? 'Diciembre':
                                          '',
                                          //"${menu1Provider.date.day}-${menu1Provider.date.month}-${menu1Provider.date.year}",
                                          style: GoogleFonts.quicksand(
                                              color: const Color.fromARGB(255, 35, 35, 35),
                                              fontSize: 20,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                      )
                                    ],
                                  ),
                              ),
                            ),

                            Padding(//CHECK
                              padding: const EdgeInsets.only(left: 0, right: 40, top: 20),
                              child: GestureDetector(
                                onTap: (){
                                  menu2Provider.estadoCheckSolLLuvia(menu2Provider.checkSolLluvia);
                                },
                                child: Image(
                                  image: menu2Provider.checkSolLluvia == false ? 
                                    const AssetImage("lib/app_control_obra/sources/checkSol.png") : 
                                    const AssetImage("lib/app_control_obra/sources/checkLluvia.png"),
                                  fit: BoxFit.cover,
                                  width: 90,
                                  ),
                              ),
                              )

                          ],
                        ),

                        const SizedBox(height: 40,),

                        if(menu2Provider.checkSolLluvia == true)
                        Row(//TIEMPO DE LLUVIA
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                            Padding(//TEXTO
                              padding: const EdgeInsets.only(left: 0),
                              child: Text(
                                "Tiempo de lluvia",
                                style: GoogleFonts.quicksand(
                                  color: Color.fromARGB(255, 0, 0, 0),
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),

                            Padding(//INPUT
                              padding: const EdgeInsets.all(0),
                              child: TextButton.icon(
                                  onPressed: ()async{
                                      TimeOfDay? time = await showTimePicker(
                                        context: context, 
                                        initialTime: TimeOfDay.now()
                                        );

                                      menu2Provider.asignarTiempoInicial(time);
                                  }, 
                                  icon: const Icon(
                                    FontAwesomeIcons.clock,
                                    size: 15, 
                                    color: Colors.black45, 
                                  ), 
                                  label: Text(
                                    "${menu2Provider.horaInicial.hour}:${menu2Provider.horaInicial.minute}",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontSize: 18,
                                          fontWeight: FontWeight.w500,
                                        )
                                    ),
                                  style: ButtonStyle(
                                    side: MaterialStateProperty.all( 
                                        const BorderSide(
                                        width: 2,
                                        color: Color.fromARGB(66, 0, 0, 0),
                                        ),
                                      ),
                                    shape: MaterialStateProperty.all(
                                      RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(100)
                                      )
                                    ),
                                    padding: MaterialStateProperty.all( const EdgeInsets.symmetric(horizontal: 15, vertical: 20)),
                                  ),
                                )
                                
                              ),

                            Padding(//INPUT
                              padding: const EdgeInsets.all(0),
                              child: TextButton.icon(
                                  onPressed: ()async{
                                      TimeOfDay? time = await showTimePicker(
                                        context: context, 
                                        initialTime: TimeOfDay.now()
                                        );

                                      menu2Provider.asignarTiempoFinal(time);
                                  }, 
                                  icon: const Icon(
                                    FontAwesomeIcons.clock,
                                    size: 15, 
                                    color: Colors.black45, 
                                  ), 
                                  label: Text(
                                    "${menu2Provider.horaFinal.hour}:${menu2Provider.horaFinal.minute}",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontSize: 18,
                                          fontWeight: FontWeight.w500,
                                        )
                                    ),
                                  style: ButtonStyle(
                                    side: MaterialStateProperty.all( 
                                        const BorderSide(
                                        width: 2,
                                        color: Color.fromARGB(66, 0, 0, 0),
                                        ),
                                      ),
                                    shape: MaterialStateProperty.all(
                                      RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(100)
                                      )
                                    ),
                                    padding: MaterialStateProperty.all( const EdgeInsets.symmetric(horizontal: 15, vertical: 20)),
                                  ),
                                )
                                
                              ),
                            ],
                        ),

                        const SizedBox(height: 30,),

                        Center(//TEXTO
                          child: Padding(
                          padding: const EdgeInsets.only(left: 40, right: 40),
                          child: Text(
                            "${widget.ordenTrabajo} - ${widget.proyecto}",
                            style: GoogleFonts.quicksand(
                               color: const Color.fromARGB(255, 0, 77, 150),
                               fontSize: 20,
                               fontWeight: FontWeight.bold,
                               decoration: TextDecoration.underline
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 40,),

                        Padding(//LABEL SUPERIOR RECURSOS HUMANOS
                          padding:const EdgeInsets.only(left: 40, bottom: 4),
                          child: Text(
                            "Recursos Humanos",
                            style: GoogleFonts.quicksand(
                              color: Color.fromARGB(255, 8, 8, 8),
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              height: 2
                              )
                            ),
                        ),

                        Padding(//INPUT RECURSOS HUMANOS
                        padding: const EdgeInsets.symmetric( horizontal:  40.0),
                        child: Container(
                          decoration: const  BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(102, 0, 0, 0),
                                blurRadius: 2,
                                spreadRadius: 0,
                                offset: const Offset(0, 5)
                              )
                            ]
                          ),
                          child: TextFormField(
                            //initialValue: menu2Provider.colaborador,
                            validator: (value){
                              if(value == null || value==""){
                                return 'Debe ingresar un colaborador.';
                              }
                              return null;
                            },
                            onChanged: (value){
                              menu2Provider.asignarColaborador(value);
                            },
                            keyboardType: TextInputType.text,
                            style:  const  TextStyle(
                              height:1,
                              color:  Color.fromARGB(255, 83, 82, 82), 
                              fontSize: 20, 
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.3,
                              fontFamily: 'quicksand'
                              ),
                            decoration:  InputDecoration(
                               hintText: 'Escribir colaboradores',
                               hintStyle: const TextStyle(
                                color: Color.fromARGB(255, 160, 159, 153),
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                letterSpacing: 1.3,
                                fontFamily: 'quicksand'
                               ),
                               //labelText: 'Usuario',
                               //floatingLabelBehavior: FloatingLabelBehavior.always,
                               border:  OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide.none
                               ),
                               filled: true,
                               fillColor: Colors.white,
                               errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 255, 0, 0),
                                  width: 2
                                )
                               ) ,
                               errorStyle: const TextStyle( 
                                color: Color.fromARGB(255, 255, 0, 0),
                                letterSpacing: 2.2,
                                fontWeight: FontWeight.w400,
                                fontSize: 15
                                )
                              ),
                            ),
                        ),
                        ),

                        const SizedBox(height: 20,),

                        Padding(//LABEL SUPERIOR EQUIPOS
                          padding:const EdgeInsets.only(left: 40, bottom: 4),
                          child: Text(
                            "Equipos",
                            style: GoogleFonts.quicksand(
                              color: Color.fromARGB(255, 8, 8, 8),
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              height: 2
                              )
                            ),
                        ),

                        Padding(//INPUT EQUIPOS
                        padding: const EdgeInsets.symmetric( horizontal:  40.0),
                        child: Container(
                          decoration: const  BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(102, 0, 0, 0),
                                blurRadius: 2,
                                spreadRadius: 0,
                                offset: const Offset(0, 5)
                              )
                            ]
                          ),
                          child: TextFormField(
                            //initialValue: menu2Provider.equipo,
                            validator: (value){
                              if(value == null || value==""){
                                return 'Debe ingresar un valor';
                              }
                              return null;
                            },
                            onChanged: (value){
                              menu2Provider.asignarEquipo(value);
                            },
                            keyboardType: TextInputType.text,
                            style:  const  TextStyle(
                              height:1,
                              color:  Color.fromARGB(255, 83, 82, 82), 
                              fontSize: 20, 
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.3,
                              fontFamily: 'quicksand'
                              ),
                            decoration:  InputDecoration(
                               hintText: 'Escribir equipos utilizados.',
                               hintStyle: const TextStyle(
                                color: Color.fromARGB(255, 160, 159, 153),
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                letterSpacing: 1.3,
                                fontFamily: 'quicksand'
                               ),
                               //labelText: 'Usuario',
                               //floatingLabelBehavior: FloatingLabelBehavior.always,
                               border:  OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide.none
                               ),
                               filled: true,
                               fillColor: Colors.white,
                               errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 255, 0, 0),
                                  width: 2
                                )
                               ) ,
                               errorStyle: const TextStyle( 
                                color: Color.fromARGB(255, 255, 0, 0),
                                letterSpacing: 2.2,
                                fontWeight: FontWeight.w400,
                                fontSize: 15
                                )
                              ),
                            ),
                        ),
                        ),

                        const SizedBox(height: 20,),

                        Padding(//LABEL SUPERIOR INTERVENTOR
                          padding:const EdgeInsets.only(left: 40, bottom: 4),
                          child: Text(
                            "Interventor",
                            style: GoogleFonts.quicksand(
                              color: Color.fromARGB(255, 8, 8, 8),
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              height: 2
                              )
                            ),
                        ),

                        Padding( //INPUT DE INTERVENTOR
                          padding: const EdgeInsets.only(left: 40, right: 40),
                          child: Container(
                              decoration: const  BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(20)),
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(102, 0, 0, 0),
                                  blurRadius: 2,
                                  spreadRadius: 0,
                                  offset: const Offset(0, 5)
                                )
                              ]
                            ),
                            child: TextFormField(
                            //initialValue: menu2Provider.equipo,
                            validator: (value){
                              if(value == null || value==""){
                                return 'Debe ingresar un valor';
                              }
                              return null;
                            },
                            onChanged: (value){
                              menu2Provider.asignarInterventor(value);
                            },
                            keyboardType: TextInputType.text,
                            style:  const  TextStyle(
                              height:1,
                              color:  Color.fromARGB(255, 83, 82, 82), 
                              fontSize: 20, 
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.3,
                              fontFamily: 'quicksand'
                              ),
                            decoration:  InputDecoration(
                               hintText: 'Escribir el interventor.',
                               hintStyle: const TextStyle(
                                color: Color.fromARGB(255, 160, 159, 153),
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                letterSpacing: 1.3,
                                fontFamily: 'quicksand'
                               ),
                               //labelText: 'Usuario',
                               //floatingLabelBehavior: FloatingLabelBehavior.always,
                               border:  OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide.none
                               ),
                               filled: true,
                               fillColor: Colors.white,
                               errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 255, 0, 0),
                                  width: 2
                                )
                               ) ,
                               errorStyle: const TextStyle( 
                                color: Color.fromARGB(255, 255, 0, 0),
                                letterSpacing: 2.2,
                                fontWeight: FontWeight.w400,
                                fontSize: 15
                                )
                              ),
                            ),
                          ),
                          ),

                        const SizedBox(height: 20,),

                        Padding(//LABEL RESIDENTE
                          padding:const EdgeInsets.only(left: 40, bottom: 4),
                          child: Text(
                            "Residente",
                            style: GoogleFonts.quicksand(
                              color: Color.fromARGB(255, 8, 8, 8),
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              height: 2
                              )
                            ),
                        ),

                        Padding( //INPUT DE RESIDENTE
                          padding: const EdgeInsets.only(left: 40, right: 40),
                          child: Container(
                              decoration: const  BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(20)),
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(102, 0, 0, 0),
                                  blurRadius: 2,
                                  spreadRadius: 0,
                                  offset: const Offset(0, 5)
                                )
                              ]
                            ),
                            child: TextFormField(
                            //initialValue: menu2Provider.equipo,
                            validator: (value){
                              if(value == null || value==""){
                                return 'Debe ingresar un valor';
                              }
                              return null;
                            },
                            onChanged: (value){
                              menu2Provider.asignarResidente(value);
                            },
                            keyboardType: TextInputType.text,
                            style:  const  TextStyle(
                              height:1,
                              color:  Color.fromARGB(255, 83, 82, 82), 
                              fontSize: 20, 
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.3,
                              fontFamily: 'quicksand'
                              ),
                            decoration:  InputDecoration(
                               hintText: 'Escribir el residente.',
                               hintStyle: const TextStyle(
                                color: Color.fromARGB(255, 160, 159, 153),
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                letterSpacing: 1.3,
                                fontFamily: 'quicksand'
                               ),
                               //labelText: 'Usuario',
                               //floatingLabelBehavior: FloatingLabelBehavior.always,
                               border:  OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide.none
                               ),
                               filled: true,
                               fillColor: Colors.white,
                               errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 255, 0, 0),
                                  width: 2
                                )
                               ) ,
                               errorStyle: const TextStyle( 
                                color: Color.fromARGB(255, 255, 0, 0),
                                letterSpacing: 2.2,
                                fontWeight: FontWeight.w400,
                                fontSize: 15
                                )
                              ),
                            ),
                          ),
                          ),

                        const SizedBox(height: 20,),

                        Padding(//LABEL SUPERIOR NOVEDADES
                          padding:const EdgeInsets.only(left: 40, bottom: 4),
                          child: Text(
                            "Novedades",
                            style: GoogleFonts.quicksand(
                              color: Color.fromARGB(255, 8, 8, 8),
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              height: 2
                              )
                            ),
                        ),

                        Padding(//INPUT NOVEDADES
                        padding: const EdgeInsets.symmetric( horizontal:  40.0),
                        child: Container(
                          decoration: const  BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(102, 0, 0, 0),
                                blurRadius: 2,
                                spreadRadius: 0,
                                offset: const Offset(0, 5)
                              )
                            ]
                          ),
                          child: TextFormField(
                            validator: (value){
                              if(value == null || value==""){
                                return 'Debe ingresar un valor';
                              }
                              return null;
                            },
                            onChanged: (value){
                              menu2Provider.asignarNovedades(value);
                            },
                            maxLines: 2,
                            keyboardType: TextInputType.multiline,
                            style:  const  TextStyle(
                              height:1,
                              color:  Color.fromARGB(255, 83, 82, 82), 
                              fontSize: 20, 
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.3,
                              fontFamily: 'quicksand'
                              ),
                            decoration:  InputDecoration(
                               hintText: 'Escribir novedades.',
                               hintStyle: const TextStyle(
                                color: Color.fromARGB(255, 160, 159, 153),
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                letterSpacing: 1.3,
                                fontFamily: 'quicksand'
                               ),
                               //labelText: 'Usuario',
                               //floatingLabelBehavior: FloatingLabelBehavior.always,
                               border:  OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide.none
                               ),
                               filled: true,
                               fillColor: Colors.white,
                               errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 255, 0, 0),
                                  width: 2
                                )
                               ) ,
                               errorStyle: const TextStyle( 
                                color: Color.fromARGB(255, 255, 0, 0),
                                letterSpacing: 2.2,
                                fontWeight: FontWeight.w400,
                                fontSize: 15
                                )
                              ),
                            ),
                        ),
                        ),

                        const SizedBox(height: 50,),
                        
                        Center(//BOTON PARA NUEVO REPORTE
                          child: TextButton( // BOTON
                            onPressed: ()async{
                              if(keyFormulario.currentState!.validate()){

                                var respuesta = await menu2Provider.guardarReporteDiario();
                                if(respuesta == true){
                                  alerta(context, "Registro guardado exitosamente", true);
                                  menu2Provider.reiniciarValores();
                                  keyFormulario.currentState!.reset();
                                  await Future.delayed(Duration(seconds: 1));
                                  
                                  rutas.irPaginaTabConParamentros(
                                    context, 
                                    "Tabs",
                                    menu2Provider.idReporteDiarioCreado?[0]['id'],
                                    2,
                                    1,
                                    widget.proyecto, 
                                    widget.ordenTrabajo
                                  );

                                }else{
                                  alerta(context, "Ocurrio un error al guardar", false);
                                }
                                
                              }
                            } ,
                            child: Text(//TEXTO DEL BOTON
                              "Guardar", 
                              style: GoogleFonts.quicksand(
                                  color: const Color.fromARGB(255, 255, 255, 255),
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                ), 
                            ),
                            style: ButtonStyle( //ESTILOS DEL BOTON
                              side: MaterialStateProperty.all( 
                                const BorderSide(
                                width: 1,
                                color: Color.fromARGB(13, 0, 0, 0),
                                ),
                              ),
                            shape: MaterialStateProperty.all(
                                            RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(100)
                                            )
                                          ),
                              elevation: MaterialStateProperty.all(10),
                              padding: MaterialStateProperty.all( const EdgeInsets.only( top: 0, bottom: 0 , right: 40, left: 40)),
                              backgroundColor: MaterialStateProperty.all(const Color.fromARGB(255, 242, 103, 34))
                            ),
                          )
                        ),

                        const SizedBox(height: 50,),

                      ]
                    )
                
              )
                ]
              )
            ),
          
 
      ),
    );
  }
}


Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_control_obra/sources/alertaOk.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( 
                  mensaje.toString(),
                  textAlign: TextAlign.justify,
                  style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0))),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }
