import 'package:com_gestioncombustible_app/app_control_obra/controller/rutas.dart';
import 'package:com_gestioncombustible_app/app_control_obra/provider/menu3/menu3Provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/controller/home/home_controller.dart';
import 'package:dropdown_search/dropdown_search.dart';
import "package:flutter/material.dart";
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class Menu3 extends StatefulWidget {
  const Menu3({ super.key, this.id, this.proyecto, this.ordenTrabajo});

  final String? id;
  final String? proyecto;
  final String? ordenTrabajo;

  @override
  State<Menu3> createState() => _Menu3State();
}

class _Menu3State extends State<Menu3> {

    @override
  void initState(){

    final menu3Provider = Provider.of<Menu3Provider>(context, listen: false);
    menu3Provider.obtenerActividades();
    menu3Provider.obtenerInsumos();
    menu3Provider.obtenerOrigen();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    final menu3Provider  = Provider.of<Menu3Provider>(context);
    final scaffoldKey = GlobalKey<ScaffoldState>();
    print(widget.id);
    menu3Provider.getIdReporteDiario( widget.id);

    /* final keyFormulario = GlobalKey<FormState>();
    final keyFormularioInsumos = GlobalKey<FormState>(); */
    //var homeController = RutasController();

/*     final keyFormularioActividades = GlobalKey<FormState>();
    final keyFormularioInsumosActividades = GlobalKey<FormState>();
    var homeControllerActividades = RutasController(); */

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        key: scaffoldKey,
         resizeToAvoidBottomInset: true,
         body: 
         widget.id == 'null' ?
           Center(
             child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image(
                      image: AssetImage("lib/app_control_obra/sources/alerta.png",),
                     ),
                    Text(
                     "Recuerda primero crear un reporte diario.",
                     style: GoogleFonts.quicksand(
                     color: Color.fromARGB(255, 173, 31, 10),
                      fontSize: 20,
                      fontWeight: FontWeight.w400,
                     ),
                    ),
                  ]
             ),
           )        
         :
         Column(
              children:  <Widget> [  
                
                Padding(//CALENDARIO

                                  padding: const EdgeInsets.only(left: 40, right: 0, top: 20),
                                  child: GestureDetector(
                                    onTap: () async{
                                      
                                      DateTime? newDate = await showDatePicker(
                                        context: context,
                                        initialDate: menu3Provider.date,
                                        firstDate: DateTime(1900),
                                        lastDate: DateTime(2030),
                                      );

                                      menu3Provider.asignarFecha(newDate);

                                    },
                                    child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Align(//IMAGEN DEL CALENDARIO
                                            alignment: Alignment.centerLeft,
                                            child: Stack(
                                              alignment: AlignmentDirectional.bottomCenter,
                                              children: <Widget>[              
                                                const Image(
                                                  image: AssetImage("lib/app_control_obra/sources/calendario.png",),
                                                  width: 50,
                                                  ),
                                                Text(
                                                  "${menu3Provider.date.day}",
                                                  style: const TextStyle( fontSize: 30 ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                          Container(//CONTENEDOR DE TEXTO
                                            padding: const EdgeInsets.only(left: 20, right: 20, top: 1, bottom: 2),
                                            decoration: const BoxDecoration(
                                              color: Colors.transparent,
                                              border:  Border(
                                                top: BorderSide( color: Colors.black ),
                                                bottom: BorderSide( color: Colors.black ),
                                                right: BorderSide( color: Colors.black ),
                                              )
                                            ),
                                            child: Text(
                                              DateFormat('MMM').format(menu3Provider.date) == 'Jan' ? 'Enero' : 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Feb' ? 'Febrero' :
                                              DateFormat('MMM').format(menu3Provider.date) == 'Mar' ? 'Marzo': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Apr' ? 'Abril': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'May' ? 'Mayo' : 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Jun' ? 'Junio': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Jul' ? 'Julio':
                                              DateFormat('MMM').format(menu3Provider.date) == 'Aug' ? 'Agosto':
                                              DateFormat('MMM').format(menu3Provider.date) == 'Sep' ? 'Septiembre': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Oct' ? 'Octubre':
                                              DateFormat('MMM').format(menu3Provider.date) == 'Nov' ? 'Noviembre': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Dec' ? 'Diciembre':
                                              '',
                                              //"${menu1Provider.date.day}-${menu1Provider.date.month}-${menu1Provider.date.year}",
                                              style: GoogleFonts.quicksand(
                                                  color: const Color.fromARGB(255, 35, 35, 35),
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                          )
                                        ],
                                      ),
                                  ),
                                ),

                const SizedBox(height: 30,),

                Center(//TEXTO
                              child: Padding(
                              padding: const EdgeInsets.only(left: 40, right: 40),
                              child: Text(
                                "${widget.ordenTrabajo} - ${widget.proyecto}",
                                style: GoogleFonts.quicksand(
                                  color: const Color.fromARGB(255, 0, 77, 150),
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  decoration: TextDecoration.underline
                                  ),
                                ),
                              ),
                            ),
                
                const SizedBox(height: 30,),

                GestureDetector(//BOTON PARA AGREGAR ACTIVIDAD
                  onTap: () {
                    alerta(context);
                    //menu3Provider.cambiarFormulario();
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children:  <Widget> [
                      Text(
                        "Agregar actividades",
                        style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 29, 28, 28),
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700,
                                      )),
                      Container( //CONTENEDOR DEL ICONO
                            padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color.fromARGB(255, 242, 103, 34)
                              ) ,
                              child: const Icon( //ICONO
                              size: 25,
                              FontAwesomeIcons.plus, 
                              color: Color.fromARGB(255, 255, 255, 255),
                            ),
                          ),
                    ],
                  ),
                ),

                const SizedBox(height: 30,),

                Expanded(//LISTA DE TARJETAS
                  child: ListView(
                    children: <Widget>[
                      
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: Card(
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                            side: BorderSide(
                              color: Color.fromARGB(255, 242, 158, 56),
                            ),
                            borderRadius:  BorderRadius.all(Radius.circular(12)),
                          ),
                          child:  Column(
                          
                          children: [

                              Padding(//TITULO E ICONO DE LA TARJETA
                                padding:const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(//TEXTO
                                      "125 - Cunetas",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        )
                                      ),
                                    const Icon(//ICONO
                                      FontAwesomeIcons.trash,
                                      color: Colors.amber,)
                                  ],
                                ), 
                              ),

                              Padding(//DESCRIPCION
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO DESCRIPCION
                                      "Descripción:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DESCRIPCION
                                      child: Text(
                                      "Se realiza excavación hasta las 6 de la tarde, prueba de tarjeta.",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//CANTIDAD EJECUTADA
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO CANTIDAD EJECUTADA
                                      "Cantidad ejecutada:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO de la cantidad
                                      child: Text(
                                      "20 m3",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA INICIAL
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA INICIAL
                                      "Abcisa inicial:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA
                                      child: Text(
                                      "K 0 + 440",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA FINAL
                                padding: EdgeInsets.only(left:15,top: 1, bottom: 15),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA FINAL
                                      "Abcisa final:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA FINAL
                                      child: Text(
                                      "K 0 + 470",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                          ],
                          ),
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: Card(
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                            side: BorderSide(
                              color: Color.fromARGB(255, 242, 158, 56),
                            ),
                            borderRadius:  BorderRadius.all(Radius.circular(12)),
                          ),
                          child:  Column(
                          
                          children: [

                              Padding(//TITULO E ICONO DE LA TARJETA
                                padding:const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(//TEXTO
                                      "125 - Cunetas",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        )
                                      ),
                                    const Icon(//ICONO
                                      FontAwesomeIcons.trash,
                                      color: Colors.amber,)
                                  ],
                                ), 
                              ),

                              Padding(//DESCRIPCION
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO DESCRIPCION
                                      "Descripción:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DESCRIPCION
                                      child: Text(
                                      "Se realiza excavación hasta las 6 de la tarde, prueba de tarjeta.",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//CANTIDAD EJECUTADA
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO CANTIDAD EJECUTADA
                                      "Cantidad ejecutada:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO de la cantidad
                                      child: Text(
                                      "20 m3",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA INICIAL
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA INICIAL
                                      "Abcisa inicial:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA
                                      child: Text(
                                      "K 0 + 440",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA FINAL
                                padding: EdgeInsets.only(left:15,top: 1, bottom: 15),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA FINAL
                                      "Abcisa final:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA FINAL
                                      child: Text(
                                      "K 0 + 470",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                          ],
                          ),
                        ),
                      ),

                    ]
                  )
                ),

                const SizedBox(height: 20,),
              ],
            )
        /* menu3Provider.mostrarFormulario == false && widget.id != null ?
          Column(
              children:  <Widget> [  
                
                Padding(//CALENDARIO

                                  padding: const EdgeInsets.only(left: 40, right: 0, top: 20),
                                  child: GestureDetector(
                                    onTap: () async{
                                      
                                      DateTime? newDate = await showDatePicker(
                                        context: context,
                                        initialDate: menu3Provider.date,
                                        firstDate: DateTime(1900),
                                        lastDate: DateTime(2030),
                                      );

                                      menu3Provider.asignarFecha(newDate);

                                    },
                                    child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Align(//IMAGEN DEL CALENDARIO
                                            alignment: Alignment.centerLeft,
                                            child: Stack(
                                              alignment: AlignmentDirectional.bottomCenter,
                                              children: <Widget>[              
                                                const Image(
                                                  image: AssetImage("lib/app_control_obra/sources/calendario.png",),
                                                  width: 50,
                                                  ),
                                                Text(
                                                  "${menu3Provider.date.day}",
                                                  style: const TextStyle( fontSize: 30 ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                          Container(//CONTENEDOR DE TEXTO
                                            padding: const EdgeInsets.only(left: 20, right: 20, top: 1, bottom: 2),
                                            decoration: const BoxDecoration(
                                              color: Colors.transparent,
                                              border:  Border(
                                                top: BorderSide( color: Colors.black ),
                                                bottom: BorderSide( color: Colors.black ),
                                                right: BorderSide( color: Colors.black ),
                                              )
                                            ),
                                            child: Text(
                                              DateFormat('MMM').format(menu3Provider.date) == 'Jan' ? 'Enero' : 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Feb' ? 'Febrero' :
                                              DateFormat('MMM').format(menu3Provider.date) == 'Mar' ? 'Marzo': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Apr' ? 'Abril': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'May' ? 'Mayo' : 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Jun' ? 'Junio': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Jul' ? 'Julio':
                                              DateFormat('MMM').format(menu3Provider.date) == 'Aug' ? 'Agosto':
                                              DateFormat('MMM').format(menu3Provider.date) == 'Sep' ? 'Septiembre': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Oct' ? 'Octubre':
                                              DateFormat('MMM').format(menu3Provider.date) == 'Nov' ? 'Noviembre': 
                                              DateFormat('MMM').format(menu3Provider.date) == 'Dec' ? 'Diciembre':
                                              '',
                                              //"${menu1Provider.date.day}-${menu1Provider.date.month}-${menu1Provider.date.year}",
                                              style: GoogleFonts.quicksand(
                                                  color: const Color.fromARGB(255, 35, 35, 35),
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                          )
                                        ],
                                      ),
                                  ),
                                ),

                const SizedBox(height: 30,),

                Center(//TEXTO
                              child: Padding(
                              padding: const EdgeInsets.only(left: 40, right: 40),
                              child: Text(
                                "${widget.ordenTrabajo} - ${widget.proyecto}",
                                style: GoogleFonts.quicksand(
                                  color: const Color.fromARGB(255, 0, 77, 150),
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  decoration: TextDecoration.underline
                                  ),
                                ),
                              ),
                            ),
                
                const SizedBox(height: 30,),

                GestureDetector(//BOTON PARA AGREGAR ACTIVIDAD
                  onTap: () {
                    menu3Provider.cambiarFormulario();
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children:  <Widget> [
                      Text(
                        "Agregar actividades",
                        style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 29, 28, 28),
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700,
                                      )),
                      Container( //CONTENEDOR DEL ICONO
                            padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color.fromARGB(255, 242, 103, 34)
                              ) ,
                              child: const Icon( //ICONO
                              size: 25,
                              FontAwesomeIcons.plus, 
                              color: Color.fromARGB(255, 255, 255, 255),
                            ),
                          ),
                    ],
                  ),
                ),

                const SizedBox(height: 30,),

                Expanded(//LISTA DE TARJETAS
                  child: ListView(
                    children: <Widget>[
                      
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: Card(
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                            side: BorderSide(
                              color: Color.fromARGB(255, 242, 158, 56),
                            ),
                            borderRadius:  BorderRadius.all(Radius.circular(12)),
                          ),
                          child:  Column(
                          
                          children: [

                              Padding(//TITULO E ICONO DE LA TARJETA
                                padding:const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(//TEXTO
                                      "125 - Cunetas",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        )
                                      ),
                                    const Icon(//ICONO
                                      FontAwesomeIcons.trash,
                                      color: Colors.amber,)
                                  ],
                                ), 
                              ),

                              Padding(//DESCRIPCION
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO DESCRIPCION
                                      "Descripción:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DESCRIPCION
                                      child: Text(
                                      "Se realiza excavación hasta las 6 de la tarde, prueba de tarjeta.",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//CANTIDAD EJECUTADA
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO CANTIDAD EJECUTADA
                                      "Cantidad ejecutada:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO de la cantidad
                                      child: Text(
                                      "20 m3",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA INICIAL
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA INICIAL
                                      "Abcisa inicial:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA
                                      child: Text(
                                      "K 0 + 440",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA FINAL
                                padding: EdgeInsets.only(left:15,top: 1, bottom: 15),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA FINAL
                                      "Abcisa final:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA FINAL
                                      child: Text(
                                      "K 0 + 470",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                          ],
                          ),
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: Card(
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                            side: BorderSide(
                              color: Color.fromARGB(255, 242, 158, 56),
                            ),
                            borderRadius:  BorderRadius.all(Radius.circular(12)),
                          ),
                          child:  Column(
                          
                          children: [

                              Padding(//TITULO E ICONO DE LA TARJETA
                                padding:const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(//TEXTO
                                      "125 - Cunetas",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        )
                                      ),
                                    const Icon(//ICONO
                                      FontAwesomeIcons.trash,
                                      color: Colors.amber,)
                                  ],
                                ), 
                              ),

                              Padding(//DESCRIPCION
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO DESCRIPCION
                                      "Descripción:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DESCRIPCION
                                      child: Text(
                                      "Se realiza excavación hasta las 6 de la tarde, prueba de tarjeta.",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//CANTIDAD EJECUTADA
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO CANTIDAD EJECUTADA
                                      "Cantidad ejecutada:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO de la cantidad
                                      child: Text(
                                      "20 m3",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA INICIAL
                                padding: EdgeInsets.only(left:15,top: 1),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA INICIAL
                                      "Abcisa inicial:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA
                                      child: Text(
                                      "K 0 + 440",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                              Padding(//ABCISA FINAL
                                padding: EdgeInsets.only(left:15,top: 1, bottom: 15),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    
                                    Text(//TITULO ABCISA FINAL
                                      "Abcisa final:",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 26, 26, 26),
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        )
                                    ),

                                    SizedBox(width: 5,),

                                    Flexible(//CUERPO DE LA ABCISA FINAL
                                      child: Text(
                                      "K 0 + 470",
                                      style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 26, 26, 26),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          )
                                      )
                                    ),
                                  ],
                                )
                              ),

                          ],
                          ),
                        ),
                      ),

                    ]
                  )
                ),

                const SizedBox(height: 20,),
              ],
            ):
            SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Padding(
                padding: const EdgeInsets.only(left: 35, right: 35, top:10, bottom: 10),
                child: Column(
                  children: [
                    Form(
                                key: keyFormularioActividades,
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        //LABEL ACTIVIDADES
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Text("Actividades",
                                            style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(
                                                    255, 8, 8, 8),
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                                height: 2)),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      Padding(
                                        //SELECT ACTIVIDADES
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          decoration: const BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(20)),
                                              boxShadow: [
                                                BoxShadow(
                                                    color: Color.fromARGB(
                                                        102, 0, 0, 0),
                                                    blurRadius: 7,
                                                    spreadRadius: 0,
                                                    offset: const Offset(0, 8))
                                              ]),
                                          child: DropdownSearch(
                                            validator: (value) {
                                              if (value == null ||
                                                  value == '') {
                                                return "Este campo es requerido";
                                              }
                                            },
                                            selectedItem:
                                                menu3Provider.nombreActividad,
                                            mode: Mode.MENU,
                                            showSearchBox: true,
                                            items: menu3Provider.allActividades,
                                            showClearButton: true,
                                            dropdownSearchDecoration:
                                                InputDecoration(
                                              filled: true,
                                              fillColor: Colors.white,
                                              border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  borderSide: BorderSide.none),
                                              hintText: 'Seleccionar actividad',
                                              hintStyle: const TextStyle(
                                                  color: Color.fromARGB(
                                                      255, 160, 159, 153),
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 16,
                                                  letterSpacing: 1.3,
                                                  fontFamily: 'quicksand'),
                                            ),
                                            onChanged: (e) {
                                              menu3Provider.asignarActividad(e);
                                            },
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                      Padding(
                                        //LABEL NOVEDADES
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Text("Novedades",
                                            style: GoogleFonts.quicksand(
                                                color: Color.fromARGB(
                                                    255, 8, 8, 8),
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                                height: 2)),
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      Padding(
                                        //INPUT NOVEDADES
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          decoration: const BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(20)),
                                              boxShadow: [
                                                BoxShadow(
                                                    color: Color.fromARGB(
                                                        102, 0, 0, 0),
                                                    blurRadius: 7,
                                                    spreadRadius: 0,
                                                    offset: const Offset(0, 8))
                                              ]),
                                          child: TextFormField(
                                            validator: (value) {
                                              if (value == null ||
                                                  value == '') {
                                                return 'Debe ingresar un valor';
                                              }
                                              return null;
                                            },
                                            initialValue: menu3Provider.novedades,
                                            onChanged: (value) {
                                              menu3Provider
                                                  .asignarNovedad(value);
                                            },
                                            maxLines: 2,
                                            keyboardType:
                                                TextInputType.multiline,
                                            style: const TextStyle(
                                                height: 1,
                                                color: Color.fromARGB(
                                                    255, 83, 82, 82),
                                                fontSize: 20,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: 1.3,
                                                fontFamily: 'quicksand'),
                                            decoration: InputDecoration(
                                                hintText:
                                                    'Describa la actividad realizada.',
                                                hintStyle: const TextStyle(
                                                    color: Color.fromARGB(
                                                        255, 160, 159, 153),
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'),
                                                //labelText: 'Usuario',
                                                //floatingLabelBehavior: FloatingLabelBehavior.always,
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    borderSide:
                                                        BorderSide.none),
                                                filled: true,
                                                fillColor: Colors.white,
                                                errorBorder: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    borderSide: const BorderSide(
                                                        color: Color.fromARGB(
                                                            255, 255, 0, 0),
                                                        width: 2)),
                                                errorStyle: const TextStyle(
                                                    color: Color.fromARGB(
                                                        255, 255, 0, 0),
                                                    letterSpacing: 2.2,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15)),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 20),
                                      Padding(
                                        //UNIDAD DE MEDIDA
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 5),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              "Unidad de medida:",
                                              style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(
                                                    255, 51, 52, 53),
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              "m3",
                                              style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(
                                                    255, 1, 92, 177),
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 20),
                                      Padding(
                                        //CANTIDAD EJECUTADA
                                        padding: EdgeInsets.only(left: 0),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: <Widget>[
                                            Text(
                                              //CANTIDAD EJECUTADA
                                              "Cantidad ejecutada:",
                                              style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(
                                                    255, 51, 52, 53),
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                            Padding(
                                              //INPUT CANTIDAD
                                              padding: const EdgeInsets.all(0),
                                              child: Container(
                                                decoration: const BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                20)),
                                                    boxShadow: [
                                                      BoxShadow(
                                                          color: Color.fromARGB(
                                                              102, 0, 0, 0),
                                                          blurRadius: 7,
                                                          spreadRadius: 0,
                                                          offset: const Offset(
                                                              0, 8))
                                                    ]),
                                                child: SizedBox(
                                                  width: 100,
                                                  child: TextFormField(
                                                    validator: (value) {
                                                      if (value == null ||
                                                          value == '') {
                                                        return 'Debe ingresar este valor.';
                                                      }
                                                      return null;
                                                    },
                                                    initialValue: menu3Provider.cantidadEjecutada.toString(),
                                                    onChanged: (value) {
                                                      menu3Provider
                                                          .asignarCantidadEjecutada(
                                                              value);
                                                    },
                                                    keyboardType:
                                                        TextInputType.number,
                                                    style: const TextStyle(
                                                        height: 1,
                                                        color: Color.fromARGB(
                                                            255, 83, 82, 82),
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        letterSpacing: 1.3,
                                                        fontFamily:
                                                            'quicksand'),
                                                    decoration: InputDecoration(
                                                        hintStyle: const TextStyle(
                                                            color: Color.fromARGB(
                                                                255, 160, 159, 153),
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            fontSize: 16,
                                                            letterSpacing: 1.3,
                                                            fontFamily:
                                                                'quicksand'),
                                                        border: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    20),
                                                            borderSide:
                                                                BorderSide
                                                                    .none),
                                                        filled: true,
                                                        fillColor: Colors.white,
                                                        errorBorder: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    20),
                                                            borderSide:
                                                                const BorderSide(
                                                                    color: Color.fromARGB(255, 255, 0, 0),
                                                                    width: 2)),
                                                        errorStyle: const TextStyle(color: Color.fromARGB(255, 255, 0, 0), letterSpacing: 2.2, fontWeight: FontWeight.w400, fontSize: 15)),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 20),
                                      Row(
                                        //ABCISAS
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Column(
                                            //ABCISA INICIAL
                                            children: [
                                              Text(
                                                  //TEXTO
                                                  "Abcisa Inicial:",
                                                  style: GoogleFonts.quicksand(
                                                      color:
                                                          const Color.fromARGB(
                                                              255, 8, 8, 8),
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      height: 2)),
                                              Padding(
                                                //INPUT
                                                padding: const EdgeInsets.only(
                                                    top: 4),
                                                child: Container(
                                                  decoration:
                                                      const BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          20)),
                                                          boxShadow: [
                                                        BoxShadow(
                                                            color:
                                                                Color.fromARGB(
                                                                    102,
                                                                    0,
                                                                    0,
                                                                    0),
                                                            blurRadius: 7,
                                                            spreadRadius: 0,
                                                            offset:
                                                                const Offset(
                                                                    0, 8))
                                                      ]),
                                                  child: SizedBox(
                                                    width: 100,
                                                    child: TextFormField(
                                                      validator: (value) {
                                                        if (value == null ||
                                                            value == '') {
                                                          return 'Debe ingresar este valor.';
                                                        }
                                                        return null;
                                                      },
                                                      onChanged: (value) {
                                                        menu3Provider
                                                            .asignarAbcisaInicial(
                                                                value);
                                                      },
                                                      initialValue: menu3Provider.abcisaInicial,
                                                      keyboardType:
                                                          TextInputType.number,
                                                      style: const TextStyle(
                                                          height: 1,
                                                          color: Color.fromARGB(
                                                              255, 83, 82, 82),
                                                          fontSize: 20,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          letterSpacing: 1.3,
                                                          fontFamily:
                                                              'quicksand'),
                                                      decoration: InputDecoration(
                                                          hintStyle: const TextStyle(
                                                              color: Color.fromARGB(
                                                                  255, 160, 159, 153),
                                                              fontWeight: FontWeight
                                                                  .w700,
                                                              fontSize: 16,
                                                              letterSpacing:
                                                                  1.3,
                                                              fontFamily:
                                                                  'quicksand'),
                                                          border: OutlineInputBorder(
                                                              borderRadius: BorderRadius.circular(
                                                                  20),
                                                              borderSide: BorderSide
                                                                  .none),
                                                          filled: true,
                                                          fillColor:
                                                              Colors.white,
                                                          errorBorder: OutlineInputBorder(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      20),
                                                              borderSide: const BorderSide(
                                                                  color: Color.fromARGB(255, 255, 0, 0),
                                                                  width: 2)),
                                                          errorStyle: const TextStyle(color: Color.fromARGB(255, 255, 0, 0), letterSpacing: 2.2, fontWeight: FontWeight.w400, fontSize: 15)),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Column(
                                            //ABCISA FINAL
                                            children: [
                                              Text(
                                                  //TEXTO
                                                  "Abcisa Final:",
                                                  style: GoogleFonts.quicksand(
                                                      color:
                                                          const Color.fromARGB(
                                                              255, 8, 8, 8),
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      height: 2)),
                                              Padding(
                                                //INPUT
                                                padding: const EdgeInsets.only(
                                                    top: 4),
                                                child: Container(
                                                  decoration:
                                                      const BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          20)),
                                                          boxShadow: [
                                                        BoxShadow(
                                                            color:
                                                                Color.fromARGB(
                                                                    102,
                                                                    0,
                                                                    0,
                                                                    0),
                                                            blurRadius: 7,
                                                            spreadRadius: 0,
                                                            offset:
                                                                const Offset(
                                                                    0, 8))
                                                      ]),
                                                  child: SizedBox(
                                                    width: 100,
                                                    child: TextFormField(
                                                      validator: (value) {
                                                        if (value == null ||
                                                            value == '') {
                                                          return 'Debe ingresar este valor.';
                                                        }
                                                        return null;
                                                      },
                                                      onChanged: (value) {
                                                        menu3Provider
                                                            .asignarAbcisaFinal(
                                                                value);
                                                      },
                                                      initialValue: menu3Provider.abcisaFinal,
                                                      keyboardType:
                                                          TextInputType.number,
                                                      style: const TextStyle(
                                                          height: 1,
                                                          color: Color.fromARGB(
                                                              255, 83, 82, 82),
                                                          fontSize: 20,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          letterSpacing: 1.3,
                                                          fontFamily:
                                                              'quicksand'),
                                                      decoration: InputDecoration(
                                                          hintStyle: const TextStyle(
                                                              color: Color.fromARGB(
                                                                  255, 160, 159, 153),
                                                              fontWeight: FontWeight
                                                                  .w700,
                                                              fontSize: 16,
                                                              letterSpacing:
                                                                  1.3,
                                                              fontFamily:
                                                                  'quicksand'),
                                                          border: OutlineInputBorder(
                                                              borderRadius: BorderRadius.circular(
                                                                  20),
                                                              borderSide: BorderSide
                                                                  .none),
                                                          filled: true,
                                                          fillColor:
                                                              Colors.white,
                                                          errorBorder: OutlineInputBorder(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      20),
                                                              borderSide: const BorderSide(
                                                                  color: Color.fromARGB(255, 255, 0, 0),
                                                                  width: 2)),
                                                          errorStyle: const TextStyle(color: Color.fromARGB(255, 255, 0, 0), letterSpacing: 2.2, fontWeight: FontWeight.w400, fontSize: 15)),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 20),
                                      Row(
                                        //CARGAR IMAGENES
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Text(
                                              //TEXTO
                                              "Cargar imagen",
                                              style: GoogleFonts.quicksand(
                                                  color: Color.fromARGB(
                                                      255, 8, 8, 8),
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w500,
                                                  height: 2)),
                                          TextButton(
                                            //BOTON PARA MOSTRAR UNA MODAL DONDE ESCAJA LA FORMA DE ADJUNTAR UN DOCUMENTO
                                            onPressed: () {
                                              showModalBottomSheet(
                                                  //MODAL QUE SE MUESTRA DE LA PARTE INFERIOR
                                                  backgroundColor:
                                                      Color.fromARGB(
                                                          255, 255, 255, 255),
                                                  //barrierColor: Colors.amber,
                                                  shape: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide:
                                                          BorderSide.none),
                                                  context: context,
                                                  builder:
                                                      (BuildContext context) {
                                                    return Container(
                                                      //color: Color.fromARGB(36, 255, 255, 255),
                                                      height: 150,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          Column(
                                                            //BOTON DE LA CAMARA
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Container(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .all(
                                                                        15.0),
                                                                child: Icon(
                                                                  FontAwesomeIcons
                                                                      .camera,
                                                                  size: 30,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                                decoration: const BoxDecoration(
                                                                    color: Color
                                                                        .fromARGB(
                                                                            213,
                                                                            10,
                                                                            143,
                                                                            192),
                                                                    shape: BoxShape
                                                                        .circle),
                                                              ),
                                                              Text("Camara",
                                                                  style: GoogleFonts.quicksand(
                                                                      color: Color
                                                                          .fromARGB(
                                                                              255,
                                                                              8,
                                                                              8,
                                                                              8),
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      height:
                                                                          2))
                                                            ],
                                                          ),
                                                          Column(
                                                            //BOTON DE ADJUNTAR ARCHIVO
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Container(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .all(
                                                                        15.0),
                                                                child: Icon(
                                                                  FontAwesomeIcons
                                                                      .file,
                                                                  size: 30,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                                decoration: const BoxDecoration(
                                                                    color: Color
                                                                        .fromARGB(
                                                                            211,
                                                                            189,
                                                                            138,
                                                                            28),
                                                                    shape: BoxShape
                                                                        .circle),
                                                              ),
                                                              Text("Documento",
                                                                  style: GoogleFonts.quicksand(
                                                                      color: Color
                                                                          .fromARGB(
                                                                              255,
                                                                              8,
                                                                              8,
                                                                              8),
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      height:
                                                                          2))
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  });
                                            },
                                            child: Container(
                                              //CONTENEDOR DEL ICONO
                                              padding: const EdgeInsets.all(10),
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: Color.fromARGB(
                                                      255, 242, 103, 34)),
                                              child: const Icon(
                                                //ICONO
                                                size: 25,
                                                FontAwesomeIcons
                                                    .arrowUpFromBracket,
                                                color: Color.fromARGB(
                                                    255, 255, 255, 255),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                      Column(
                                        //ARCHIVOS ADJUNTOS
                                        children: [
                                          Padding(
                                            //NOMBRE DE LAS IMAGENES
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Text(
                                                  "Imagen_de_excavacion1.png",
                                                  style: GoogleFonts.quicksand(
                                                    color: const Color.fromARGB(
                                                        255, 0, 77, 150),
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                                const Icon(
                                                  FontAwesomeIcons.xmark,
                                                  color: Color.fromARGB(
                                                      255, 0, 77, 150),
                                                )
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            //NOMBRE DE LAS IMAGENES
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Text(
                                                  "Imagen_de_excavacion1.png",
                                                  style: GoogleFonts.quicksand(
                                                    color: const Color.fromARGB(
                                                        255, 0, 77, 150),
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                                const Icon(
                                                  FontAwesomeIcons.xmark,
                                                  color: Color.fromARGB(
                                                      255, 0, 77, 150),
                                                )
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            //NOMBRE DE LAS IMAGENES
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Text(
                                                  "Imagen_de_excavacion1.png",
                                                  style: GoogleFonts.quicksand(
                                                    color: const Color.fromARGB(
                                                        255, 0, 77, 150),
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                                const Icon(
                                                  FontAwesomeIcons.xmark,
                                                  color: Color.fromARGB(
                                                      255, 0, 77, 150),
                                                )
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 10),
                                    ]
                                  )
                          ),
                    Form(
                                  key: keyFormularioInsumosActividades,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                  
                                      Padding(//LABEL INSUMOS
                                          padding:const EdgeInsets.only(left: 0),
                                          child: Text(
                                            "Insumos",
                                            style: GoogleFonts.quicksand(
                                              color: Color.fromARGB(255, 8, 8, 8),
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500,
                                              height: 2
                                              )
                                            ),
                                        ),
                    
                                      const SizedBox(height: 5,),
                                      
                                      Padding( //SELECT INSUMOS
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          
                                            decoration: const  BoxDecoration(
                                            borderRadius: BorderRadius.all(Radius.circular(20)),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(102, 0, 0, 0),
                                                blurRadius: 7,
                                                spreadRadius: 0,
                                                offset: const Offset(0, 8)
                                              )
                                            ]
                                          ),
                                          child: DropdownSearch(
                                                selectedItem: menu3Provider.nombreInsumo,
                                                mode : Mode.MENU,
                                                showSearchBox: true,
                                                items: menu3Provider.allInsumos,
                                                showClearButton: true,
                                                dropdownSearchDecoration:  InputDecoration(
                                                  filled: true,
                                                  fillColor: Colors.white,
                                                  border:OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide.none
                                                  ),
                                                  hintText: 'Seleccionar insumos',
                                                  hintStyle: const TextStyle(
                                                    color: Color.fromARGB(255, 160, 159, 153),
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                  ),
                                                ),
                                                validator: (value) {
                                                  if(value == null || value == ''){
                                                    return "Campo requerido";
                                                  }
                                                  return null;
                                                },
                                                onChanged: (value) {
                                                  menu3Provider.asignarInsumo(value);
                                                },
                                              ),
                                        ),
                                        ),
                    
                                      const SizedBox(height: 10),
                                      
                                      Padding(//LABEL ORIGEN
                                          padding:const EdgeInsets.only(left: 0),
                                          child: Text(
                                            "Origen",
                                            style: GoogleFonts.quicksand(
                                              color: Color.fromARGB(255, 8, 8, 8),
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500,
                                              height: 2
                                              )
                                            ),
                                        ),
                    
                                      const SizedBox(height: 5,),
                                      
                                      Padding( //SELECT ORIGEN
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          
                                            decoration: const  BoxDecoration(
                                            borderRadius: BorderRadius.all(Radius.circular(20)),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(102, 0, 0, 0),
                                                blurRadius: 7,
                                                spreadRadius: 0,
                                                offset: const Offset(0, 8)
                                              )
                                            ]
                                          ),
                                          child: DropdownSearch(
                                                selectedItem: menu3Provider.nombreOrigen,
                                                mode : Mode.MENU,
                                                showSearchBox: true,
                                                items: menu3Provider.allOrigen,
                                                showClearButton: true,
                                                dropdownSearchDecoration:  InputDecoration(
                                                  filled: true,
                                                  fillColor: Colors.white,
                                                  border:OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide.none
                                                  ),
                                                  hintText: 'Seleccionar origen de insumo',
                                                  hintStyle: const TextStyle(
                                                    color: Color.fromARGB(255, 160, 159, 153),
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                  ),
                                                ),
                                                validator: (value) {
                                                  if(value == null || value ==''){
                                                    return "Campo requerido";
                                                  }
                                                  return null;
                                                },
                                                onChanged: (e) {
                                                  menu3Provider.asignarOrigen(e);
                                                },
                                              ),
                                        ),
                                        ),
            
                                      const SizedBox(height: 30,),

                                      Row(//CANTIDAD
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: <Widget> [
                    
                                            Text(//TEXTO CANTIDAD
                                              "Cantidad:",
                                              style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(255, 51, 52, 53),
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                ),
                                            ),
                    
                                            Padding(//INPUT CANTIDAD
                                            padding: const EdgeInsets.all(0),
                                            child: Container(
                                              decoration: const  BoxDecoration(
                                                borderRadius: BorderRadius.all(Radius.circular(20)),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color.fromARGB(102, 0, 0, 0),
                                                    blurRadius: 7,
                                                    spreadRadius: 0,
                                                    offset: const Offset(0, 8)
                                                  )
                                                ]
                                              ),
                                              child: SizedBox(
                                                width: 100,
                                                child: TextFormField(
                                                  validator: (value){
                                                    if(value == null || value ==''){
                                                      return 'Debe ingresar este valor.';
                                                    }
                                                    return null;
                                                  },
                                                  onChanged: (value) {
                                                    menu3Provider.asignarCantidad(value);
                                                  },
                                                  initialValue: menu3Provider.cantidad.toString(),
                                                  keyboardType: TextInputType.number,
                                                  style:  const  TextStyle(
                                                    height:1,
                                                    color:  Color.fromARGB(255, 83, 82, 82), 
                                                    fontSize: 20, 
                                                    fontWeight: FontWeight.w700,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                    ),
                                                  decoration:  InputDecoration(
                                                    hintStyle: const TextStyle(
                                                      color: Color.fromARGB(255, 160, 159, 153),
                                                      fontWeight: FontWeight.w700,
                                                      fontSize: 16,
                                                      letterSpacing: 1.3,
                                                      fontFamily: 'quicksand'
                                                    ),
                                                    border:  OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(20),
                                                      borderSide: BorderSide.none
                                                    ),
                                                    filled: true,
                                                    fillColor: Colors.white,
                                                    errorBorder: OutlineInputBorder(
                                                        borderRadius: BorderRadius.circular(20),
                                                        borderSide: const BorderSide(
                                                        color: Color.fromARGB(255, 255, 0, 0),
                                                        width: 2
                                                      )
                                                    ) ,
                                                    errorStyle: const TextStyle( 
                                                      color: Color.fromARGB(255, 255, 0, 0),
                                                      letterSpacing: 2.2,
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 15
                                                      )
                                                    ),
                                                  ),
                                              ),
                                            ),
                                            ),

                                            TextButton(//BOTON AGREGAR CANTIDAD
                                            onPressed: (){ 
                                              
                                              if(keyFormularioInsumosActividades.currentState!.validate()){
                                                menu3Provider.agregarInsumo();
                                                //menu3Provider.reiniciarFormularioInsumos();
                                                keyFormularioInsumosActividades.currentState!.reset();
                                              }                       
                                            }, 
                                            child: Container( //CONTENEDOR DEL ICONO
                                                padding: const EdgeInsets.all(10),
                                                  decoration: const BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: Color.fromARGB(255, 242, 103, 34)
                                                  ) ,
                                                  child: const Icon( //ICONO
                                                  size: 25,
                                                  FontAwesomeIcons.plus, 
                                                  color: Color.fromARGB(255, 255, 255, 255),
                                                ),
                                              ),
                                            )
      
                                          ],
                                        ),
      
                                    ],
                                  )
                                ),

                          const SizedBox(height: 30,),

                          const Divider(//LINEA DIVISORA
                                    color: Colors.black,
                                    height: 1,
                                  ),
                                  
                          const SizedBox(height: 30,),

                          Padding(//TEXTO DE INSUMOS AGREGADOS
                                  padding: EdgeInsets.only(left: 1),
                                  child: Text(
                                    "Insumos agregados:",
                                    style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 33, 109, 184),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          ),
                                  ),
                                ),

                          const SizedBox(height: 20,),

                          Column(//INSUMOS AGREGADOS
                                  children: menu3Provider.listaInsumos.map((item) => tarjetaIsumos(item)).toList(),
                          ),


                          const SizedBox(height: 10,),

                          Center(//BOTON GUARDAR
                                  child: TextButton( // BOTON
                                    onPressed: (){
                                      menu3Provider.cambiarFormulario();
                                    } ,
                                    child: Text(//TEXTO DEL BOTON
                                      "Guardar", 
                                      style: GoogleFonts.quicksand(
                                          color: const Color.fromARGB(255, 255, 255, 255),
                                          fontSize: 17,
                                          fontWeight: FontWeight.w700,
                                        ), 
                                    ),
                                    style: ButtonStyle( //ESTILOS DEL BOTON
                                      side: MaterialStateProperty.all( 
                                        const BorderSide(
                                        width: 1,
                                        color: Color.fromARGB(13, 0, 0, 0),
                                        ),
                                      ),
                                    shape: MaterialStateProperty.all(
                                                    RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.circular(100)
                                                    )
                                                  ),
                                      elevation: MaterialStateProperty.all(10),
                                      padding: MaterialStateProperty.all( const EdgeInsets.only( top: 0, bottom: 0 , right: 40, left: 40)),
                                      backgroundColor: MaterialStateProperty.all(const Color.fromARGB(255, 242, 103, 34))
                                    ),
                                  )
                                ),




                  ],
                ),
              )
          )
           */
        ),

      
    );
  }


}

Future alerta(BuildContext context){//MODAL QUE AGREGA UNA NUEVA ACTIVIDAD

    final menu3Provider = Provider.of<Menu3Provider>(context, listen: false);
    

    final keyFormulario = GlobalKey<FormState>();
    final keyFormularioInsumos = GlobalKey<FormState>();
    var homeController = RutasController();

    return showDialog( //MODAL PARA AGREGAR ACTIVIDADES
      context: context,
      barrierDismissible: false,
      builder: (context) {

        return AlertDialog(
                  shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(15.0))),
                  scrollable : true,
                  content: SizedBox(
                    width: 300.0,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
              
                        children: <Widget>[ 
                          Row(//BOTON PARA CERRAR MODAL
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget> [
                        
                              GestureDetector(//BOTON PARA CERRAR MODAL
                                onTap: (){ 
                                  homeController.volverPagina(context);
                                  menu3Provider.reiniciarTodosFormulario();
                                  keyFormulario.currentState!.reset();
                                  keyFormularioInsumos.currentState!.reset();
                                },
                                child: const Icon(
                                    size: 25,
                                    FontAwesomeIcons.xmark, 
                                    color: Color.fromARGB(185, 0, 0, 0)
                                  ),
                              )
                        
                            ],
                          ),
              
                          Form(//FORMULARIO DE ACTIVIDADES
                            key:keyFormulario,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
              
                                Padding(//LABEL ACTIVIDADES
                                    padding:const EdgeInsets.only(left: 0),
                                    child: Text(
                                      "Actividades",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 8, 8, 8),
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        height: 2
                                        )
                                      ),
                                  ),
              
                                const SizedBox(height: 5,),
                                
                                Padding( //SELECT ACTIVIDADES
                                  padding: const EdgeInsets.only(left: 0),
                                  child: Container(
                                    
                                      decoration: const  BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(20)),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color.fromARGB(102, 0, 0, 0),
                                          blurRadius: 7,
                                          spreadRadius: 0,
                                          offset: const Offset(0, 8)
                                        )
                                      ]
                                    ),
                                    child: DropdownSearch(
                                          validator: (value) {
                                            if(value == null || value == ''){
                                              return "Este campo es requerido";
                                            }
                                          },
                                          selectedItem: menu3Provider.nombreActividad,
                                          mode : Mode.MENU,
                                          showSearchBox: true,
                                          items: menu3Provider.allActividades,
                                          showClearButton: true,
                                          dropdownSearchDecoration:  InputDecoration(
                                            filled: true,
                                            fillColor: Colors.white,
                                            border:OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              borderSide: BorderSide.none
                                            ),
                                            hintText: 'Seleccionar actividad',
                                            hintStyle: const TextStyle(
                                              color: Color.fromARGB(255, 160, 159, 153),
                                              fontWeight: FontWeight.w700,
                                              fontSize: 16,
                                              letterSpacing: 1.3,
                                              fontFamily: 'quicksand'
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(10),
                                                borderSide: const BorderSide(
                                                color: Color.fromARGB(255, 255, 0, 0),
                                                width: 2
                                              )
                                            ) ,
                                            errorStyle: const TextStyle( 
                                              color: Color.fromARGB(255, 255, 0, 0),
                                              letterSpacing: 2.2,
                                              fontWeight: FontWeight.w400,
                                              fontSize: 15
                                              )
                                          ),
                                          
                                          onChanged: (e) {
                                            menu3Provider.asignarActividad(e);
                                          },
                                        ),
                                  ),
                                  ),
              
                                const SizedBox(height: 8,),
                                
                                Padding(//LABEL DESCRIPCION DE ACTIVIDADES
                                  padding:const EdgeInsets.only(left: 0),
                                  child: Text(
                                    "Descripción",
                                    style: GoogleFonts.quicksand(
                                      color: Color.fromARGB(255, 8, 8, 8),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                      height: 2
                                      )
                                    ),
                                ),
              
                                const SizedBox(height: 5,),
              
                                Padding(//INPUT DESCRIPCION DE ACTIVIDADES
                                padding: const EdgeInsets.only( left: 0),
                                child: Container(
                                  decoration: const  BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.circular(20)),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color.fromARGB(102, 0, 0, 0),
                                        blurRadius: 7,
                                        spreadRadius: 0,
                                        offset: const Offset(0, 8)
                                      )
                                    ]
                                  ),
                                  child: TextFormField(
                                    validator: (value){
                                      if(value == null || value==''){
                                        return 'Debe ingresar un valor';
                                      }
                                      return null;
                                    },
                                    initialValue: menu3Provider.novedades,
                                    onChanged: (value) {
                                      menu3Provider.asignarNovedad(value);
                                    },
                                    maxLines: 2,
                                    keyboardType: TextInputType.multiline,
                                    style:  const  TextStyle(
                                      height:1,
                                      color:  Color.fromARGB(255, 83, 82, 82), 
                                      fontSize: 20, 
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 1.3,
                                      fontFamily: 'quicksand'
                                      ),
                                    decoration:  InputDecoration(
                                      hintText: 'Describa la actividad realizada.',
                                      hintStyle: const TextStyle(
                                        color: Color.fromARGB(255, 160, 159, 153),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                        letterSpacing: 1.3,
                                        fontFamily: 'quicksand'
                                      ),
                                      //labelText: 'Usuario',
                                      //floatingLabelBehavior: FloatingLabelBehavior.always,
                                      border:  OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide.none
                                      ),
                                      filled: true,
                                      fillColor: Colors.white,
                                      errorBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10),
                                          borderSide: const BorderSide(
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          width: 2
                                        )
                                      ) ,
                                      errorStyle: const TextStyle( 
                                        color: Color.fromARGB(255, 255, 0, 0),
                                        letterSpacing: 2.2,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 15
                                        )
                                      ),
                                    ),
                                ),
                                ),
              
                                const SizedBox(height: 20),
              
                                Padding(//UNIDAD DE MEDIDA
                                  padding:const EdgeInsets.symmetric(horizontal: 5),
                                  child: Row(
                                    mainAxisAlignment:MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        "Unidad de medida:",
                                        style: GoogleFonts.quicksand(
                                          color: const Color.fromARGB(255, 51, 52, 53),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          ),
                                      ),
                                      const SizedBox(width: 10,),
                                      Text(
                                        "m3",
                                        style: GoogleFonts.quicksand(
                                          color: const Color.fromARGB(255, 1, 92, 177),
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          ),
                                      )
                                    ],
                                  ),
                                  
                                  ),
              
              
                                const SizedBox(height: 20),
              
                                Padding(//CANTIDAD EJECUTADA
                                  padding: EdgeInsets.only(left: 0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: <Widget> [
              
                                      Text(//CANTIDAD EJECUTADA
                                        "Cantidad ejecutada:",
                                        style: GoogleFonts.quicksand(
                                          color: const Color.fromARGB(255, 51, 52, 53),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          ),
                                      ),
              
                                      Padding(//INPUT CANTIDAD
                                      padding: const EdgeInsets.all(0),
                                      child: Container(
                                        decoration: const  BoxDecoration(
                                          borderRadius: BorderRadius.all(Radius.circular(20)),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color.fromARGB(102, 0, 0, 0),
                                              blurRadius: 7,
                                              spreadRadius: 0,
                                              offset: const Offset(0, 8)
                                            )
                                          ]
                                        ),
                                        child: SizedBox(
                                          width: 100,
                                          child: TextFormField(
                                            validator: (value){
                                              if(value == null || value ==''){
                                                return 'Debe ingresar este valor.';
                                              }
                                              return null;
                                            },
                                            initialValue: menu3Provider.cantidadEjecutada.toString(),
                                            onChanged: (value) {
                                              menu3Provider.asignarCantidadEjecutada(value);
                                            },
                                            keyboardType: TextInputType.number,
                                            style:  const  TextStyle(
                                              height:1,
                                              color:  Color.fromARGB(255, 83, 82, 82), 
                                              fontSize: 20, 
                                              fontWeight: FontWeight.w700,
                                              letterSpacing: 1.3,
                                              fontFamily: 'quicksand'
                                              ),
                                            decoration:  InputDecoration(
                                              hintStyle: const TextStyle(
                                                color: Color.fromARGB(255, 160, 159, 153),
                                                fontWeight: FontWeight.w700,
                                                fontSize: 16,
                                                letterSpacing: 1.3,
                                                fontFamily: 'quicksand'
                                              ),
                                              border:  OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(20),
                                                borderSide: BorderSide.none
                                              ),
                                              filled: true,
                                              fillColor: Colors.white,
                                              errorBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: const BorderSide(
                                                  color: Color.fromARGB(255, 255, 0, 0),
                                                  width: 2
                                                )
                                              ) ,
                                              errorStyle: const TextStyle( 
                                                color: Color.fromARGB(255, 255, 0, 0),
                                                letterSpacing: 2.2,
                                                fontWeight: FontWeight.w400,
                                                fontSize: 15
                                                )
                                              ),
                                            ),
                                        ),
                                      ),
                                      ),
              
                                    ],
                                  ),
                                ),
                                
                                const SizedBox(height: 20),
              
                                Row(//ABCISAS
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
              
                                    Column(//ABCISA INICIAL
                                      children: [
              
                                        Text(//TEXTO
                                          "Abcisa Inicial:",
                                          style: GoogleFonts.quicksand(
                                            color: const Color.fromARGB(255, 8, 8, 8),
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                            height: 2
                                            )
                                          ),
              
                                        Padding(//INPUT
                                          padding: const EdgeInsets.only( top:4),
                                          child: Container(
                                            decoration: const  BoxDecoration(
                                              borderRadius: BorderRadius.all(Radius.circular(20)),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color.fromARGB(102, 0, 0, 0),
                                                  blurRadius: 7,
                                                  spreadRadius: 0,
                                                  offset: const Offset(0, 8)
                                                )
                                              ]
                                            ),
                                            child: SizedBox(
                                              width: 100,
                                              child: TextFormField(
                                                validator: (value){
                                                  if(value == null || value ==''){
                                                    return 'Debe ingresar este valor.';
                                                  }
                                                  return null;
                                                },
                                                initialValue: menu3Provider.abcisaInicial,
                                                onChanged: (value) {
                                                  menu3Provider.asignarAbcisaInicial(value);
                                                },
                                                keyboardType: TextInputType.text,
                                                style:  const  TextStyle(
                                                  height:1,
                                                  color:  Color.fromARGB(255, 83, 82, 82), 
                                                  fontSize: 20, 
                                                  fontWeight: FontWeight.w700,
                                                  letterSpacing: 1.3,
                                                  fontFamily: 'quicksand'
                                                  ),
                                                decoration:  InputDecoration(
                                                  hintStyle: const TextStyle(
                                                    color: Color.fromARGB(255, 160, 159, 153),
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                  ),
                                                  border:  OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(20),
                                                    borderSide: BorderSide.none
                                                  ),
                                                  filled: true,
                                                  fillColor: Colors.white,
                                                  errorBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(20),
                                                      borderSide: const BorderSide(
                                                      color: Color.fromARGB(255, 255, 0, 0),
                                                      width: 2
                                                    )
                                                  ) ,
                                                  errorStyle: const TextStyle( 
                                                    color: Color.fromARGB(255, 255, 0, 0),
                                                    letterSpacing: 2.2,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15
                                                    )
                                                  ),
                                                ),
                                            ),
                                          ),
                                        ),
              
                                      ],
                                    ),
              
                                    Column(//ABCISA FINAL
                                      children: [
              
                                        Text(//TEXTO
                                          "Abcisa Final:",
                                          style: GoogleFonts.quicksand(
                                            color: const Color.fromARGB(255, 8, 8, 8),
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                            height: 2
                                            )
                                          ),
              
                                        Padding(//INPUT
                                          padding: const EdgeInsets.only( top:4),
                                          child: Container(
                                            decoration: const  BoxDecoration(
                                              borderRadius: BorderRadius.all(Radius.circular(20)),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color.fromARGB(102, 0, 0, 0),
                                                  blurRadius: 7,
                                                  spreadRadius: 0,
                                                  offset: const Offset(0, 8)
                                                )
                                              ]
                                            ),
                                            child: SizedBox(
                                              width: 100,
                                              child: TextFormField(
                                                validator: (value){
                                                  if(value == null || value == ''){
                                                    return 'Debe ingresar este valor.';
                                                  }
                                                  return null;
                                                },
                                                initialValue: menu3Provider.abcisaFinal,
                                                onChanged: (value) {
                                                  menu3Provider.asignarAbcisaFinal(value);
                                                },
                                                keyboardType: TextInputType.text,
                                                style:  const  TextStyle(
                                                  height:1,
                                                  color:  Color.fromARGB(255, 83, 82, 82), 
                                                  fontSize: 20, 
                                                  fontWeight: FontWeight.w700,
                                                  letterSpacing: 1.3,
                                                  fontFamily: 'quicksand'
                                                  ),
                                                decoration:  InputDecoration(
                                                  hintStyle: const TextStyle(
                                                    color: Color.fromARGB(255, 160, 159, 153),
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                  ),
                                                  border:  OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(20),
                                                    borderSide: BorderSide.none
                                                  ),
                                                  filled: true,
                                                  fillColor: Colors.white,
                                                  errorBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(20),
                                                      borderSide: const BorderSide(
                                                      color: Color.fromARGB(255, 255, 0, 0),
                                                      width: 2
                                                    )
                                                  ) ,
                                                  errorStyle: const TextStyle( 
                                                    color: Color.fromARGB(255, 255, 0, 0),
                                                    letterSpacing: 2.2,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15
                                                    )
                                                  ),
                                                ),
                                            ),
                                          ),
                                        ),
              
                                      ],
                                    ),
              
                                  ],
              
                                ),
              
                                const SizedBox(height: 20),
              
                                Row(//CARGAR IMAGEN-1
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
              
                                    Text(//TEXTO
                                      "Cargar primera imagen",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 8, 8, 8),
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        height: 2
                                      )
                                    ),
              
                                    TextButton(//BOTON PARA MOSTRAR UNA MODAL DONDE ESCAJA LA FORMA DE ADJUNTAR UN DOCUMENTO
                                      onPressed: (){

                                        showModalBottomSheet(//MODAL QUE SE MUESTRA DE LA PARTE INFERIOR
                                          backgroundColor: Color.fromARGB(255, 255, 255, 255),
                                          //barrierColor: Colors.amber,
                                          shape: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              borderSide: BorderSide.none
                                            ),
                                          context: context, 
                                          builder: (BuildContext context){
                                            return Container(
                                              //color: Color.fromARGB(36, 255, 255, 255),
                                              height: 150,
                                              child: Row(
                                                
                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                children: [

                                                  Column(//BOTON DE LA CAMARA
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [

                                                      GestureDetector(
                                                        onTap: ()async{ 
                                                          var resultado1 = await menu3Provider.seleccionarImagen1(0, context); 
                                                          if (resultado1) {
                                                            //alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos,true);
                                                            homeController.volverPagina(context);
                                                            alerta(context);
                                                          }else{
                                                            alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos.toString(),false);
                                                          }
                                                        }, 
                                                        child: Container(
                                                            padding: const EdgeInsets.all(15.0),
                                                            child: Icon(FontAwesomeIcons.camera , size: 30, color: Colors.white,),
                                                            
                                                            decoration: const BoxDecoration(
                                                              color: Color.fromARGB(213, 10, 143, 192),
                                                              shape: BoxShape.circle
                                                            ),
                                                            
                                                          ),
                                                      ),
                                                      Text(
                                                        "Camara",
                                                        style: GoogleFonts.quicksand(
                                                            color: Color.fromARGB(255, 8, 8, 8),
                                                            fontSize: 14,
                                                            fontWeight: FontWeight.w500,
                                                            height: 2
                                                          )
                                                        )
                                                    ],
                                                  ),

                                                  Column(//BOTON DE ADJUNTAR ARCHIVO
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [

                                                      GestureDetector(
                                                        onTap: ()async{ 
                                                          var resultado1 = await menu3Provider.seleccionarImagen1(1, context); 
                                                          if (resultado1) {
                                                            //alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos,true);
                                                            homeController.volverPagina(context);
                                                            alerta(context);
                                                          }else{
                                                            alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos.toString(),false);
                                                          }
                                                        }, 
                                                        child: Container(
                                                            padding: const EdgeInsets.all(15.0),
                                                            child: Icon(FontAwesomeIcons.file , size: 30, color: Colors.white,),
                                                            
                                                            decoration: const BoxDecoration(
                                                              color: Color.fromARGB(211, 189, 138, 28),
                                                              shape: BoxShape.circle
                                                            ),
                                                            
                                                          ),
                                                      ),
                                                      
                                                      Text(
                                                        "Documento",
                                                        style: GoogleFonts.quicksand(
                                                            color: Color.fromARGB(255, 8, 8, 8),
                                                            fontSize: 14,
                                                            fontWeight: FontWeight.w500,
                                                            height: 2
                                                          )
                                                        )

                                                    ],
                                                  ),
                                                  
                                                ],
                                              ),
                                            );
                                          });
                                        
                                      }, 
                                      child: Container( //CONTENEDOR DEL ICONO
                                          padding: const EdgeInsets.all(10),
                                            decoration: const BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Color.fromARGB(255, 242, 103, 34)
                                            ) ,
                                            child: const Icon( //ICONO
                                            size: 15,
                                            FontAwesomeIcons.arrowUpFromBracket, 
                                            color: Color.fromARGB(255, 255, 255, 255),
                                          ),
                                        ),
                                      )
              
                                  ],
                                ),

                                if(menu3Provider.nombreImagen1.isNotEmpty)//PRIMERA IMAGEN ADJUNTADA
                                Padding(//NOMBRE DE LAS IMAGENES
                                        padding: const EdgeInsets.only( left: 5, right: 5, top: 10, bottom: 10),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                            Text(
                                              menu3Provider.nombreImagen1.toString().substring(0,10),
                                              style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(255, 0, 77, 150),
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                                ),
                                            ),
                                            GestureDetector(
                                              onTap: (){
                                                menu3Provider.eliminarImagen1();
                                                homeController.volverPagina(context);
                                                alerta(context);
                                              },
                                              child: const Icon(
                                                FontAwesomeIcons.xmark,
                                                color:  Color.fromARGB(255, 0, 77, 150),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),

                                Row(//CARGAR IMAGEN - 2
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
              
                                    Text(//TEXTO
                                      "Cargar segunda imagen ",
                                      style: GoogleFonts.quicksand(
                                        color: Color.fromARGB(255, 8, 8, 8),
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        height: 2
                                      )
                                    ),
              
                                    TextButton(//BOTON PARA MOSTRAR UNA MODAL DONDE ESCAJA LA FORMA DE ADJUNTAR UN DOCUMENTO
                                      onPressed: (){

                                        showModalBottomSheet(//MODAL QUE SE MUESTRA DE LA PARTE INFERIOR
                                          backgroundColor: Color.fromARGB(255, 255, 255, 255),
                                          //barrierColor: Colors.amber,
                                          shape: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              borderSide: BorderSide.none
                                            ),
                                          context: context, 
                                          builder: (BuildContext context){
                                            return Container(
                                              //color: Color.fromARGB(36, 255, 255, 255),
                                              height: 150,
                                              child: Row(
                                                
                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                children: [

                                                  Column(//BOTON DE LA CAMARA
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [

                                                      GestureDetector(
                                                        onTap: ()async{ 
                                                          var resultado2 = await menu3Provider.seleccionarImagen2(0, context); 
                                                          if (resultado2) {
                                                            //alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos,true);
                                                            homeController.volverPagina(context);
                                                            alerta(context);
                                                          }else{
                                                            alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos.toString(),false);
                                                          }
                                                        }, 
                                                        child: Container(
                                                            padding: const EdgeInsets.all(15.0),
                                                            child: Icon(FontAwesomeIcons.camera , size: 30, color: Colors.white,),
                                                            
                                                            decoration: const BoxDecoration(
                                                              color: Color.fromARGB(213, 10, 143, 192),
                                                              shape: BoxShape.circle
                                                            ),
                                                            
                                                          ),
                                                      ),
                                                      Text(
                                                        "Camara",
                                                        style: GoogleFonts.quicksand(
                                                            color: Color.fromARGB(255, 8, 8, 8),
                                                            fontSize: 14,
                                                            fontWeight: FontWeight.w500,
                                                            height: 2
                                                          )
                                                        )
                                                    ],
                                                  ),

                                                  Column(//BOTON DE ADJUNTAR ARCHIVO
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [

                                                      GestureDetector(
                                                        onTap: ()async{ 
                                                          var resultado2 = await menu3Provider.seleccionarImagen2(1, context); 
                                                          if (resultado2) {
                                                            //alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos,true);
                                                            homeController.volverPagina(context);
                                                            alerta(context);
                                                          }else{
                                                            alertaModal(context,menu3Provider.mensajeAdjuntoDocumentos.toString(),false);
                                                          }
                                                        },
                                                        child: Container(
                                                            padding: const EdgeInsets.all(15.0),
                                                            child: Icon(FontAwesomeIcons.file , size: 30, color: Colors.white,),
                                                            
                                                            decoration: const BoxDecoration(
                                                              color: Color.fromARGB(211, 189, 138, 28),
                                                              shape: BoxShape.circle
                                                            ),
                                                            
                                                          ),
                                                      ),
                                                      
                                                      Text(
                                                        "Documento",
                                                        style: GoogleFonts.quicksand(
                                                            color: Color.fromARGB(255, 8, 8, 8),
                                                            fontSize: 14,
                                                            fontWeight: FontWeight.w500,
                                                            height: 2
                                                          )
                                                        )

                                                    ],
                                                  ),
                                                  
                                                ],
                                              ),
                                            );
                                          });
                                        
                                      }, 
                                      child: Container( //CONTENEDOR DEL ICONO
                                          padding: const EdgeInsets.all(10),
                                            decoration: const BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Color.fromARGB(255, 242, 103, 34)
                                            ) ,
                                            child: const Icon( //ICONO
                                            size: 15,
                                            FontAwesomeIcons.arrowUpFromBracket, 
                                            color: Color.fromARGB(255, 255, 255, 255),
                                          ),
                                        ),
                                      )
              
                                  ],
                                ),

                                if(menu3Provider.nombreImagen2.isNotEmpty)//segunda imagen adjuntada
                                Padding(//NOMBRE DE LAS IMAGENES
                                        padding: const EdgeInsets.only( left: 5, right: 5, top: 10, bottom: 10),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Text(
                                              menu3Provider.nombreImagen2.toString().substring(0,10),
                                              style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(255, 0, 77, 150),
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                                ),
                                            ),
                                            GestureDetector(
                                              onTap: (){
                                                menu3Provider.eliminarImagen2();
                                                homeController.volverPagina(context);
                                                alerta(context);
                                              },
                                              child: const Icon(
                                                FontAwesomeIcons.xmark,
                                                color:  Color.fromARGB(255, 0, 77, 150),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),

                                const SizedBox(height: 10),
                                
                              ]
                            )),
                          

                          Form(//FORMULARIO PARA AGREGAR INSUMOS
                                  key: keyFormularioInsumos,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                  
                                      Padding(//LABEL INSUMOS
                                          padding:const EdgeInsets.only(left: 0),
                                          child: Text(
                                            "Insumos",
                                            style: GoogleFonts.quicksand(
                                              color: Color.fromARGB(255, 8, 8, 8),
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500,
                                              height: 2
                                              )
                                            ),
                                        ),
                    
                                      const SizedBox(height: 5,),
                                      
                                      Padding( //SELECT INSUMOS
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          
                                            decoration: const  BoxDecoration(
                                            borderRadius: BorderRadius.all(Radius.circular(20)),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(102, 0, 0, 0),
                                                blurRadius: 7,
                                                spreadRadius: 0,
                                                offset: const Offset(0, 8)
                                              )
                                            ]
                                          ),
                                          child: DropdownSearch(
                                                selectedItem: menu3Provider.nombreInsumo,
                                                mode : Mode.MENU,
                                                showSearchBox: true,
                                                items: menu3Provider.allInsumos,
                                                showClearButton: true,
                                                dropdownSearchDecoration:  InputDecoration(
                                                  filled: true,
                                                  fillColor: Colors.white,
                                                  border:OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide.none
                                                  ),
                                                  hintText: 'Seleccionar insumos',
                                                  hintStyle: const TextStyle(
                                                    color: Color.fromARGB(255, 160, 159, 153),
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                  ),
                                                  errorBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(10),
                                                      borderSide: const BorderSide(
                                                      color: Color.fromARGB(255, 255, 0, 0),
                                                      width: 2
                                                    )
                                                  ) ,
                                                  errorStyle: const TextStyle( 
                                                    color: Color.fromARGB(255, 255, 0, 0),
                                                    letterSpacing: 2.2,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15
                                                    )
                                                ),
                                                validator: (value) {
                                                  if(value == null || value == ''){
                                                    return "Campo requerido";
                                                  }
                                                  return null;
                                                },
                                                onChanged: (value) {
                                                  menu3Provider.asignarInsumo(value);
                                                },
                                              ),
                                        ),
                                        ),
                    
                                      const SizedBox(height: 10),
                                      
                                      Padding(//LABEL ORIGEN
                                          padding:const EdgeInsets.only(left: 0),
                                          child: Text(
                                            "Origen",
                                            style: GoogleFonts.quicksand(
                                              color: Color.fromARGB(255, 8, 8, 8),
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500,
                                              height: 2
                                              )
                                            ),
                                        ),
                    
                                      const SizedBox(height: 5,),
                                      
                                      Padding( //SELECT ORIGEN
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          
                                            decoration: const  BoxDecoration(
                                            borderRadius: BorderRadius.all(Radius.circular(20)),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(102, 0, 0, 0),
                                                blurRadius: 7,
                                                spreadRadius: 0,
                                                offset: const Offset(0, 8)
                                              )
                                            ]
                                          ),
                                          child: DropdownSearch(
                                                selectedItem: menu3Provider.nombreOrigen,
                                                mode : Mode.MENU,
                                                showSearchBox: true,
                                                items: menu3Provider.allOrigen,
                                                showClearButton: true,
                                                dropdownSearchDecoration:  InputDecoration(
                                                  filled: true,
                                                  fillColor: Colors.white,
                                                  border:OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide.none
                                                  ),
                                                  hintText: 'Seleccionar origen de insumo',
                                                  hintStyle: const TextStyle(
                                                    color: Color.fromARGB(255, 160, 159, 153),
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                  ),

                                                  errorBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(10),
                                                      borderSide: const BorderSide(
                                                      color: Color.fromARGB(255, 255, 0, 0),
                                                      width: 2
                                                    )
                                                  ) ,
                                                  errorStyle: const TextStyle( 
                                                    color: Color.fromARGB(255, 255, 0, 0),
                                                    letterSpacing: 2.2,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15
                                                    )
                                                ),
                                                validator: (value) {
                                                  if(value == null || value ==''){
                                                    return "Campo requerido";
                                                  }
                                                  return null;
                                                },
                                                onChanged: (e) {
                                                  menu3Provider.asignarOrigen(e);
                                                },
                                              ),
                                        ),
                                        ),
            
                                      const SizedBox(height: 30,),

                                      Row(//CANTIDAD
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: <Widget> [
                    
                                            Text(//TEXTO CANTIDAD
                                              "Cantidad:",
                                              style: GoogleFonts.quicksand(
                                                color: const Color.fromARGB(255, 51, 52, 53),
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                ),
                                            ),
                    
                                            Padding(//INPUT CANTIDAD
                                            padding: const EdgeInsets.all(0),
                                            child: Container(
                                              decoration: const  BoxDecoration(
                                                borderRadius: BorderRadius.all(Radius.circular(20)),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color.fromARGB(102, 0, 0, 0),
                                                    blurRadius: 7,
                                                    spreadRadius: 0,
                                                    offset: const Offset(0, 8)
                                                  )
                                                ]
                                              ),
                                              child: SizedBox(
                                                width: 100,
                                                child: TextFormField(
                                                  validator: (value){
                                                    if(value == null || value ==''){
                                                      return 'Debe ingresar este valor.';
                                                    }
                                                    return null;
                                                  },
                                                  initialValue: menu3Provider.cantidad.toString(),
                                                  onChanged: (value) {
                                                    menu3Provider.asignarCantidad(value);
                                                  },
                                                  keyboardType: TextInputType.number,
                                                  style:  const  TextStyle(
                                                    height:1,
                                                    color:  Color.fromARGB(255, 83, 82, 82), 
                                                    fontSize: 20, 
                                                    fontWeight: FontWeight.w700,
                                                    letterSpacing: 1.3,
                                                    fontFamily: 'quicksand'
                                                    ),
                                                  decoration:  InputDecoration(
                                                    hintStyle: const TextStyle(
                                                      color: Color.fromARGB(255, 160, 159, 153),
                                                      fontWeight: FontWeight.w700,
                                                      fontSize: 16,
                                                      letterSpacing: 1.3,
                                                      fontFamily: 'quicksand'
                                                    ),
                                                    border:  OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(20),
                                                      borderSide: BorderSide.none
                                                    ),
                                                    filled: true,
                                                    fillColor: Colors.white,
                                                    errorBorder: OutlineInputBorder(
                                                        borderRadius: BorderRadius.circular(10),
                                                        borderSide: const BorderSide(
                                                        color: Color.fromARGB(255, 255, 0, 0),
                                                        width: 2
                                                      )
                                                    ) ,
                                                    errorStyle: const TextStyle( 
                                                      color: Color.fromARGB(255, 255, 0, 0),
                                                      letterSpacing: 2.2,
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 15
                                                      )
                                                    ),
                                                  ),
                                              ),
                                            ),
                                            ),

                                            TextButton(//BOTON AGREGAR CANTIDAD
                                            onPressed: ()async{ 
                              
                                              if(keyFormularioInsumos.currentState!.validate()){
                                                menu3Provider.agregarInsumo();
                                                keyFormularioInsumos.currentState!.reset();

                                                homeController.volverPagina(context);
                                                alerta(context);
                                              }
                

                                              /* if( 
                                                menu3Provider.nombreInsumo == null ||  
                                                menu3Provider.nombreInsumo == '' ||
                                                menu3Provider.nombreOrigen == null ||
                                                menu3Provider.nombreOrigen == '' ||
                                                menu3Provider.cantidad == null ||
                                                menu3Provider.cantidad == '' ){
                                                alertaModal(context, "El insumo, el origen , y la cantidad son Requeridas.", false);
                                              }else{
                                                keyFormularioInsumos.currentState?.reset();
                                                menu3Provider.agregarInsumo();
                                              }   */                         
                                            }, 
                                            child: Container( //CONTENEDOR DEL ICONO
                                                padding: const EdgeInsets.all(10),
                                                  decoration: const BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: Color.fromARGB(255, 242, 103, 34)
                                                  ) ,
                                                  child: const Icon( //ICONO
                                                  size: 25,
                                                  FontAwesomeIcons.plus, 
                                                  color: Color.fromARGB(255, 255, 255, 255),
                                                ),
                                              ),
                                            )
      
                                          ],
                                        ),
      
                                    ],
                                  )
                                ),

                                  
                          const SizedBox(height: 30,),

                          const Divider(//LINEA DIVISORA
                                    color: Colors.black,
                                    height: 1,
                                  ),
                                  
                          const SizedBox(height: 30,),

                          Padding(//TEXTO DE INSUMOS AGREGADOS
                                  padding: EdgeInsets.only(left: 1),
                                  child: Text(
                                    "Insumos agregados:",
                                    style: GoogleFonts.quicksand(
                                          color: Color.fromARGB(255, 33, 109, 184),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          ),
                                  ),
                                ),

                          const SizedBox(height: 20,),

                          Column(//INSUMOS AGREGADOS
                                  children: menu3Provider.listaInsumos.map((item) => tarjetaIsumos(item)).toList(),
                          ),


                          const SizedBox(height: 10,),

                          Center(//BOTON GUARDAR
                                  child: TextButton( // BOTON
                                    onPressed: (){
                                      if(keyFormulario.currentState!.validate()){
                                          keyFormulario.currentState!.reset();
                                          menu3Provider.guardarActividades();
                                        }
                                    } ,
                                    child: Text(//TEXTO DEL BOTON
                                      "Guardar", 
                                      style: GoogleFonts.quicksand(
                                          color: const Color.fromARGB(255, 255, 255, 255),
                                          fontSize: 17,
                                          fontWeight: FontWeight.w700,
                                        ), 
                                    ),
                                    style: ButtonStyle( //ESTILOS DEL BOTON
                                      side: MaterialStateProperty.all( 
                                        const BorderSide(
                                        width: 1,
                                        color: Color.fromARGB(13, 0, 0, 0),
                                        ),
                                      ),
                                    shape: MaterialStateProperty.all(
                                                    RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.circular(100)
                                                    )
                                                  ),
                                      elevation: MaterialStateProperty.all(10),
                                      padding: MaterialStateProperty.all( const EdgeInsets.only( top: 0, bottom: 0 , right: 40, left: 40)),
                                      backgroundColor: MaterialStateProperty.all(const Color.fromARGB(255, 242, 103, 34))
                                    ),
                                  )
                                ),




                        ]
                      )
              
                    ),
                  
                );
  
      }
    );
  }

Future alertaModal(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_control_obra/sources/alertaOk.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( 
                  mensaje.toString(),
                  textAlign: TextAlign.justify,
                  style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0))),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

Widget tarjetaIsumos(item){
  print(item!['insumo'].toString());
  return Padding(
    padding: const EdgeInsets.symmetric( vertical:5),
      child: Row(
       mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
         Text(
          item!['insumo'].toString(),
          style: GoogleFonts.quicksand(
           color: Color.fromARGB(255, 0, 0, 0),
           fontSize: 15,
           fontWeight: FontWeight.w600,
          ),
         ),

         Text(
          item!['cantidad'].toString(),
          style: GoogleFonts.quicksand(
            color: Color.fromARGB(255, 0, 0, 0),
            fontSize: 15,
            fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
}




