
import 'package:sqflite/sqflite.dart';
//import 'package:com_gestioncombustible_app/models/ingreso_model.dart';
import 'package:path/path.dart';

class DBControlObra {

  /*
   * @crearTablaActivo
   * @funcionalidad Se encarga de crear la base de datos y la tabla activo
   */
  static Future<Database> crearBaseDatosTablas() async{
    return openDatabase(join( await getDatabasesPath(), 'contolObra.db'),
      onCreate:(db, version) {
        db.execute(
          '''
          CREATE TABLE IF NOT EXISTS reporteDiario(
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            fecha TEXT NULL,
            tiempo INTEGER NULL,
            tiempoInicial TEXT NULL,
            tiempoFinal TEXT NULL,
            nombreProyecto TEXT NULL,
            nombreOrdenTrabajo TEXT NULL,
            colaborador TEXT NULL,
            equipo TEXT NULL,
            interventorNombre TEXT NULL,
            residente TEXT NULL,
            novedades TEXT NULL,
            estadoTarjeta TEXT NULL
            );
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS actividades(
              id                INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              reporteDiarioId   INTEGER,
              actividadNombre TEXT NULL,
              actividadId     TEXT NULL,
              novedad         TEXT NULL,
              unidadMedida    TEXT NULL,
              cantidadEjecutada TEXT NULL,
              abcisaInicial TEXT NULL,
              abcisaFinal   TEXT NULL,
              imagen BLOB NULL,
              insumoNombre TEXT NULL,
              insumoId TEXT NULL,
              origenNombre TEXT NULL,
              origenId TEXT NULL,
              cantidad BLOB NULL,
              fecha TEXT NULL,
              foreign key(reporteDiarioId) references reporteDiario(id)
               )  ;
          '''
        );
        
      }, version: 1 );
  }

    /*
   *@method insertarReporteDiario
   *@funcionalidad Se encarga de insertar ReporteDiario
   */
  static Future<bool> insertarReporteDiario(
    fecha,
    tiempo,
    tiempoInicial,
    tiempoFinal,
    nombreProyecto,
    nombreOrdenTrabajo,
    colaborador,
    equipo,
    interventorNombre,
    residente,
    novedades,
    estadoTarjeta
  )async{

    Database database = await crearBaseDatosTablas();

    try {

      await database.rawInsert(
      '''INSERT INTO reporteDiario
      (
        fecha,
        tiempo,
        tiempoInicial,
        tiempoFinal,
        nombreProyecto,
        nombreOrdenTrabajo,
        colaborador,
        equipo,
        interventorNombre,
        residente,
        novedades,
        estadoTarjeta
        )
        VALUES
        (
          '$fecha',
          '$tiempo',
          '$tiempoInicial',
          '$tiempoFinal',
          '$nombreProyecto',
          '$nombreOrdenTrabajo',
          '$colaborador',
          '$equipo',
          '$interventorNombre',
          '$residente',
          '$novedades',
          '$estadoTarjeta'
          )
          ''');

        return true;
    } catch (e) {
      print(e.toString());
      return false;
      throw Exception('Falla en la consulta');
    }
  }

    /*
   *@method: obtenerReporteDiario
   *@funcionalidad: Se encarga de traer el ultimo reporte diario
   */
  static Future<List<Map<String, Object?>>> obtenerUltimoIdReporteDiario()async{
    Database database = await crearBaseDatosTablas();
    try {
      return await database.rawQuery("SELECT * FROM reporteDiario ORDER BY id DESC LIMIT 1");
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }


   /*
   *@method insertarActividades
   *@funcionalidad Se encarga de insertar actividades
   */
  static Future<void> insertarActividades(
    reporteDiarioId,
    actividadNombre,
    actividadId,
    novedad,
    unidadMedida,
    cantidadEjecutada,
    abcisaInicial,
    abcisaFinal,
    imagen,
    insumoNombre,
    insumoId,
    origenNombre,
    origenId,
    cantidad,
    fecha
  )async{

    Database database = await crearBaseDatosTablas();

    try {

      await database.rawInsert(
      '''INSERT INTO actividades
      (
        reporteDiarioId,
        actividadNombre,
        actividadId,
        novedad,
        unidadMedida,
        cantidadEjecutada,
        abcisaInicial,
        abcisaFinal,
        imagen,
        insumoNombre,
        insumoId,
        origenNombre,
        origenId,
        cantidad,
        fecha
        )
        VALUES
        (
          '$reporteDiarioId',
          '$actividadNombre',
          '$actividadId',
          '$novedad',
          '$unidadMedida',
          '$cantidadEjecutada',
          '$abcisaInicial',
          '$abcisaFinal',
          '$imagen',
          '$insumoNombre',
          '$insumoId',
          '$origenNombre',
          '$origenId',
          '$cantidad',
          '$fecha'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: obtenerReporteDiario
   *@funcionalidad: Se encarga de traer todas los resportes diarios
   */
  static Future<List<Map<String, Object?>>> obtenerReporteDiario()async{
    Database database = await crearBaseDatosTablas();
    try {
      return await database.rawQuery("SELECT nombreProyecto, nombreOrdenTrabajo, fecha, estadoTarjeta FROM reporteDiario");
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }


  
  // Delete the database
  static Future<bool> borrarTablas()async {
    Database database = await crearBaseDatosTablas();
    await database.delete('reporteDiario');
    await database.delete('actividades');
    return true;
    //await database.delete('ingresos');
  }

  
}