class Environment {

  var environment = {
    /* production: false,
    url: 'http://127.0.0.1:8000',
    api: 'http://127.0.0.1:8000/api',
    serverURL: 'http://127.0.0.1:8000/',
    serverArchivo:'https://datasseq.s3.us-west-2.amazonaws.com/',
    urlFront: 'http://localhost:4200/', */


    /* production: true,
    url: 'http://35.84.235.5:8079',
    api: 'http://35.84.235.5:8079/api',
    serverURL: 'http://35.84.235.5:8079',
    serverArchivo:'https://datasseq.s3.us-west-2.amazonaws.com/',
    urlFront: 'http://35.84.235.5:81/' */

    /* 'production': false,
    'url': 'https://testing.v2.datasseq.com.co:8079' ,
    'api': 'https://testing.v2.datasseq.com.co:8079/api',
    'serverURL': 'https://testing.v2.datasseq.com.co:8079',
    'serverArchivo':'https://datasseq.s3.us-west-2.amazonaws.com/',
    'urlFront': 'https://testing.v2.datasseq.com.co/' */

    'production': false,
    'url': 'https://testing.v2.datasseq.com.co:8079' ,
    'api': 'https://testing.v2.datasseq.com.co:8079/api',
    'serverURL': 'https://testing.v2.datasseq.com.co:8079/',
    'serverArchivo':'http://datasseq.s3.us-west-2.amazonaws.com/',
    'urlFront': 'https://testing.v2.datasseq.com.co:8079/'
  };

}