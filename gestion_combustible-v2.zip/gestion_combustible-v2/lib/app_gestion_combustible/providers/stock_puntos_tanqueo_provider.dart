import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:intl/intl.dart';

class StockPuntosTanqueoProvider extends ChangeNotifier{

 
  List<dynamic> listaStockPuntosTanqueos =[];
  var fechaUltimaSincronizacion = "";
  bool loading = false;

  /*
   *@method obtenerFechaSincronizada
   *@funcionalidad Se encarga de obtener la utlima fecha de sincronizacion
   */
  obtenerFechaSincronizada()async{
    var resultado = await DB.obtenerFechas();
    if(resultado.isNotEmpty){
      DateTime fechaSincronizado = DateTime.parse(resultado[0]["fecha"].toString());
      fechaUltimaSincronizacion = DateFormat. yMd().add_jm().format(fechaSincronizado);
      notifyListeners();
    } 
  }

  /*
   *@method mostrarStockPuntosTanqueo
   *@funcionalidad Se encarga de obtener todos los puntos de tanqueo
   */
/*   void mostrarStockPuntosTanqueo()async{
    
    loading = true;
    
    var datos = await DB.mostrarStockPuntosTanqueo();
    listaStockPuntosTanqueos = datos;

    if(datos.isNotEmpty){
      listaStockPuntosTanqueos = datos;
      
      loading = false;
      notifyListeners();
    }
    else{
      loading = false;
      notifyListeners();
    } 
  } */

  /*
   *@method galonesSaliente
   *@funcionalidad Se encarga de mostrar los datos de los galones salientes y el stock actual del punto de tanqueo
   */
  void galonesSaliente()async{
    loading = true;
    listaStockPuntosTanqueos = await DB.galonesSaliente();
    if(listaStockPuntosTanqueos.isNotEmpty){
      
      loading = false;
      notifyListeners();
    }
    else{
      loading = false;
      notifyListeners();
    } 
  }


}