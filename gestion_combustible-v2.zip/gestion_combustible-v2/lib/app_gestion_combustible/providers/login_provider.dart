import 'dart:convert';
import 'dart:io';
import 'package:com_gestioncombustible_app/app_gestion_combustible/environments/environments.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:developer' as developer;


class LoginProvider extends ChangeNotifier{
  
  final uri = Environment().environment['api'];

  var datoUser ;

  obtenerDatosUser() => datoUser;

  var nombreUsuario = "" ;
  var documento = "";
  var cargo = "" ;
  
  /*
   * @method: ingresarUsuario
   * @funcionalidad: Se encarga de logear al usuario.
   */
  Future<int> ingresarUsuario( numeroIdentificacion, password, context)async{
    
    /**
     * 0 no hay internet
     * 1 logeado con internet
     * 2 logeado sin internet
     * 3 el usuario no es el mismo que se autentificó
     */
    
    var resultado = 0;

    try {
      final result = await InternetAddress.lookup('v2.datasseq.com');

      if (result.isNotEmpty) {//si hay internet
        var body = {
          "numero_identificacion": numeroIdentificacion,
          "password": password
        };

        try {
          var dio = Dio();
          final respuesta = await dio.post(
            '$uri/auth/login',
            data: body
          );

          
          if(respuesta.statusCode == 200){

            var permisosComponente ="";
            var permisosSubComponente ="";

            for (var i = 0; i < respuesta.data["data"]["data"][0]["permisos"].length; i++) {
              permisosComponente = permisosComponente + '${respuesta.data["data"]["data"][0]["permisos"][i]["componente_id"].toString()},';              
            }        

            for (var i = 0; i < respuesta.data["data"]["data"][0]["permisos"].length; i++) {
              for (var f = 0; f < respuesta.data["data"]["data"][0]["permisos"][i]["sub_componentes"].length; f++) {
                permisosSubComponente = permisosSubComponente + '${respuesta.data["data"]["data"][0]["permisos"][i]["sub_componentes"][f]["sub_componente_id"].toString()},';
              }              
            }

            //await DB.borrarSecciones();
            await DB.borrarDocumentoSesion();

            DB.insertarDatoSesionUsuario( 
              respuesta.data["data"]["data"][0]["id"].toString(),
              respuesta.data["data"]["data"][0]["name"].toString(),
              respuesta.data["data"]["data"][0]["numero_identificacion"].toString(),
              respuesta.data["data"]["data"][0]["tipo_documento_id"].toString(),
              respuesta.data["data"]["data"][0]["cargo_id_label"].toString(),
              respuesta.data["token"]["original"]["access_token"].toString(),
              permisosComponente,
              permisosSubComponente,
            );

            DB.insertarDocumentoSesion(respuesta.data["data"]["data"][0]["numero_identificacion"].toString());

             await Future.delayed(Duration(seconds: 1));

            resultado = 1;  
          }else{
            resultado = 0;
          }

        } catch (e) {
          print(e.toString());
          resultado = 3;
        }
      }

    } catch (e) {//no hay internet
      await DB.borrarDocumentoSesion();//borro los documentos de sesion
      var datos = await DB.obtenerSesionUsuario(numeroIdentificacion.toString());
      DB.insertarDocumentoSesion(numeroIdentificacion.toString());//vuelvo e ingreso el docuemnto

      if(datos.isEmpty){
        resultado = 3;
      }else{
        resultado =2;
       /*  if( datos[0]["documento"].toString() == numeroIdentificacion.toString() ){
        resultado = 2;
        }else{
          resultado = 3;
        }  */
      }
    }

    return resultado;
  }

  /*
   *@mehtod obtenerSesion
   *@funcionalidad Se encarga de obtener la session del usuario
   */
  Future<void> obtenerSesion()async {

    var document = await DB.obtenerDocumentoSesion();
    datoUser = await DB.obtenerSesionUsuario(document[0]['documento']);
    //print(datoUser);
    nombreUsuario = await datoUser[0]["nombreUsuario"];
    documento = await datoUser[0]["documento"];
    cargo = await datoUser[0]["cargo"];
    notifyListeners();
  }
  
  /*
   *@method: tienePermiso
   *@funcionalidad: se encarga de recorrer los permisos. 
   */
  /* tienePermiso( List permisos )async{
    var datos = await DB.obtenerSesionUsuario();
    var token =  datos[0]["permisos"];
    print(token);
    //print(datoUser);
    //var datosFormateados = token.split(',');  

    /* bool _resultadoPermiso = false;

    for (var i = 0; i < datosFormateados.length; i++) {

      var permisosFound = permisos.map((e) => { datosFormateados[i].toString() == e.toString() });
      if(permisosFound.first.first){
        _resultadoPermiso = true;
        break;
      }
    } */
    return true;// _resultadoPermiso;
  } */


}