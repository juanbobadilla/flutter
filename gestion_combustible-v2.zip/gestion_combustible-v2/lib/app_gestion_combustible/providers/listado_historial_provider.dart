import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:developer' as developer;


class ListadoHistorialProvider extends ChangeNotifier{

    DateTime fechaInicial = DateTime(DateTime.now().year , DateTime.now().month, 1);
    
    DateTime fechaFinal = DateTime(DateTime.now().year , DateTime.now().month, DateTime.now().day);

    var puntoTanquoSeleccionadoId = null;
    var puntoTanqueoSeleccionadoTexto = null;
    var puntoTanquoSeleccionadoCompleto = null;

    var activosSeleccionadoId =null;
    var activoTexto = null;
    var activoSeleccionadoCompleto = null;

    late Map<String, dynamic> headers = {} ;
    List<dynamic> listaPuntoTanquo =[];
    List<dynamic> listaActivos =[];

    bool spinnerPuntoTanqueo = false;
    bool spinnerActivos = false;

    setHeaders(header){
      headers = header;
    }

    List<dynamic> listadoHistorial = [];

    void mostrarTodosIngresos() async{
      listadoHistorial = await DB.mostrarTodosIngresos(fechaInicial, fechaFinal, puntoTanquoSeleccionadoId, activosSeleccionadoId);

      notifyListeners();
    }

    /*
    *@method obtenerPuntosTanqueo
    *@funcionalidad Se encarga de obtener todos los puntos de tanqueo
    */
    void obtenerPuntosTanqueo()async{
      spinnerPuntoTanqueo = true;
      listaPuntoTanquo.clear();

      var datos = await DB.mostrarTodosPuntosTanqueo();
      
      for (var i = 0; i < datos.length; i++) {
        listaPuntoTanquo.add("${datos[i]["id"]} ${datos[i]["nombre"]}");
      }
      spinnerPuntoTanqueo = false;
      notifyListeners();
    }

    /*
    *@method setPuntoTanquoSeleccionado
    *@funcionalidad Se encarga de asignar el valor
    */
    setPuntoTanquoSeleccionado(puntoTanquoSeleccionado ){
      if(puntoTanquoSeleccionado == null){
        puntoTanquoSeleccionadoCompleto = null ;
        puntoTanquoSeleccionadoId = null;
        puntoTanqueoSeleccionadoTexto = null;
        notifyListeners();
      }else{
        puntoTanquoSeleccionadoCompleto = puntoTanquoSeleccionado;
        var dato = puntoTanquoSeleccionado.split(' ');
        puntoTanquoSeleccionadoId = int.parse(dato[0]);
        notifyListeners();
      }
    }

    /*
    *@method obtenerActivos
    *@funcionalidad Se encarga obtener los activos
    */
    void obtenerActivos() async{
      spinnerActivos = true;
      listaActivos.clear();
      var datos = await DB.mostrarTodosActivos();
      
      for (var i = 0; i < datos.length; i++) {
        listaActivos.add("${datos[i]["id"]} ${datos[i]["clasificacion"]}-${datos[i]["categoria"]}-${datos[i]["placa"]}");
      }
      spinnerActivos = false;
      notifyListeners();
    }

    /*
    *@method setActivosSeleccionado
    *@funcionadlidad Se encarga de asignar el valor
    */ 
    setActivosSeleccionado(activosSeleccionado){
      if(activosSeleccionado == null){
        activoSeleccionadoCompleto = null;
        activosSeleccionadoId = null;
        activoTexto = null;
        notifyListeners();
      }else{
        activoSeleccionadoCompleto = activosSeleccionado;
        var dato = activosSeleccionado.split(' ');
        activosSeleccionadoId = int.parse(dato[0]);
        notifyListeners();
      }
    }

    /*
     *@method seleccionarFechaInicial
     *@funcionalidad Se encarga de seleccionar la fecha inicial
     */
    void seleccionarFechaInicial(context) async {
      final DateTime? newDate = await showDatePicker(
        context: context,
        initialDate: fechaInicial,
        firstDate: DateTime(2009),
        lastDate: DateTime(2030),
        helpText: 'Seleccione una fecha',
      );
      if (newDate != null) {
        fechaInicial = newDate;
        notifyListeners();
      }
    }

    /*
     *@method seleccionarFechaFinal
     *@funcionalidad Se encarga de seleccionar la fecha final
     */
    void seleccionarFechaFinal(context) async {
      final DateTime? newDate = await showDatePicker(
        context: context,
        initialDate: fechaFinal,
        firstDate: DateTime(2009),
        lastDate: DateTime(2030),
        helpText: 'Seleccione una fecha',
      );
      if (newDate != null) {
        fechaFinal = newDate;
        notifyListeners();
      }
    }

    /*
     *@method realizarBusqueda
     *@funcionalidad Se encarga de tomar los filtros y reaizar la consulta 
     */
    void realizarBusqueda()async{
      listadoHistorial = [];
      listadoHistorial = await DB.mostrarTodosIngresos(fechaInicial, fechaFinal, puntoTanquoSeleccionadoId, activosSeleccionadoId);
      notifyListeners();
    }


}