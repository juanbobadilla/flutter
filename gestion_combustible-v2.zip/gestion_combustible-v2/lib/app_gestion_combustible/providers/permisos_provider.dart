import "package:flutter/material.dart";

class PermisosProvider extends ChangeNotifier{

  late int _permisos;

  PermisosProvider( int permiso ){
    _permisos = permiso;
  }

  bool tienePermiso( List permisos ){

    

    return true;
  }


}