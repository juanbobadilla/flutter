import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'dart:developer' as developer;

class HomeProvider extends ChangeNotifier{



}