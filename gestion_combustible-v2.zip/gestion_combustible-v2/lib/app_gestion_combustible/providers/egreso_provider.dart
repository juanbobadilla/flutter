import 'dart:io';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'package:flutter/foundation.dart';
import "package:flutter/material.dart";
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/environments/environments.dart';
import 'dart:developer' as developer;

class EgresoProvider extends ChangeNotifier {
  //final uri = 'https://v2.datasseq.com:8079/api';
  final uri = Environment().environment['api'];

  late Map<String, dynamic> headers = {};
  List<dynamic> listaPuntoTanquo = [];
  List<dynamic> listaProyectos = [];
  List<dynamic> listaFrentes = [];
  List<dynamic> listaActivos = [];
  List<dynamic>listaConductores = [];

  DateTime fecha = DateTime.now();
  var fechaDia = "";
  var fechaMes = "";
  var fechaAno = "";
  var datoUser = [];
  String base64string = "";
  var imagen = null;
  String mensajeAdjuntoDocumentos = "";
  String extension = "";

  /*
   *@method desacoplaFecha
   *@funcionalidad Se encarga de desacoplar las fechas
   */
  desacoplaFecha() {
    var fechaotro = DateFormat('yyyy-MM-dd').format(fecha);
    DateTime date = DateTime.parse(fechaotro);
    fechaAno = date.year.toString(); //Año
    fechaMes = date.month.toString(); //mes
    fechaDia = date.day.toString(); //año
  }

  var puntoTanquoSeleccionadoId = null;
  var puntoTanquoSeleccionadoCompleto = null;
  var puntoTanqueoTexto = null;

  var proyectoId = null ;
  var tanquProyectoId = null;
  var proyectoSeleccionadoCompleto = null;
  var proyectoTexto = null;

  var frenteSeleccionadoId = null;
  var frenteSeleccionadoCompleto = null;
  var frenteTexto = null;

  var activosSeleccionadoId = null;
  var activoTexto = null;
  var activoSeleccionadoCompleto = null;

  var conductoresSeleccionadoId = null;
  var conductorTexto = null;
  var conductoresSeleccionadoCompleto = null;

  var isleroSeleccionadoCompleto = null;
  var isleroSeleccionadoId = null;
  var isleroTexto = null;

  String ubicacionPuntoTanqueo = "--";
  String stock = "0";
  String tipoCombustible = "";
  int radioButton = 2008;
  bool checkFullNoFull = true;
  double volumen = 0.0;
  double contadorPostTanqueo = 0.0;
  bool checkInicioOperar = false;
  String selloAnterior = "0.0";
  double horometroAnterior = 0.0;
  double kilometrajeAnterior = 0.0;
  double valorGalonHr = 0.0;
  double valorKilometroHr = 0.0;
  String selloActual = "--";
  double horometroActual = 0.0;
  double kilometrajeActual = 0.0;
  String observaciones = "NINGUNA";
  bool estadoHorometro = false;
  bool estadoOdometro = false;

  bool spinnerPuntoTanqueo = false;
  bool spinnerProyecto = false;
  bool spinnerFrente = false;
  bool spinnerActivos = false;
  bool spinnerConductor = false;
  bool spinnerDatosAnteriores = false;

  bool alertaGalHr = false;
  bool alertaKmGl = false;
  bool mostrarCheckFullNoFull = true;

  getHeaders() => headers;

  setHeaders(header) {
    headers = header;
  }

  /*
   *@method obtenerPuntosTanqueo
   *@funcionalidad Se encarga de obtener todos los puntos de tanqueo
   */
  void obtenerPuntosTanqueo() async {
    spinnerPuntoTanqueo = true;
    listaPuntoTanquo.clear();

    var datos = await DB.mostrarTodosPuntosTanqueo();

    for (var i = 0; i < datos.length; i++) {
      listaPuntoTanquo.add("${datos[i]["id"]} ${datos[i]["nombre"]}");
    }
    spinnerPuntoTanqueo = false;
    notifyListeners();
  }

  /*
   *@method setPuntoTanquoSeleccionado
   *@funcionalidad Se encarga de asignar el valor
   */
  setPuntoTanquoSeleccionado(puntoTanquoSeleccionado) {
    if (puntoTanquoSeleccionado == null) {
      puntoTanquoSeleccionadoCompleto = null;
      //puntoTanquoSeleccionadoId = null;
      ubicacionPuntoTanqueo = "--";
      stock = "0";
      tipoCombustible = "";
      proyectoSeleccionadoCompleto = null;
      tanquProyectoId = null;
      listaProyectos = [];

      frenteSeleccionadoCompleto = null;
      frenteSeleccionadoId = null;
      listaFrentes = [];

      notifyListeners();
    } else {
      puntoTanquoSeleccionadoCompleto = puntoTanquoSeleccionado;
      var dato = puntoTanquoSeleccionado.split(' ');
      puntoTanquoSeleccionadoId = int.parse(dato[0]);
      puntoTanqueoTexto = dato[0];
      obtenerProyectosPuntoTanqueo(int.parse(dato[0]));
      obtenerInformacioPuntoTanqueo(int.parse(dato[0]));
      notifyListeners();
    }
  }

  /*
   *@method obtenerProyectosPuntoTanqueo
   *@funcionalidad Se encarga de obtener los proyectos
   */
  void obtenerProyectosPuntoTanqueo(valor) async {
    spinnerProyecto = true;
    proyectoSeleccionadoCompleto = null;
    tanquProyectoId = null;
    listaProyectos.clear();

    var datos = await DB.mostrarTodosProyectoPorPuntosTanqueo(valor);
    if (datos.isNotEmpty) {
      for (var i = 0; i < datos.length; i++) {
        listaProyectos.add(
            "${datos[i]["proyecto_id"]}. ${datos[i]["id"]}. ${datos[i]["proyecto_nombre"]}");
      }
      spinnerProyecto = false;
      notifyListeners();
    } else {
      spinnerProyecto = false;
      notifyListeners();
    }
  }

  /*
   *@method obtenerInformacioPuntoTanqueo
   *@funcionalidad Se encarga de obtener los valores de la ubicacion y el stock del punto de tanqueo
   */
  void obtenerInformacioPuntoTanqueo(valor) async {
    ubicacionPuntoTanqueo = "--";
    stock = "0";
    tipoCombustible = "";

    var datos = await DB.mostrarTodosInformacionPorPuntosTanqueo(valor);

    if (datos.isNotEmpty) {
      ubicacionPuntoTanqueo =
          datos[0]["municipio"] == "" ? "--" : datos[0]["municipio"].toString();
      stock = datos[0]["stock"] == ""
          ? "0.0"
          : double.parse(datos[0]["stock"].toString()).toStringAsFixed(2);
      tipoCombustible = datos[0]["tipo_combustible"] == ""
          ? "--"
          : datos[0]["tipo_combustible"].toString();
      notifyListeners();
    }
  }

  /*
   *@method: setProyectoSeleccionado
   *@funcionalida: Se encarga de obtener el valor para asignarlo a la variable
   */
  setProyectoSeleccionado(proyectoSeleccionado) {
    if (proyectoSeleccionado == null) {
      proyectoSeleccionadoCompleto = null;
      proyectoTexto = null;

      frenteSeleccionadoCompleto = null;
      frenteSeleccionadoId = null;
      listaFrentes = [];

      notifyListeners();
    } else {
      proyectoSeleccionadoCompleto = proyectoSeleccionado;
      var dato = proyectoSeleccionado.split('.');
      proyectoId = int.parse(dato[1].toString().trim());
      tanquProyectoId = int.parse(dato[0].toString().trim());
      mostrarFrentesPorProyecto(dato[1].toString().trim());
      proyectoTexto = dato[2].toString().trim();
      notifyListeners();
    }
  }

  /*
   * @method mostrarFrentesPorProyecto
   * @funcionalidad Se encarga de mostrar los frentes de acuerdo con el proyecto
   */
  void mostrarFrentesPorProyecto(idProyecto) async {
    spinnerFrente = true;
    frenteSeleccionadoCompleto = null;
    frenteSeleccionadoId = null;
    listaFrentes.clear();
    
    var datos = await DB.mostrarFrentesPorProyecto(idProyecto);
    if (datos.isNotEmpty) {
      for (var i = 0; i < datos.length; i++) {
        listaFrentes.add("${datos[i]["id"]} ${datos[i]["nombre"]}");
      }
      spinnerFrente = false;
      notifyListeners();
    } else {
      spinnerFrente = false;
      notifyListeners();
    }
  }

  /*
   *@method: setFrenteSeleccionado
   *@funcionalida: Se encarga de asignar el valor para asignarlo a la variable
   */
  setFrenteSeleccionado(frenteSeleccionado) {
    if (frenteSeleccionado == null) {
      frenteSeleccionadoCompleto = null;
      frenteTexto = null;
      notifyListeners();
    } else {
      frenteSeleccionadoCompleto = frenteSeleccionado;
      var dato = frenteSeleccionado.split(' ');
      frenteSeleccionadoId = int.parse(dato[0]);
      frenteTexto = dato[0];
      notifyListeners();
    }
  }

  /*
   * @method: obtenerProyectos
   * @funcionalidad: Se encarga de obtener todos los proyectos.
   */
  /* void obtenerProyectos()async{

      listaProyectos.clear();

      spinnerProyecto = true;
      final header = getHeaders();

      final respuesta = await http.get(
        Uri.parse('$uri/ms/proyectos?registros=200'),
        headers: {HttpHeaders.authorizationHeader: 'Bearer ${header['token']['original']['access_token']}' }
      );

      if(respuesta.statusCode == 200){
        spinnerProyecto = false;
        Map<String, dynamic> dato = json.decode(respuesta.body);

        for (var i = 0; i < dato['data']['data'].length; i++) {
          
          listaProyectos.add( "${dato['data']['data'][i]["id"]} ${dato['data']['data'][i]["nombre"]}" );
        }
        notifyListeners();
      }
      else {
        spinnerProyecto = false;
        notifyListeners();
        // Si la llamada no fue exitosa, lanza un error.
        throw Exception('Falla en la petición get');
      }
  }
 */

  /*
   *@method obtenerActivos
   *@funcionalidad Se encarga obtener los activos
   */
  void obtenerActivos() async {
    spinnerActivos = true;
    listaActivos.clear();
    var datos = await DB.mostrarTodosActivos();

    for (var i = 0; i < datos.length; i++) {
      listaActivos.add(
          "${datos[i]["id"]} ${datos[i]["clasificacion"]}-${datos[i]["categoria"]}-${datos[i]["placa"]}");
    }
    spinnerActivos = false;
    notifyListeners();
  }

  /*
   *@method setActivosSeleccionado
   *@funcionadlidad Se encarga de asignar el valor
   */
  setActivosSeleccionado(activosSeleccionado) {
    if (activosSeleccionado == null) {
      activoSeleccionadoCompleto = null;
      activosSeleccionadoId = null;
      activoTexto = null;
      selloAnterior = "0.0";
      horometroAnterior = 0.0;
      kilometrajeAnterior = 0.0;
      valorGalonHr = 0.0;
      valorKilometroHr = 0.0;
      notifyListeners();
    } else {
      activoSeleccionadoCompleto = activosSeleccionado;
      var dato = activosSeleccionado.split(' ');
      activosSeleccionadoId = int.parse(dato[0]);
      activoTexto = dato[0];
      obtenerValoresAnterioresActivo(int.parse(dato[0]));
      notifyListeners();
    }
  }

  /*
   *@method obtenerValoresAnterioresActivo
   *@funcionalidad Se encarga de 
   */
  void obtenerValoresAnterioresActivo(activo) async {
    spinnerDatosAnteriores = true;

    var datos = await DB.mostrarSelloHoromotroKilometrajeAnterior(activo);
    if (datos.isNotEmpty) {
      spinnerDatosAnteriores = false;
      selloAnterior = datos[0]["sello_actual"].toString();
     /*  horometroAnterior = double.parse(datos[0]["horometro_actual"].toString());
      kilometrajeAnterior =
          double.parse(datos[0]["kilometro_actual"].toString()); */
      setHorometroAnterior(double.parse(datos[0]["horometro_actual"].toString()));
      setKilometrajeAnterior(double.parse(datos[0]["kilometro_actual"].toString()));
      estadoHorometro = datos[0]["estadoHorometro"] == 0 ? false : true;
      estadoOdometro = datos[0]["estadoOdometro"] == 0 ? false : true;
      notifyListeners();
    } else {
      spinnerDatosAnteriores = false;
      selloAnterior = "--";
      horometroAnterior = 0.0;
      kilometrajeAnterior = 0.0;
      estadoHorometro = false;
      estadoOdometro = false;
      notifyListeners();
    }
  }

  /*
   *@method obtenerConductores
   *@funcionalidad Se encarga de traer los conductores
   */

  void obtenerConductores() async {
    spinnerConductor = true;
    listaConductores.clear();
    var datos = await DB.mostrarTodosConductores();
   
    for (var i = 0; i < datos.length; i++) {
      listaConductores.add("${datos[i]["id"]} ${datos[i]["name"]}");
    }
    spinnerConductor = false;
    notifyListeners();
  }

  /*
   *@method setConductoresSeleccionado
   *@funcionalidad Se encarga de asignar los valores
   */
  setConductoresSeleccionado(valor) {
    if (valor == null) {
      conductoresSeleccionadoCompleto = null;
      conductoresSeleccionadoId = null;
      conductorTexto = null;
      notifyListeners();
    } else {
      conductoresSeleccionadoCompleto = valor;
      var dato = valor.split(' ');
      conductoresSeleccionadoId = int.parse(dato[0]);
      conductorTexto = dato[0];
      notifyListeners();
    }
  }

  /*
   *@method setIsleroSeleccionado
   *@funcionalidad Se encarga de asignar valores
   */
  setIsleroSeleccionado(valor) {
    if (valor == null) {
      isleroSeleccionadoCompleto = null;
      isleroSeleccionadoId = null;
      isleroTexto = null;
      notifyListeners();
    } else {
      isleroSeleccionadoCompleto = valor;
      var dato = valor.split(' ');
      isleroSeleccionadoId = int.parse(dato[0]);
      isleroTexto = dato[0];
      notifyListeners();
    }
  }

  /*
   *@method setRadioButton
   *@funcionalidad Se encarga de asignar el valor al radio button 
   */
  setRadioButton(valor) {
    radioButton = valor;
    if (valor == 2008) {
      checkInicioOperar = false;
      checkFullNoFull = true;
      mostrarCheckFullNoFull = true;
      notifyListeners();
    } else if (valor == 2284) {
      checkInicioOperar = true;
      checkFullNoFull = true;
      mostrarCheckFullNoFull = true;
      calcularValores();
      //notifyListeners();
    } else {
      checkInicioOperar = true;
      checkFullNoFull = false;
      mostrarCheckFullNoFull = false;
      notifyListeners();
    }
  }

  /*
   *@method  setCheckFullNoFull
   *@funcionalidad Se encarga de asignar el valor
   */
  setCheckFullNoFull(valor) {
    checkFullNoFull = valor;
    notifyListeners();
  }

  /*
   *@method: setVolumen
   *@funcionalidad: Se encarga de asignar el valor volumen a su varible 
   */
  setVolumen(valor) {
    if (valor == null || valor.isEmpty) {
      volumen = 0.0;
      notifyListeners();
    } else {
      volumen = double.parse(valor);
      calcularValores();
      notifyListeners();
    }
  }

  /*
   *@method: setCOntadorPostTanqueo
   *@funcionalidad: Se encarga de asignar el valor a su varible 
   */
  setCOntadorPostTanqueo(valor) {
    if (valor == null || valor.isEmpty) {
      contadorPostTanqueo = 0.0;
      notifyListeners();
    } else {
      contadorPostTanqueo = double.parse(valor);
      calcularValores();
      notifyListeners();
    }
  }

  /*
   *@method  setCheckInicioOperar
   @funcionalidad Se encarga de asignar el valor
   */
  setCheckInicioOperar(valor) {
    checkInicioOperar = valor;
    calcularValores();
    notifyListeners();
  }

  /*
   *@method calcularValores
   *@funcionalidad Se encarga de calcular los valores de glHr y kmGal 
   */
  calcularValores() {
    var galHr =
        (volumen / (horometroActual - horometroAnterior)).toStringAsFixed(7);
    var kmGal = ((kilometrajeActual - kilometrajeAnterior) / volumen)
        .toStringAsFixed(7);

    if (double.parse(galHr) < 0) {
      alertaGalHr = true;
    } else {
      alertaGalHr = false;
    }

    if (double.parse(kmGal) < 0) {
      alertaKmGl = true;
    } else {
      alertaKmGl = false;
    }

    setValorGalonHr(galHr);
    setValorKilometroHr(kmGal);
    notifyListeners();
  }

  /*
   * @method setSelloAnterior
   * @funcionalidad Se encarga de asignar el valor
   */
  setSelloAnterior(valor) {
    selloAnterior = valor;
  }

  /*
   *@method setHorometroAnterior
   *@funcionalidad Se encarga de asignar el valor
   */
  setHorometroAnterior(valor) {
    horometroAnterior = valor;
    notifyListeners();
  }

  /*
   *@method setKilometrajeAnterior
   *@funcionalidad Se encarga de asignar el valor
   */
  setKilometrajeAnterior(valor) {
    kilometrajeAnterior = valor;
    notifyListeners();
  }

  /*
   *@method setValorGalonHr
   *@funcionalidad Se encarga de asignar el valor
   */
  setValorGalonHr(valor) {
    valorGalonHr = double.parse(valor);
  }

  /*
   *@method setValorKilometroHr
   *@funcionalidad Se encarga de asignar el valor
   */
  setValorKilometroHr(valor) {
    valorKilometroHr = double.parse(valor);
  }

  /*
   *@method setSelloActual
   *@funcionalidad Se encarga de asignar el valor 
   */
  setSelloActual(valor) {
    if (valor == null || valor.isEmpty) {
      selloActual = "";
      notifyListeners();
    } else {
      selloActual = valor;
      notifyListeners();
    }
  }

  /*
   *@method setHorometroActual
   *@funcionalidad Se encarga de asignar el valor 
   */
  setHorometroActual(valor) {
    if (valor == null || valor.isEmpty) {
      horometroActual = 0.0;
      notifyListeners();
    } else {
      horometroActual = double.parse(valor);
      calcularValores();
    }
  }

  /*
   *@method setHorometroActual
   *@funcionalidad Se encarga de asignar el valor 
   */
  setKilometrajeActual(valor) {
    if (valor == null || valor.isEmpty) {
      kilometrajeActual = 0.0;
      notifyListeners();
    } else {
      kilometrajeActual = double.parse(valor);
      calcularValores();
    }
  }

  /*
   *@method setObservaciones
   *@funcionalidad Se encarga de asignar el valor 
   */
  setObservaciones(valor) {
    observaciones = valor;
  }

  /*
   *@method obtenerConsecutivoIngreso
   *@funcionalidad Se encarga de obtener el consecutivo de los datos
   */
  void obtenerSession() async {
    var documento = await DB.obtenerDocumentoSesion();
    datoUser = await DB.obtenerSesionUsuario(documento[0]['documento']);
    notifyListeners();
  }

  /*
   *@method guardarFormularioEgreso
   *@funcionalidad Se encarga de enviar los datos para ser guardados
   */
  Future<bool> guardarFormularioEgreso() async {
    var totalStock = double.parse(stock) - volumen;

    if (totalStock < 0) {
      return false;
    } else {
      var puntoTanqueoFormateado = puntoTanquoSeleccionadoCompleto.split(' ');
      var horaFormateada = fecha.toString().substring(10, 16);
      var nombreArchivo =
          '${DateFormat('yyyy-MM-dd').format(fecha)}-EG-${horaFormateada.toString().trim()}-${puntoTanqueoFormateado[1].toString().trim()}';

      await DB.insertarDatosIngresosEgresos(
          fecha,
          DateFormat('yyyy-MM-dd').format(fecha).toString(),
          "0",
          puntoTanquoSeleccionadoId.toString(),
          puntoTanquoSeleccionadoCompleto.toString(),
          "",
          "",
          volumen.toString(),
          "",
          "",
          "",
          "",
          observaciones.toString(),
          datoUser[0]["id"].toString(),
          datoUser[0]["nombreUsuario"].toString(),
          datoUser[0]["id"].toString(),
          datoUser[0]["nombreUsuario"].toString(),
          radioButton.toString(),
          "EGRESO",
          proyectoId.toString(),
          tanquProyectoId.toString(),
          proyectoSeleccionadoCompleto.toString(),
          frenteSeleccionadoId.toString() == "null"
              ? ""
              : frenteSeleccionadoId.toString(),
          frenteSeleccionadoCompleto.toString() == "null"
              ? ""
              : frenteSeleccionadoCompleto.toString(),
          activosSeleccionadoId.toString(),
          activoSeleccionadoCompleto.toString(),
          conductoresSeleccionadoId.toString(),
          conductoresSeleccionadoCompleto.toString(),
          checkFullNoFull,
          contadorPostTanqueo.toString() == "null"
              ? 0
              : contadorPostTanqueo.toString(),
          "", //checkInicioOperar == false ? "0" : "1",
          selloActual.toString() == "null" || selloActual.toString() =="--" ? selloAnterior.toString() : selloActual.toString(),
          horometroActual.toString() == "0.0" || horometroActual.toString() == "" || horometroActual.toString() == "null" 
              ? horometroAnterior.toString()
              : horometroActual.toString(),
          kilometrajeActual.toString() == "0.0" || kilometrajeActual.toString() == "" || kilometrajeActual.toString() == "null"
              ? kilometrajeAnterior.toString()
              : kilometrajeActual.toString(),
          base64string.toString(),
          nombreArchivo.toString(),
          extension.toString(),
          tipoCombustible.toString(),
          volumen.toString(),
          "0",
          "LOCAL"
          );

      await DB.insertarDatosInformacionPuntoTanqueo(
          puntoTanquoSeleccionadoId,
          ubicacionPuntoTanqueo.toString(),
          tipoCombustible.toString(),
          "0",
          "0",
          totalStock);
      return true;
    }
  }

  seleccionarImagen(opcion, context) async {
    final ImagePicker imgpicker = ImagePicker();
    String imagepath = "";

    switch (opcion) {
      case 0:
        try {
          var archivoSeleccionado = await imgpicker.pickImage(
              source: ImageSource.camera,
              maxWidth: 1080,
              maxHeight: 720,
              imageQuality: 80);

          if (archivoSeleccionado != null) {
            imagepath = archivoSeleccionado.path;

            var informacionImagen = [];
            informacionImagen = archivoSeleccionado.name.split('.');
            extension = informacionImagen[1];

            File imagefile = File(imagepath); //convert Path to File
            Uint8List imagebytes =
                await imagefile.readAsBytes(); //convert to bytes
            base64string =
                base64.encode(imagebytes); //convert bytes to base64 string
            developer.log(base64string.toString());

            //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

            imagen = base64.decode(base64string);

            Navigator.pop(context);

            mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
            notifyListeners();
            return true;
          } else {
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }
        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos =
              "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;
      case 1:
        try {
          var archivoSeleccionado = await imgpicker.pickImage(
              source: ImageSource.gallery,
              maxWidth: 1080,
              maxHeight: 720,
              imageQuality: 80);

          if (archivoSeleccionado != null) {
            var informacionImagen = [];

            informacionImagen = archivoSeleccionado.name.split('.');

            if (informacionImagen[1] == "jpg" ||
                informacionImagen[1] == "png") {
              imagepath = archivoSeleccionado.path;
              extension = informacionImagen[1];

              File imagefile = File(imagepath); //convert Path to File
              Uint8List imagebytes =
                  await imagefile.readAsBytes(); //convert to bytes
              base64string =
                  base64.encode(imagebytes); //convert bytes to base64 string

              //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

              imagen = base64.decode(base64string);

              Navigator.pop(context);
              mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
              notifyListeners();
              return true;
            } else {
              Navigator.pop(context);
              mensajeAdjuntoDocumentos =
                  "La imagen seleccionada tiene que ser de formato jpg.";
              notifyListeners();
              return false;
            }
          } else {
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }
        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos =
              "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;

      default:
    }
  }

  /*
   *@method reiniciarFormulario
   *@funcionalidad Se encarga de reiniicar los valores del formulario 
   */
  void reiniciarFormulario() {
    puntoTanquoSeleccionadoCompleto = null;
    puntoTanquoSeleccionadoId = null;
    ubicacionPuntoTanqueo = "--";
    stock = "0";
    tipoCombustible = "";
    proyectoSeleccionadoCompleto = null;
    tanquProyectoId = null;
    listaProyectos = [];
    frenteSeleccionadoCompleto = null;
    frenteSeleccionadoId = null;
    listaFrentes = [];
    isleroSeleccionadoCompleto = null;
    isleroSeleccionadoId = null;
    activoSeleccionadoCompleto = null;
    activosSeleccionadoId = null;
    conductoresSeleccionadoCompleto = null;
    conductoresSeleccionadoId = null;
    volumen = 0.0;
    contadorPostTanqueo = 0.0;
    selloActual = "--";
    horometroActual = 0.0;
    kilometrajeActual = 0.0;
    estadoHorometro = false;
    estadoOdometro = false;
    observaciones = "NINGUNO";
    imagen = null;
    base64string = "";
    mensajeAdjuntoDocumentos = "";
    setActivosSeleccionado(null);
    setCheckFullNoFull(true);
  }
}
