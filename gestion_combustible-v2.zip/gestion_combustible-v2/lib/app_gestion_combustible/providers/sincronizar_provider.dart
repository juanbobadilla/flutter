import 'dart:io';
import 'package:com_gestioncombustible_app/app_control_obra/model/conexion_model.dart';
import 'package:path_provider/path_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'dart:convert';
import 'package:com_gestioncombustible_app/app_gestion_combustible/environments/environments.dart';
import 'package:flutter/material.dart';
import 'package:share/share.dart';
import 'package:dio/dio.dart';
import 'dart:developer' as developer;

class SincronizarProvider extends ChangeNotifier{

  final uri = Environment().environment['api'];
  var token = "";

  bool loadingPeticion = false;

  /*
   *@method obtenerSesion
   *@funcionalidad Se encarga de traer la informacion de la sesion del usuario
   */
  Future<void> obtenerSesion()async{
    var documento = await DB.obtenerDocumentoSesion();
    var datoUser ;
    datoUser = await DB.obtenerSesionUsuario(documento[0]['documento']);
    if(datoUser.isEmpty){
      return ;
    }else{
      token = datoUser[0]["token"];
      print(token);
      notifyListeners();
    }
   
  }

  /*
   *@method importarDatos
   *@funcionalidad Se encarga de importar los datos necesarios
   */
  Future<int> importarLosDatos()async{
    //1- error al importar
    //2- error al borrar las tablas
    //3- error al subir los datos
    //4- error al borrar o al importar los datos
    //5- error al subir datos
    //6- error no existe ningun documento
    //7- no existe conexion con datasseqv2
    //8- definitivament no existe conexion con datasseqv2
    //9- todo funcionando

    var estado ;
    var datoUser ;
    var estadoDefinitivo;

    try {
      //trae el estado del internet
      final result = await InternetAddress.lookup('v2.datasseq.com');
      if (result.isNotEmpty) {
        loadingPeticion = true;
        var documentoUsuario = await DB.obtenerDocumentoSesion();//obtengo el documento de la sesion
        if(documentoUsuario.isNotEmpty){
          datoUser = await DB.obtenerSesionUsuario(documentoUsuario[0]['documento']);
          var resultadoSubirDatos = await subirDatos();//ejecuto la subida de información
          estado = resultadoSubirDatos;
          
          developer.log(jsonEncode(resultadoSubirDatos).toString());

          if(resultadoSubirDatos != null){//verificar si se subio los datos
            try {
              if(estado["status_server"] == 200 && estado["respuesta"]=="OK"){//verifico el estado de la peticion y la respuesta
                var estadoTabla = await DB.borrarTablas();//borra las tablas para reiniciar los valores con la sincronizacion
                if(estadoTabla == true){//validacion de la eliminacion de las tablas
                  
                  var dio = Dio();
                  final respuesta = await dio.get(
                    '$uri/app/importar',
                    options: Options(
                      headers: {
                        HttpHeaders.authorizationHeader: 'Bearer ${datoUser[0]["token"].toString()}'
                      },
                    ),
                  );

                  estado = respuesta.statusCode;
                  if(estado==200){//verifico el estado del petición
                    var dato = respuesta.data;
                    DateTime fecha = DateTime.now();
                    DB.insertarDatosFechas(fecha.toString());

                    for (var i = 0; i < dato["activos"].length; i++) {
                      DB.insertarDatosActivos(dato["activos"][i]["id"], dato["activos"][i]["codigo_clasificacion"].toString(), dato["activos"][i]["codigo_categoria"].toString(), dato["activos"][i]["placa_unico"].toString() );
                      
                      if(dato["activos"][i]["combustible"].isNotEmpty){
                        for (var f = 0; f < dato["activos"][i]["combustible"].length; f++) {
                          DB.insertarDatosInformacionActivo(
                              dato["activos"][i]["combustible"][f]["id"],
                              dato["activos"][i]["combustible"][f]["sello_actual"],
                              dato["activos"][i]["combustible"][f]["horometro_actual"],
                              dato["activos"][i]["combustible"][f]["kilometro_actual"],
                              dato["activos"][i]["horometro"] == false || dato["activos"][i]["horometro"] == null ? 0 : 1,
                              dato["activos"][i]["odometro"] == false || dato["activos"][i]["odometro"] == null ? 0 : 1,
                              dato["activos"][i]["id"]
                            );
                        } 
                      }else{
                        DB.insertarDatosInformacionActivo(
                              "",
                              "",
                              0,
                              0,
                              dato["activos"][i]["horometro"] == false ? 0 : 1,
                              dato["activos"][i]["odometro"] == false ? 0 : 1,
                              dato["activos"][i]["id"]
                            );
                      }

                    }

                    for (var i = 0; i < dato["conductores"].length; i++) {
                      DB.insertarDatosConductores(dato["conductores"][i]["id"], dato["conductores"][i]["name"].toString(), dato["conductores"][i]["numero_identificacion"].toString());
                    }

                    for (var i = 0; i < dato["colaboradores"].length; i++) {
                      DB.insertarDatosConductores(dato["colaboradores"][i]["id"], dato["colaboradores"][i]["name"].toString(), dato["colaboradores"][i]["numero_identificacion"].toString());
                    }
                      

                    for (var i = 0; i < dato["proveedores_combustible"].length; i++) {
                      DB.insertarDatosProveedores(dato["proveedores_combustible"][i]["id"], dato["proveedores_combustible"][i]["name"].toString(), dato["proveedores_combustible"][i]["numero_identificacion"].toString(), dato["proveedores_combustible"][i]["tipo_persona_id_codigo"].toString());
                    }

                    for (var i = 0; i < dato["puntos_tanqueo"].length; i++) {
                      DB.insertarDatosPuntoTanqueo(
                        dato["puntos_tanqueo"][i]["id"],
                        dato["puntos_tanqueo"][i]["nombre"].toString(),
                        dato["puntos_tanqueo"][i]["ficha_tecnica"] == null ? "" : dato["puntos_tanqueo"][i]["ficha_tecnica"].toString(),
                        dato["puntos_tanqueo"][i]["created_at"].toString(),
                        dato["puntos_tanqueo"][i]["updated_at"].toString(),
                        dato["puntos_tanqueo"][i]["tipo_tanque_id_label"].toString(),
                        dato["puntos_tanqueo"][i]["name"].toString(),
                        dato["puntos_tanqueo"][i]["fecha_calibracion"].toString()
                      );

                      DB.insertarDatosInformacionPuntoTanqueo(
                        dato["puntos_tanqueo"][i]["id"],
                        dato["puntos_tanqueo"][i]["municipio_id_label"].toString(), 
                        dato["puntos_tanqueo"][i]["tipo_combustible_id_label"].toString(), 
                        dato["puntos_tanqueo"][i]["total_ingreso"].toString(),
                        dato["puntos_tanqueo"][i]["total_egreso"].toString(),
                        dato["puntos_tanqueo"][i]["stock"]
                      );

                      for (var f = 0; f < dato["puntos_tanqueo"][i]["proyectos"].length; f++) {
                        DB.insertarDatosProyectosPuntoTanqueo(
                          dato["puntos_tanqueo"][i]["proyectos"][f]["proyecto_id"],
                          dato["puntos_tanqueo"][i]["id"],
                          dato["puntos_tanqueo"][i]["proyectos"][f]["id"], 
                          dato["puntos_tanqueo"][i]["proyectos"][f]["proyecto_id_label"].toString()
                          );
                      }

                    }

                    for (var f = 0; f < dato["frentes"].length; f++) {
                        DB.insertarDatosFrentes(
                          dato["frentes"][f]["id"], 
                          dato["frentes"][f]["proyecto_id"], 
                          dato["frentes"][f]["nombre_frente"], 
                          dato["frentes"][f]["estado"] == true ? 1 : 0,
                          dato["frentes"][f]["frente_principal"] == true ? 1 : 0,
                          );
                    }

                    loadingPeticion = false;//detengo el loading
                    notifyListeners();
                    estadoDefinitivo = 9;
                  }else{
                    loadingPeticion = false;
                    notifyListeners();
                    print("error al importar");
                    estadoDefinitivo = 1;
                    //importarDatos();
                  }
                }else{
                  loadingPeticion = false;
                  notifyListeners();
                  print("error al borrar las tablas");
                  estadoDefinitivo = 2;
                }
              }else{
                loadingPeticion = false;
                notifyListeners();
                print("error al subir los datos");
                estadoDefinitivo = 3;
              }
            } catch (e) {
              loadingPeticion = false;
              notifyListeners();
              print("error al borrar o al importar los datos");
              estadoDefinitivo = 4;
            }
          }else{
            loadingPeticion = false;
            notifyListeners();
            print("error al subir datos");
            estadoDefinitivo = 5;
          }
        }else{
          loadingPeticion = false;
          notifyListeners();
          print("error no existe ningun documento");
          estadoDefinitivo = 6;
        }
      }else{
        loadingPeticion = false;
        notifyListeners();
        print("no existe conexion con datasseqv2");
        estadoDefinitivo = 7;
      }
      
    } on SocketException catch (_) {
      loadingPeticion = false;
      notifyListeners();
      print("definitivament no existe conexion con datasseqv2");
      estadoDefinitivo = 8;
    }

    return estadoDefinitivo;

  }


  /* Future importarDatos()async{
           
    var estado ;
    var datoUser ;
    
    try {
      //trae el estado del internet
      final result = await InternetAddress.lookup('v2.datasseq.com');
      if (result.isNotEmpty) {
        
        loadingPeticion = true;
        var documento = await DB.obtenerDocumentoSesion();

        datoUser = await DB.obtenerSesionUsuario(documento[0]['documento']);

        notifyListeners();

        var resultadoSubirDatos = await subirDatos();
        developer.log((resultadoSubirDatos).toString());
        estado = resultadoSubirDatos;

        if(resultadoSubirDatos != null){

          try {

            if(estado["status_server"] == 200 && estado["respuesta"]=="OK"){
              
              await DB.borrarTablas();

              var dio = Dio();
              final respuesta = await dio.get(
                '$uri/app/importar',
                options: Options(
                  headers: {
                    HttpHeaders.authorizationHeader: 'Bearer ${datoUser[0]["token"].toString()}'
                  },
                ),
              );

              estado = respuesta.statusCode;

              if(estado==200){

                var dato = respuesta.data;

                DateTime fecha = DateTime.now();

                DB.insertarDatosFechas(fecha.toString());

                //await DB.borrarSecciones(documento[0]['documento']);
              
                for (var i = 0; i < dato["activos"].length; i++) {
                  DB.insertarDatosActivos(dato["activos"][i]["id"], dato["activos"][i]["codigo_clasificacion"].toString(), dato["activos"][i]["codigo_categoria"].toString(), dato["activos"][i]["placa_unico"].toString() );
                  
                  if(dato["activos"][i]["combustible"].isNotEmpty){
                    for (var f = 0; f < dato["activos"][i]["combustible"].length; f++) {
                      DB.insertarDatosInformacionActivo(
                          dato["activos"][i]["combustible"][f]["id"],
                          dato["activos"][i]["combustible"][f]["sello_actual"],
                          dato["activos"][i]["combustible"][f]["horometro_actual"],
                          dato["activos"][i]["combustible"][f]["kilometro_actual"],
                          dato["activos"][i]["horometro"] == false || dato["activos"][i]["horometro"] == null ? 0 : 1,
                          dato["activos"][i]["odometro"] == false || dato["activos"][i]["odometro"] == null ? 0 : 1,
                          dato["activos"][i]["id"]
                        );
                    } 
                  }else{
                    DB.insertarDatosInformacionActivo(
                          "",
                          "",
                          0,
                          0,
                          dato["activos"][i]["horometro"] == false ? 0 : 1,
                          dato["activos"][i]["odometro"] == false ? 0 : 1,
                          dato["activos"][i]["id"]
                        );
                  }

                }

                for (var i = 0; i < dato["conductores"].length; i++) {
                  DB.insertarDatosConductores(dato["conductores"][i]["id"], dato["conductores"][i]["name"].toString(), dato["conductores"][i]["numero_identificacion"].toString());
                }

                for (var i = 0; i < dato["colaboradores"].length; i++) {
                  DB.insertarDatosConductores(dato["colaboradores"][i]["id"], dato["colaboradores"][i]["name"].toString(), dato["colaboradores"][i]["numero_identificacion"].toString());
                }
                  

                for (var i = 0; i < dato["proveedores_combustible"].length; i++) {
                  DB.insertarDatosProveedores(dato["proveedores_combustible"][i]["id"], dato["proveedores_combustible"][i]["name"].toString(), dato["proveedores_combustible"][i]["numero_identificacion"].toString(), dato["proveedores_combustible"][i]["tipo_persona_id_codigo"].toString());
                }

                for (var i = 0; i < dato["puntos_tanqueo"].length; i++) {
                  DB.insertarDatosPuntoTanqueo(
                    dato["puntos_tanqueo"][i]["id"],
                    dato["puntos_tanqueo"][i]["nombre"].toString(),
                    dato["puntos_tanqueo"][i]["ficha_tecnica"] == null ? "" : dato["puntos_tanqueo"][i]["ficha_tecnica"].toString(),
                    dato["puntos_tanqueo"][i]["created_at"].toString(),
                    dato["puntos_tanqueo"][i]["updated_at"].toString(),
                    dato["puntos_tanqueo"][i]["tipo_tanque_id_label"].toString(),
                    dato["puntos_tanqueo"][i]["name"].toString(),
                    dato["puntos_tanqueo"][i]["fecha_calibracion"].toString()
                  );

                  DB.insertarDatosInformacionPuntoTanqueo(
                    dato["puntos_tanqueo"][i]["id"],
                    dato["puntos_tanqueo"][i]["municipio_id_label"].toString(), 
                    dato["puntos_tanqueo"][i]["tipo_combustible_id_label"].toString(), 
                    dato["puntos_tanqueo"][i]["total_ingreso"].toString(),
                    dato["puntos_tanqueo"][i]["total_egreso"].toString(),
                    dato["puntos_tanqueo"][i]["stock"]
                  );

                  for (var f = 0; f < dato["puntos_tanqueo"][i]["proyectos"].length; f++) {
<<<<<<< HEAD
<<<<<<< HEAD
                    DB.insertarDatosProyectosPuntoTanqueo(
=======
                     DB.insertarDatosProyectosPuntoTanqueo(
>>>>>>> developer
=======
                    DB.insertarDatosProyectosPuntoTanqueo(
>>>>>>> developer
                      dato["puntos_tanqueo"][i]["proyectos"][f]["proyecto_id"],
                      dato["puntos_tanqueo"][i]["id"],
                      dato["puntos_tanqueo"][i]["proyectos"][f]["id"], 
                      dato["puntos_tanqueo"][i]["proyectos"][f]["proyecto_id_label"].toString()
                      );
                  }

                }

                for (var f = 0; f < dato["frentes"].length; f++) {
                    DB.insertarDatosFrentes(
                      dato["frentes"][f]["id"], 
                      dato["frentes"][f]["proyecto_id"], 
                      dato["frentes"][f]["nombre_frente"], 
                      dato["frentes"][f]["estado"] == true ? 1 : 0,
                      dato["frentes"][f]["frente_principal"] == true ? 1 : 0,
                      );
                }

                loadingPeticion = false;
                notifyListeners();
              }else{
                loadingPeticion = false;
                notifyListeners();
                print("error al importar");
                //importarDatos();
              }


            }else{
              loadingPeticion = false;
              notifyListeners();
              //importarDatos();
              print("no se subio los datos 2");
            }

          } catch (e) {
            loadingPeticion = false;
            notifyListeners();
            print("error al borrar y al importar");
            //importarDatos();
          }
        }else{
          loadingPeticion = false;
          notifyListeners();
          print(estado);
          //importarDatos();
        }

      }
    } on SocketException catch (_)
    { 
      loadingPeticion = false;
      notifyListeners();
      //importarDatos();
      print('not connected');
    }

    loadingPeticion = false;
    notifyListeners();
    return estado;
  }
 */
  /*
   *@mehtod descargarDatosLocales
   *@funcionalidad Se encarga de descargar todos los datos locales internos con estado local
   */
  void descargarDatosLocales()async{
    
    var datosPreparadosCompartir = {};
    var datosIngresosCompartir = [];
    var datosEgresosCompartir = [];

    var datos = await DB.listarTodaTablaIngresos();

    //datos para compartir
    for (var i = 0; i < datos.length; i++) {
      if(datos.isNotEmpty){

        /* if (datos[i]["tipo_ingreso_egreso_texto"] == "INGRESO") {
          datosIngresosCompartir.add(datos[i]);
        }else{
          datosEgresosCompartir.add(datos[i]);
        } */

        if (datos[i]["tipo_ingreso_egreso_texto"] == "INGRESO") {
          
          datosIngresosCompartir.add(
            { 
              'id':datos[i]['id'],
              'fecha':datos[i]['fecha'],
              'tecnico_apoyo_id':datos[i]['tecnico_id'],
              'punto_tanqueo_id':datos[i]['punto_tanqueo_id'],
              'tipo_ingreso_id':datos[i]['tipo_registro_id'],
              'proveedor_id':datos[i]['proveedor_id'],
              'volumen':datos[i]['volumen'],
              'ingreso_consecutivo':datos[i]['consecutivo'],
              'num_factura':datos[i]['factura'],
              'num_guia':datos[i]['guia'],
              'placa':datos[i]['placa'],
              'nombre_conductor':datos[i]['conductor'],
              'usuario_registra_id':datos[i]['usuario_registra_id'],
              'nombre_adjunto' : datos[i]['nombreArchivo'],
              'factura' : datos[i]['adjunto'],
              'extension': datos[i]['extension'],
              'observacion':datos[i]['observacion'],
              "estado" : datos[i]['tipo_registro_id'] == '2007' ? null : true,
              "usuario_aprueba_id": ""
            }
          );
        }else{
          datosEgresosCompartir.add(
            { 
              'id':datos[i]['id'],
              'fecha':datos[i]['fecha'],
              'tecnico_apoyo_id':datos[i]['tecnico_id'],
              'proyecto_id':datos[i]['proyecto_id'],
              'tanque_proyecto_id':datos[i]['tanque_proyecto_id'],
              'frente_id': datos[i]['frente_id'],
              'activo_id':datos[i]['activo_id'],
              'conductor_id':datos[i]['conductor_egreso_id'],
              'tipo_egreso_id':datos[i]['tipo_registro_id'],
              'tanque_full': datos[i]['tanque_full'],
              'volumen':datos[i]['volumen'],
              'contador_tanqueo':datos[i]['numero_contador'],
              'sello_actual':datos[i]['sello'],
              'horometro_actual':datos[i]['horometro'],
              'kilometro_actual':datos[i]['kilometraje'],
              'observacion':datos[i]['observacion'],
              'usuario_registra_id':datos[i]['usuario_registra_id'],
              'inicio_operar':datos[i]['inicio_operar'] == 1 ? true : false,
              'nombre_adjunto' : datos[i]['nombreArchivo'],
              'documento' : datos[i]['adjunto'],
              'extension': datos[i]['extension'],
              "estado":datos[i]['tipo_registro_id'] == '2007' ? null : true,
              "egreso_consecutivo": "1202"
            }
          );
        }

      }
    }

    datosPreparadosCompartir = {
      'ingresos':datosIngresosCompartir,
      'egresos':datosEgresosCompartir,
    };

    developer.log(jsonEncode(datosPreparadosCompartir).toString());

    compartirDatos( jsonEncode(datosPreparadosCompartir) );
  }

  /*
   *@method subirDatos
   *@funcionalidad Se encarga de subir los datos con la base de datos datasseqv2
   */
  Future subirDatos()async{

    var datoUser ;
    Object datosPreparadosExportar ={};
    var datosIngresosExportar = [];
    var datosEgresosExporta = [];
    var estadoPeticion ;

    var datos = await DB.listarTodaTablaIngresosLocal();
    var documento = await DB.obtenerDocumentoSesion();
    datoUser = await DB.obtenerSesionUsuario(documento[0]['documento']);
    developer.log(jsonEncode(datoUser).toString());

    //developer.log(jsonEncode(datos).toString());

    //datos para exportar
    if(datos.isNotEmpty){
      for (var i = 0; i < datos.length; i++) {
        if (datos[i]["tipo_ingreso_egreso_texto"] == "INGRESO") {
          
          datosIngresosExportar.add(
            { 
              'id':datos[i]['id'],
              'fecha':datos[i]['fecha'],
              'tecnico_apoyo_id':datos[i]['tecnico_id'],
              'punto_tanqueo_id':datos[i]['punto_tanqueo_id'],
              'tipo_ingreso_id':datos[i]['tipo_registro_id'],
              'proveedor_id':datos[i]['proveedor_id'],
              'volumen':datos[i]['volumen'],
              'ingreso_consecutivo':datos[i]['consecutivo'],
              'num_factura':datos[i]['factura'],
              'num_guia':datos[i]['guia'],
              'placa':datos[i]['placa'],
              'nombre_conductor':datos[i]['conductor'],
              'usuario_registra_id':datos[i]['usuario_registra_id'],
              'nombre_adjunto' : datos[i]['nombreArchivo'],
              'factura' : datos[i]['adjunto'],
              'extension': datos[i]['extension'],
              'observacion':datos[i]['observacion'],
              "estado" : datos[i]['tipo_registro_id'] == '2007' ? null : true,
              "usuario_aprueba_id": ""
            }
          );
        }else{
          datosEgresosExporta.add(
            { 
              'id':datos[i]['id'],
              'fecha':datos[i]['fecha'],
              'tecnico_apoyo_id':datos[i]['tecnico_id'],
              'proyecto_id':datos[i]['proyecto_id'],
              'tanque_proyecto_id':datos[i]['tanque_proyecto_id'],
              'frente_id': datos[i]['frente_id'],
              'activo_id':datos[i]['activo_id'],
              'conductor_id':datos[i]['conductor_egreso_id'],
              'tipo_egreso_id':datos[i]['tipo_registro_id'],
              'tanque_full': datos[i]['tanque_full'],
              'volumen':datos[i]['volumen'],
              'contador_tanqueo':datos[i]['numero_contador'],
              'sello_actual':datos[i]['sello'],
              'horometro_actual':datos[i]['horometro'],
              'kilometro_actual':datos[i]['kilometraje'],
              'observacion':datos[i]['observacion'],
              'usuario_registra_id':datos[i]['usuario_registra_id'],
              'inicio_operar':datos[i]['inicio_operar'] == 1 ? true : false,
              'nombre_adjunto' : datos[i]['nombreArchivo'],
              'documento' : datos[i]['adjunto'],
              'extension': datos[i]['extension'],
              "estado":datos[i]['tipo_registro_id'] == '2007' ? null : true,
              "egreso_consecutivo": "1202"
            }
          );
        }
      }
    }

    datosPreparadosExportar = {
      'ingresos':datosIngresosExportar,
      'egresos':datosEgresosExporta,
    };

    //developer.log(jsonEncode(datosPreparadosExportar).toString());

    try {
      obtenerSesion();
      var body ; 
      body = jsonEncode(datosPreparadosExportar);
      var dio = Dio();
      final respuesta = await dio.post(
        '$uri/app/sincronizar_combustible',
        data: body,
        options: Options(
          headers: {
            HttpHeaders.authorizationHeader: 'Bearer ${datoUser[0]["token"].toString()}'
          },
        ),
      );

      //print(respuesta.toString());
      estadoPeticion = await respuesta.data;

      developer.log(jsonEncode(estadoPeticion["status_server"]).toString());

      if( estadoPeticion["status_server"] == 200 && estadoPeticion["respuesta"]=="OK"){
        DB.cambiarEstadoLocalASincronizado(datosPreparadosExportar);
        
        return estadoPeticion;
      }
      else{
        return estadoPeticion;
      }

    } catch (e) {
      print(e.toString());
      return estadoPeticion;
    }
  }

  /* void cerrarRegistrosPasados(int opc) async {
    DateTime now = DateTime.now();
    DateTime now2 = DateTime.now();
    DateTime now3 = DateTime.now();

    now = new DateTime(now.year, now.month, now.day-15); 

    var fecha = now.toString();
    var fecha2 = now2.toString();
    var fecha3 = now3.toString();

    Database? db = await instance.database;

    if(opc==1){
      //Se cierran los controles diarios anteriores a la fecha actual
      await db?.execute('UPDATE ControlDiario SET estado="LOCAL - CERRADO" WHERE fecha<"$fecha" AND estado = "LOCAL - ABIERTO" ');
      //Se eliminan los controles diarios anterioes a 15 dias de la fecha actual
      await db?.execute('DELETE FROM ControlDiario WHERE fecha<"$fecha2" ');
      await db?.execute('DELETE FROM DetalleAlimentacion WHERE fecha<"$fecha2" ');
    }
    else{
      await db?.execute('UPDATE ControlDiario SET estado="EN EL SERVIDOR" WHERE estado = "LOCAL - CERRADO" ');
    }
  } */

  /*
   *@method  compartirDatos
   *@funcionalidad Se encarga de compartir la informacion local
   */
  Future<void> compartirDatos(data) async {
  
    escribirDatos(data);

    Directory? directory;

    directory = await getApplicationDocumentsDirectory();

    final String localPath ='${directory.path}/datos.json';

    await Future.delayed(Duration(seconds: 1));

    await Share.shareFiles([localPath]);
    
  }


  /*
   *@method lugarRuta
   *@funcionalidad Se encarga de traer la ruta de la carpeta documentos en el telfono
   */
  Future<String> get lugarRuta async {
    var directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  /*
   *@method lugarArchivo
   *@funcionalidad se encarga de crear el archivo en el directorio elegido
   */
  Future<File> get lugarArchivo async {
    final path = await lugarRuta;
    return File('$path/datos.json');
  }

  /*
   *@method escribirDatos
   *@funcionalidad Se encarga de escribir la informacion en el archivo creado
   */
  Future escribirDatos(data) async {
    final file = await lugarArchivo;
    // Escribir el archivo
    return file.writeAsString(data.toString());
    
  }


}