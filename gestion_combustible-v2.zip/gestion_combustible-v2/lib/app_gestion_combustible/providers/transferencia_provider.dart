import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'dart:developer' as developer;

class TransferenciaProvider extends ChangeNotifier{

  late Map<String, dynamic> headers = {} ;

  List<dynamic> listaPuntoTanquoEgreso =[];
  List<dynamic> listaPuntoTanquoIngreso =[];

  DateTime fecha = DateTime.now();
  var fechaDia = "";
  var fechaMes = "";
  var fechaAno = "";
  var datoUser = [];
  String base64string ="" ;
  var imagen = null ; 
  String mensajeAdjuntoDocumentos ="";
  String extension="";


  desacoplaFecha(){
    var fechaotro = DateFormat('yyyy-MM-dd').format(fecha);
    DateTime date = DateTime.parse(fechaotro);
    fechaAno = date.year.toString(); //Año
    fechaMes = date.month.toString(); //mes
    fechaDia = date.day.toString(); //año
  }
 

  var puntoTanquoEgresoSeleccionadoId = null;
  var puntoTanqueoEgresoSeleccionadoTexto = null;
  var puntoTanquoEgresoSeleccionadoCompleto = null;

  var puntoTanquoIngresoSeleccionadoId = null;
  var puntoTanqueoIngresoSeleccionadoTexto = null;
  var puntoTanquoIngresoSeleccionadoCompleto = null;

  var proveedorSeleccionadoId = null;
  var proveedorSeleccionadoTexto = null;
  var proveedorSeleccionadoCompleto = null;

  var isleroSeleccionadoId = null;
  var isleroSeleccionadoTexto = null;
  var isleroSeleccionadoCompleto = null;

  bool spinnerProyecto = false;
  List<dynamic> listaProyectos = [];
  var proyectoId = null ;
  var tanquProyectoId = null;
  var proyectoSeleccionadoCompleto = null;
  var proyectoTexto = null;
  
  int consecutivo = 1;
  String stockPuntoTanqueEgreso = "0";
  String stockPuntoTanqueIngreso = "0";
  double volumen = 0.0;
  String tipoCombustibleEgreso = "";
  String tipoCombustibleIngreso ="";
  String conductor = "";
  String contadorTanqueEgreso ="";
  String placa = "";
  String observacion = "";

  bool spinnerPuntoTanqueo = false;
  bool mostrarMensajeAlertaTipoCombustible = false;
  /*
   *@method getHeaders
   *@funcionalidad Se encarga de obtener los datos del header
   */
  getHeaders() => headers;

  /*
   *@method setHeaders
   *@funcionalidad Se encarga de asignar el valor a la variable
   */
  setHeaders(header){
    headers = header;
  }

  /*
   *@method obtenerPuntosTanqueo
   *@funcionalidad Se encarga de obtener todos los puntos de tanqueo
   */
  void obtenerPuntosTanqueoEgreso()async{
    spinnerPuntoTanqueo = true;
    listaPuntoTanquoEgreso.clear();

    var datos = await DB.mostrarTodosPuntosTanqueo();
    
    for (var i = 0; i < datos.length; i++) {
      listaPuntoTanquoEgreso.add("${datos[i]["id"]} ${datos[i]["nombre"]}");
    }
    spinnerPuntoTanqueo = false;
    notifyListeners();
  }

  /*
   *@method obtenerPuntosTanqueoIngreso
   *@funcionalidad Se encarga de obtener todos los puntos de tanqueo
   */
  void obtenerPuntosTanqueoIngreso()async{
    spinnerPuntoTanqueo = true;
    listaPuntoTanquoIngreso.clear();

    var datos = await DB.mostrarTodosPuntosTanqueo();
    
    for (var i = 0; i < datos.length; i++) {
      listaPuntoTanquoIngreso.add("${datos[i]["id"]} ${datos[i]["nombre"]}");
    }
    spinnerPuntoTanqueo = false;
    notifyListeners();
  }

  /*
   *@method setPuntoTanquoEgresoSeleccionado
   *@funcionalidad Se encarga de asignar el valor
   */
  setPuntoTanquoEgresoSeleccionado(puntoTanquoSeleccionado){
    if(puntoTanquoSeleccionado == null){
      puntoTanquoEgresoSeleccionadoCompleto = null ;
      puntoTanquoEgresoSeleccionadoId = null;
      puntoTanqueoEgresoSeleccionadoTexto = null;
      stockPuntoTanqueEgreso="0";
      tipoCombustibleEgreso = "";
      mostrarMensajeAlertaTipoCombustible = false;

      listaPuntoTanquoIngreso = [];
      puntoTanqueoIngresoSeleccionadoTexto = null;
      puntoTanquoIngresoSeleccionadoId = null;
      puntoTanquoIngresoSeleccionadoCompleto = null;
      stockPuntoTanqueIngreso ="0";

      proyectoSeleccionadoCompleto = null;
      tanquProyectoId = null;
      listaProyectos = [];

      notifyListeners();
    }else{
      puntoTanquoEgresoSeleccionadoCompleto = puntoTanquoSeleccionado;
      var dato = puntoTanquoSeleccionado.split(' ');
      puntoTanquoEgresoSeleccionadoId = int.parse(dato[0]);
      obtenerInformacioPuntoTanqueoEgreso(int.parse(dato[0]));
      obtenerProyectosPuntoTanqueo(int.parse(dato[0]));
      obtenerPuntosTanqueoIngreso();
      notifyListeners();
    }
  }

    /*
   *@method obtenerProyectosPuntoTanqueo
   *@funcionalidad Se encarga de obtener los proyectos
   */
  void obtenerProyectosPuntoTanqueo(valor)async{

    spinnerProyecto = true;
    proyectoSeleccionadoCompleto= null;
    tanquProyectoId = null;
    listaProyectos.clear();
    
    var datos = await DB.mostrarTodosProyectoPorPuntosTanqueo(valor);
    if(datos.isNotEmpty){
      for (var i = 0; i < datos.length; i++) {
        listaProyectos.add("${datos[i]["proyecto_id"]}. ${datos[i]["id"]}. ${datos[i]["proyecto_nombre"]}");
      }
      spinnerProyecto = false;
      notifyListeners();
    }else{
      spinnerProyecto = false;
      notifyListeners();
    }
    
  }

    /*
   *@method: setProyectoSeleccionado
   *@funcionalida: Se encarga de obtener el valor para asignarlo a la variable
   */
  setProyectoSeleccionado(proyectoSeleccionado ){
    if(proyectoSeleccionado == null){
      proyectoSeleccionadoCompleto = null;
      proyectoTexto = null;
      notifyListeners();
    }else{
      proyectoSeleccionadoCompleto = proyectoSeleccionado;
      var dato = proyectoSeleccionado.split('.');
      proyectoId = int.parse(dato[1].toString().trim());
      tanquProyectoId = int.parse(dato[0].toString().trim());
      proyectoTexto = dato[2].toString().trim();
      notifyListeners();
    }
  }


  /*
   *@method obtenerInformacioPuntoTanqueoEgreso
   *@funcionalidad Se encarga de obtener los valores de la ubicacion y el stock del punto de tanqueo
   */
  void obtenerInformacioPuntoTanqueoEgreso(valor)async{
      
    stockPuntoTanqueEgreso = "0";
    tipoCombustibleEgreso = "";

    var datos = await DB.mostrarTodosInformacionPorPuntosTanqueo(valor);

    if(datos.isNotEmpty){
      stockPuntoTanqueEgreso = datos[0]["stock"] == "" ? "0.0" : double.parse(datos[0]["stock"].toString()).toStringAsFixed(2);
      tipoCombustibleEgreso = datos[0]["tipo_combustible"] == "" ? "" : datos[0]["tipo_combustible"].toString();
      notifyListeners();
    }
  }

  /*
   *@method setPuntoTanquoIngresoSeleccionado
   *@funcionalidad Se encarga de asignar el valor
   */
  setPuntoTanquoIngresoSeleccionado(puntoTanquoSeleccionado){
    if(puntoTanquoSeleccionado == null){
      puntoTanquoIngresoSeleccionadoCompleto = null ;
      puntoTanquoIngresoSeleccionadoId = null;
      puntoTanqueoIngresoSeleccionadoTexto = null;
      stockPuntoTanqueIngreso="0";
      mostrarMensajeAlertaTipoCombustible = false;
      notifyListeners();
    }else{
      puntoTanquoIngresoSeleccionadoCompleto = puntoTanquoSeleccionado;
      var dato = puntoTanquoSeleccionado.split(' ');
      puntoTanquoIngresoSeleccionadoId = int.parse(dato[0]);
      obtenerInformacioPuntoTanqueoIngreso(int.parse(dato[0]));
      notifyListeners();
    }
  }

  /*
   *@method obtenerInformacioPuntoTanqueoIngreso
   *@funcionalidad Se encarga de obtener los valores de la ubicacion y el stock del punto de tanqueo
   */
  void obtenerInformacioPuntoTanqueoIngreso(valor)async{

    stockPuntoTanqueIngreso = "0";

    var datos = await DB.mostrarTodosInformacionPorPuntosTanqueo(valor);
   
    if(datos.isNotEmpty){
      stockPuntoTanqueIngreso = datos[0]["stock"] == "" ? "0.0" : double.parse(datos[0]["stock"].toString()).toStringAsFixed(2);
      tipoCombustibleIngreso = datos[0]["tipo_combustible"] == "" ? "" : datos[0]["tipo_combustible"].toString();
      validarTiposCombustible();
      notifyListeners();
    }
  }

  /*
   * @method validarTiposCombustible
   * @funcionalidad Se encarga de validar los tipos de tanqueo
   */
  validarTiposCombustible()async{
    if( tipoCombustibleEgreso.toUpperCase().toString() == tipoCombustibleIngreso.toUpperCase().toString()){
      mostrarMensajeAlertaTipoCombustible = false;
      notifyListeners();
    }else{
      mostrarMensajeAlertaTipoCombustible = true;
      notifyListeners();
    }
  }

  /*
   *@method setVolumen
   *@funcionalidad Se encarga de asignar el valor al volumen 
   */
  setVolumen(valor){
    if(valor == null || valor.isEmpty){
      volumen = 0.0;
      notifyListeners();
    }
    else{
      volumen = double.parse(valor);
      notifyListeners();
    }
  }

  /*
   *@method setConductor
   *@funcionalidad Se encarga de asignar el valor del conductor 
   */
  setConductor(valor){
    if(valor == null || valor.isEmpty){
      conductor = "";
      notifyListeners();
    }
    else{
      conductor = valor;
      notifyListeners();
    }
  }

  /*
   *@method setContador
   *@funcionalidad Se encarga de asingar los valores 
   */
  setContador(valor){
    if(valor == null || valor.isEmpty){
      contadorTanqueEgreso = "";
      notifyListeners();
    }
    else{
      contadorTanqueEgreso = valor;
      notifyListeners();
    }
  }

  /*
   *@method setPlaca
   *@funcionalidad Se encarga de asingar los valores 
   */
  setPlaca(valor){
    if(valor == null || valor.isEmpty){
      placa = "";
      notifyListeners();
    }
    else{
      placa = valor;
      notifyListeners();
    }
  }

  /*
   *@method setObservaciones
   *@funcionalidad Se encarga de asignar el valor a la observacion 
   */
  setObservaciones(valor){
    if(valor == null || valor.isEmpty){
      observacion = "";
      notifyListeners();
    }
    else{
      observacion = valor;
      notifyListeners();
    }
  }


  /*
   *@method obtenerConsecutivoIngreso
   *@funcionalidad Se encarga de obtener el consecutivo de los datos
   */
  void obtenerSession() async{
    var documento = await DB.obtenerDocumentoSesion();

    datoUser = await DB.obtenerSesionUsuario(documento[0]['documento']);
    notifyListeners();
  }


  seleccionarImagen(opcion, context) async{
    
    final ImagePicker imgpicker = ImagePicker();
    String imagepath = "";

    switch (opcion) {
      case 0:
        
        try {
          var archivoSeleccionado = await imgpicker.pickImage(source: ImageSource.camera, maxWidth: 1080,
      maxHeight: 720 , imageQuality: 80);

          if(archivoSeleccionado != null){
            imagepath = archivoSeleccionado.path;

            var informacionImagen = [];
            informacionImagen = archivoSeleccionado.name.split('.');
            extension = informacionImagen[1];

            File imagefile = File(imagepath); //convert Path to File
            Uint8List imagebytes = await imagefile.readAsBytes(); //convert to bytes
            base64string = base64.encode(imagebytes); //convert bytes to base64 string
            developer.log(base64string.toString());

            //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

            imagen =  base64.decode(base64string);

            Navigator.pop(context);

            mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
            notifyListeners();
            return true;
          }
          else{
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }

        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos = "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;
      case 1:

        try {
          var archivoSeleccionado = await imgpicker.pickImage(source: ImageSource.gallery, maxWidth: 1080,
      maxHeight: 720 , imageQuality: 80);


          if(archivoSeleccionado != null){

            var informacionImagen = [];
            
            informacionImagen = archivoSeleccionado.name.split('.');

            if ( informacionImagen[1] == "jpg" || informacionImagen[1] == "png") {
              imagepath = archivoSeleccionado.path;
              extension = informacionImagen[1];

              File imagefile = File(imagepath); //convert Path to File
              Uint8List imagebytes = await imagefile.readAsBytes(); //convert to bytes
              base64string = base64.encode(imagebytes); //convert bytes to base64 string

              //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

              imagen =  base64.decode(base64string);

              Navigator.pop(context);
              mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
              notifyListeners();
              return true;
            }else{
              Navigator.pop(context);
              mensajeAdjuntoDocumentos = "La imagen seleccionada tiene que ser de formato jpg.";
              notifyListeners();
              return false;
            }

            
          }
          else{
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }

        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos = "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;

      default:
    }

    

  }



  /*
   *@method guardarFormularioEgreso
   *@funcionalidad Se encarga de enviar los datos para ser guardados
   */
  Future<bool> guardarFormularioTransferencia()async{

    print(contadorTanqueEgreso.toString());
    
    var totalStockEgreso = double.parse(stockPuntoTanqueEgreso)- volumen;

    if(totalStockEgreso < 0 || stockPuntoTanqueEgreso == 0){
      return false;
    }else{

      obtenerConsecutivoIngreso();

      var puntoTanqueoFormateado = puntoTanquoEgresoSeleccionadoCompleto.toString().split(' ');
      var horaFormateada = fecha.toString().substring(10,16);
      var nombreArchivo = '${DateFormat('yyyy-MM-dd').format(fecha)}-EGT-${horaFormateada.toString().trim()}-${puntoTanqueoFormateado[1].toString().trim()}';

      //guardamos un egreso
      await DB.insertarDatosIngresosEgresos(
        fecha, 
         DateFormat('yyyy-MM-dd').format(fecha).toString(),
        "0",
        puntoTanquoEgresoSeleccionadoId.toString(),
        puntoTanquoEgresoSeleccionadoCompleto.toString(), 
        "", 
        "", 
        volumen.toString(), 
        "", 
        "", 
        conductor.toString(), 
        placa.toString(), 
        observacion.toString(), 
        datoUser[0]["id"].toString(),
        datoUser[0]["nombreUsuario"].toString(),  
        datoUser[0]["id"].toString(),
        datoUser[0]["nombreUsuario"].toString(), 
        "2007",
        "EGRESO",
        proyectoId.toString(),
        tanquProyectoId.toString(),
        proyectoSeleccionadoCompleto.toString(),
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        contadorTanqueEgreso.toString(),
        "",
        "",
        "",
        "",
        base64string.toString(),
        nombreArchivo.toString(),
        extension.toString(),
        tipoCombustibleEgreso.toString(),
        "",
        "0",
        "LOCAL"
        );
      
      await DB.insertarDatosInformacionPuntoTanqueo(
        puntoTanquoEgresoSeleccionadoId,
        "",
        tipoCombustibleEgreso.toString(),
        "0",
        "0",
        totalStockEgreso
      );

      //guardamos un ingreso      
      await DB.insertarDatosIngresosEgresos(
        fecha, 
        DateFormat('yyyy-MM-dd').format(fecha).toString(),
        consecutivo.toString(),
        puntoTanquoIngresoSeleccionadoId.toString(),
        puntoTanquoIngresoSeleccionadoCompleto.toString(), 
        "", 
        "", 
        volumen.toString(), 
        "", 
        "", 
        conductor.toString(), 
        placa.toString(), 
        observacion.toString(), 
        datoUser[0]["id"].toString(),
        datoUser[0]["nombreUsuario"].toString(),  
        datoUser[0]["id"].toString(),
        datoUser[0]["nombreUsuario"].toString(), 
        "2007",
        "INGRESO",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        contadorTanqueEgreso.toString(),
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        tipoCombustibleEgreso.toString(),
        "",
        "0",
        "LOCAL"
      );

      var totalStockIngreso = double.parse(stockPuntoTanqueIngreso) + volumen;

      await DB.insertarDatosInformacionPuntoTanqueo(
        puntoTanquoIngresoSeleccionadoId,
        "",
        tipoCombustibleIngreso.toString(),
        "0",
        "0",
        totalStockIngreso
      );

      obtenerConsecutivoIngreso();

      notifyListeners();
      return true;   

    }
  }


  /*
   *@method obtenerConsecutivoIngreso
   *@funcionalidad Se encarga de obtener el consecutivo de los datos
   */
  void obtenerConsecutivoIngreso() async{
    int consecutivoFinal = 0;
    var resultadoConcecutivo = await DB.obtenerConsecutivoIngreso();
    
    if (resultadoConcecutivo.isNotEmpty) {
      String valorConsecutivo = resultadoConcecutivo[0]["consecutivo"] .toString();
      consecutivo = (int.parse(valorConsecutivo) + 1);
      notifyListeners();
      
    }else{
      consecutivo = consecutivoFinal + 1;
      notifyListeners();
    }
  }

  /*
   *@method reiniciarFormulario
   *@funcionalidad Se encarga de reiniciar los valores del formulario 
   */
  void reiniciarFormulario(){
    puntoTanquoEgresoSeleccionadoId = null;
    puntoTanqueoEgresoSeleccionadoTexto = null;
    puntoTanquoEgresoSeleccionadoCompleto = null;

    proveedorSeleccionadoId = null;
    proveedorSeleccionadoTexto = null;
    proyectoSeleccionadoCompleto = null;
    listaProyectos = [];

    listaPuntoTanquoIngreso = [];
    puntoTanquoIngresoSeleccionadoId = null;
    puntoTanqueoIngresoSeleccionadoTexto = null;
    puntoTanquoIngresoSeleccionadoCompleto = null;

    mostrarMensajeAlertaTipoCombustible = false;
    stockPuntoTanqueEgreso = "0.0";
    stockPuntoTanqueIngreso = "0.0";
    tipoCombustibleEgreso = "";
    tipoCombustibleIngreso = "";
    
    imagen = null;
    base64string ="";
    mensajeAdjuntoDocumentos="";
    notifyListeners();
  }

}