import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:developer' as developer;
import 'package:flutter_image_compress/flutter_image_compress.dart';

class IngresoProvider extends ChangeNotifier{

  late Map<String, dynamic> headers = {} ;

  List<dynamic> listaPuntoTanquo =[];
  List<dynamic> listaProvedores =[];
  List<dynamic> listaUsuarios =[];

  DateTime fecha = DateTime.now();
  var fechaDia = "";
  var fechaMes = "";
  var fechaAno = "";
  var datoUser = [];

  String base64string ="" ;
  var imagen = null ; 
  String extension="";
  String mensajeAdjuntoDocumentos ="";


  desacoplaFecha(){
    var fechaotro = DateFormat('yyyy-MM-dd').format(fecha);
    DateTime date = DateTime.parse(fechaotro);
    fechaAno = date.year.toString(); //Año
    fechaMes = date.month.toString(); //mes
    fechaDia = date.day.toString(); //año
  }
 

  var puntoTanquoSeleccionadoId = null;
  var puntoTanqueoSeleccionadoTexto = null;
  var puntoTanquoSeleccionadoCompleto = null;

  var proveedorSeleccionadoId = null;
  var proveedorSeleccionadoTexto = null;
  var proveedorSeleccionadoCompleto = null;

  var isleroSeleccionadoId = null;
  var isleroSeleccionadoTexto = null;
  var isleroSeleccionadoCompleto = null;
  
  bool checkCompraRemanente = true;
  String ubicacionPuntoTanqueo = "--";
  String stock = "0";
  String tipoCombustible = "";
  double volumen = 0.0;
  String factura = "";
  String guia = "";
  String conductor = "";
  String placa = "";
  String observacion = "NINGUNO";
  int consecutivo = 0;

  bool spinnerPuntoTanqueo = false;
  bool spinnerPuntoProveedor = false;
  bool spinnerIslero = false;

  /*
   *@method getHeaders
   *@funcionalidad Se encarga de obtener los datos del header
   */
  getHeaders() => headers;

  /*
   *@method setHeaders
   *@funcionalidad Se encarga de asignar el valor a la variable
   */
  setHeaders(header){
    headers = header;
  }

  /*
   *@method obtenerPuntosTanqueo
   *@funcionalidad Se encarga de obtener todos los puntos de tanqueo
   */
  void obtenerPuntosTanqueo()async{
    spinnerPuntoTanqueo = true;
    listaPuntoTanquo.clear();

    var datos = await DB.mostrarTodosPuntosTanqueo();
    
    for (var i = 0; i < datos.length; i++) {
      listaPuntoTanquo.add("${datos[i]["id"]} ${datos[i]["nombre"]}");
    }
    spinnerPuntoTanqueo = false;
    notifyListeners();
  }

  /*
   *@method setPuntoTanquoSeleccionado
   *@funcionalidad Se encarga de asignar el valor
   */
  setPuntoTanquoSeleccionado(puntoTanquoSeleccionado ){
    if(puntoTanquoSeleccionado == null){
      puntoTanquoSeleccionadoCompleto = null ;
      puntoTanquoSeleccionadoId = null;
      puntoTanqueoSeleccionadoTexto = null;
      ubicacionPuntoTanqueo = "--";
      stock="0";
      tipoCombustible = "";
      notifyListeners();
    }else{
      puntoTanquoSeleccionadoCompleto = puntoTanquoSeleccionado;
      var dato = puntoTanquoSeleccionado.split(' ');

      puntoTanquoSeleccionadoId = int.parse(dato[0]);
      puntoTanqueoSeleccionadoTexto = dato[1];

      obtenerInformacioPuntoTanqueo(int.parse(dato[0]));
      notifyListeners();
    }
  }


  /*
   *@method obtenerInformacioPuntoTanqueo
   *@funcionalidad Se encarga de obtener los valores de la ubicacion y el stock del punto de tanqueo
   */
  void obtenerInformacioPuntoTanqueo(valor)async{

    ubicacionPuntoTanqueo ="--";
    stock = "0";
    tipoCombustible ="";

    var datos = await DB.mostrarTodosInformacionPorPuntosTanqueo(valor);
    
    if(datos.isNotEmpty){

      ubicacionPuntoTanqueo =datos[0]["municipio"] == "" ? "--" : datos[0]["municipio"].toString();
      stock = datos[0]["stock"] == "" ? "0.0" : double.parse(datos[0]["stock"].toString()).toStringAsFixed(1);
      tipoCombustible =datos[0]["tipo_combustible"] == "" ? "" : datos[0]["tipo_combustible"].toString();
      notifyListeners();
    }
  }


  /*
   *@method obtenerIslero
   *@funcionalidad Se encarga de obtener todos los isleros o tecnico
   */
  void obtenerIslero() async{
    spinnerIslero = true;
    listaUsuarios.clear();
    var datos = await DB.mostrarTodosConductores();
    
    for (var i = 0; i < datos.length; i++) {
      listaUsuarios.add("${datos[i]["id"]} ${datos[i]["name"]}");
    }
    spinnerIslero = false;
    notifyListeners();
  }

  /*
   *@method setIsleroSeleccionado
   *@funcionalidad Se encarga de asignar el valor al islero
   */
  setIsleroSeleccionado( valor ){
    if(valor == null){
      isleroSeleccionadoCompleto = null;
      isleroSeleccionadoId = null;
      isleroSeleccionadoTexto = null;
      notifyListeners();
    }else{
      isleroSeleccionadoCompleto = valor;
      var dato = valor.split(' ');
      isleroSeleccionadoId = int.parse(dato[0]);
      isleroSeleccionadoTexto = dato[1];
      notifyListeners();
    }
  }


  /*
   *@method obtenerProveedores
   *@funcionalidad Se encarga de obtener todos los proveedores
   */
  void obtenerProveedores()async{
    spinnerPuntoProveedor = true;
    listaProvedores.clear();

    var datos = await DB.mostrarTodosProveedores();
    
    for (var i = 0; i < datos.length; i++) {
      listaProvedores.add("${datos[i]["id"]} ${datos[i]["name"]}");
    }
    spinnerPuntoProveedor = false;
    notifyListeners();
  }

  /*
   *@method setPuntoTanquoSeleccionado
   *@funcionalidad Se encarga de asignar el valor
   */
  setProveedorSeleccionado(proveedor){
    if(proveedor == null){
      proveedorSeleccionadoCompleto = null ;
      proveedorSeleccionadoId = null;
      proveedorSeleccionadoTexto = null;
      notifyListeners();
    }else{
      proveedorSeleccionadoCompleto = proveedor;
      var dato = proveedor.split(' ');
      proveedorSeleccionadoId = int.parse(dato[0]);
      proveedorSeleccionadoTexto = dato[1];
      notifyListeners();
    }
  }

  /*
   *@method setVolumen
   *@funcionalidad Se encarga de asignar el valor al volumen 
   */
  setVolumen(valor){
/*     final validacion = RegExp('^[0-9.]');
    
    print(validacion.hasMatch(valor)); */
    if(valor == null || valor.isEmpty){
      volumen = 0.0;
      notifyListeners();
    }
    else{
      volumen = double.parse(valor);
      notifyListeners();
    }
  }

  /*
   *@method setFactura
   *@funcionalidad Se encarga de asignar el valor a la factura 
   */
  setFactura(valor){
    if(valor == null || valor.isEmpty){
      factura = "";
      notifyListeners();
    }
    else{
      factura = valor;
      notifyListeners();
    }
  }

  /*
   *@method setGuia
   *@funcionalidad Se encarga de asignar el valor de la guia 
   */
  setGuia(valor){
    if(valor == null || valor.isEmpty){
      guia = "";
      notifyListeners();
    }
    else{
      guia = valor;
      notifyListeners();
    }
  }

  /*
   *@method setConductor
   *@funcionalidad Se encarga de asignar el valor del conductor 
   */
  setConductor(valor){
    if(valor == null || valor.isEmpty){
      conductor = "";
      notifyListeners();
    }
    else{
      conductor = valor;
      notifyListeners();
    }
  }

  /*
   *@method setPlacaVehiculo
   *@funcionalidad Se encarga de asignar el valor a la placa del vehiculo 
   */
  setPlacaVehiculo(valor){
    if(valor == null || valor.isEmpty){
      placa = "";
      notifyListeners();
    }
    else{
      placa = valor;
      notifyListeners();
    }
  }

  /*
   *@method setObservaciones
   *@funcionalidad Se encarga de asignar el valor a la observacion 
   */
  setObservaciones(valor){
    if(valor == null || valor.isEmpty){
      observacion = "";
      notifyListeners();
    }
    else{
      observacion = valor;
      notifyListeners();
    }
  }

  /*
   *@method setCheckCompraRemanente
   *@funcionalidad Se encarga de asignar el valor al checkCompraRemanente
   */
  setCheckCompraRemanente(valor){
    checkCompraRemanente = valor;
    notifyListeners();
  }


  /*
   *@method obtenerConsecutivoIngreso
   *@funcionalidad Se encarga de obtener el consecutivo de los datos
   */
  void obtenerSession() async{
    var documento = await DB.obtenerDocumentoSesion();
    datoUser = await DB.obtenerSesionUsuario(documento[0]['documento']);
    notifyListeners();
  }
  
  /*
   *@method seleccionarImagen
   *@funcionalidad Se encarga de seleccionar la imagen
   */
  seleccionarImagen(opcion, context) async{
    final ImagePicker imgpicker = ImagePicker();
    String imagepath = "";

    switch (opcion) {
      case 0:
        
        try {
          var archivoSeleccionado = await imgpicker.pickImage(source: ImageSource.camera, maxWidth: 1080,
      maxHeight: 720 , imageQuality: 80);

          if(archivoSeleccionado != null){
            imagepath = archivoSeleccionado.path;

            var informacionImagen = [];
            informacionImagen = archivoSeleccionado.name.split('.');
            extension = informacionImagen[1];


            File imagefile = File(imagepath); //convert Path to File
            Uint8List imagebytes = await imagefile.readAsBytes(); //convert to bytes
            base64string = base64.encode(imagebytes); //convert bytes to base64 string
            developer.log(base64string.toString());

            //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

            imagen =  base64.decode(base64string);

            Navigator.pop(context);

            mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
            notifyListeners();
            return true;
          }
          else{
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }

        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos = "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;
      case 1:

        try {
          var archivoSeleccionado = await imgpicker.pickImage(source: ImageSource.gallery, maxWidth: 1080,
      maxHeight: 720 , imageQuality: 80);


          if(archivoSeleccionado != null){

            var informacionImagen = [];
            
            informacionImagen = archivoSeleccionado.name.split('.');

            if ( informacionImagen[1] == "jpg" || informacionImagen[1] == "png") {
              imagepath = archivoSeleccionado.path;
              extension = informacionImagen[1];

              File imagefile = File(imagepath); //convert Path to File
              Uint8List imagebytes = await imagefile.readAsBytes(); //convert to bytes
              base64string = base64.encode(imagebytes); //convert bytes to base64 string
            developer.log(base64string.toString());

              //Uint8List decodedbytes = base64.decode(base64string); //decodifica la imagen

              imagen =  base64.decode(base64string);

              Navigator.pop(context);
              mensajeAdjuntoDocumentos = "Imagen adjuntada con exito.";
              notifyListeners();
              return true;
            }else{
              Navigator.pop(context);
              mensajeAdjuntoDocumentos = "La imagen seleccionada tiene que ser de formato jpg.";
              notifyListeners();
              return false;
            }

            
          }
          else{
            Navigator.pop(context);
            mensajeAdjuntoDocumentos = "Ninguna imagen se seleccionó.";
            notifyListeners();
            return false;
          }

        } catch (e) {
          Navigator.pop(context);
          mensajeAdjuntoDocumentos = "Error al momento de seleccionar la imagen.";
          notifyListeners();
          return false;
        }

        break;

      default:
    }

    

  }

  /*
   *@method guardarFormularioEgreso
   *@funcionalidad Se encarga de enviar los datos para ser guardados
   */
  Future<bool> guardarFormularioIngreso()async{
    obtenerConsecutivoIngreso();
    
    developer.log(base64string.length.toString());

    var puntoTanqueoFormateado = puntoTanquoSeleccionadoCompleto.split(' ');
    var nombreArchivo = '${DateFormat('yyyy-MM-dd').format(fecha)}-IN-${factura.toString().trim()}-${puntoTanqueoFormateado[1].toString().trim()}';
   
    bool resultado = await DB.insertarDatosIngresosEgresos(
      fecha, 
       DateFormat('yyyy-MM-dd').format(fecha).toString(),
      consecutivo.toString(),
      puntoTanquoSeleccionadoId.toString(),
      puntoTanquoSeleccionadoCompleto.toString(), 
      proveedorSeleccionadoId.toString(), 
      proveedorSeleccionadoCompleto.toString(), 
      volumen.toString(), 
      factura.toString(), 
      guia.toString(), 
      conductor.toString(), 
      placa.toString(), 
      observacion.toString(), 
      datoUser[0]["id"].toString(),
      datoUser[0]["nombreUsuario"].toString(),  
      datoUser[0]["id"].toString(),
      datoUser[0]["nombreUsuario"].toString(), 
      checkCompraRemanente == false ? "2005" : "2004",
      "INGRESO",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      base64string.toString(),
      nombreArchivo.toString(),
      extension.toString(),
      tipoCombustible.toString(),
      volumen.toString(),
      "0",
      "LOCAL"
      );

    var totalStock = double.parse(stock) + volumen;

    await DB.insertarDatosInformacionPuntoTanqueo(
      puntoTanquoSeleccionadoId,
      ubicacionPuntoTanqueo.toString(),
      tipoCombustible.toString(),
      "0",
      "0",
      totalStock
    );

    obtenerConsecutivoIngreso();
      
    notifyListeners();
    return resultado;
    
  }

  /*
   *@method obtenerConsecutivoIngreso
   *@funcionalidad Se encarga de obtener el consecutivo de los datos
   */
  void obtenerConsecutivoIngreso() async{
    int consecutivoFinal = 0;
    var resultadoConcecutivo = await DB.obtenerConsecutivoIngreso();
    if (resultadoConcecutivo.isNotEmpty) {
      String valorConsecutivo = resultadoConcecutivo[0]["consecutivo"] .toString();
      consecutivo = (int.parse(valorConsecutivo) + 1);
      notifyListeners();
    }else{
      consecutivo = consecutivoFinal + 1;
      notifyListeners();
    }
  }

  /*
   *@method reiniciarFormulario
   *@funcionalidad Se encarga de reiniciar los valores del formulario 
   */
  void reiniciarFormulario(){
    puntoTanquoSeleccionadoId = null;
    puntoTanqueoSeleccionadoTexto = null;
    puntoTanquoSeleccionadoCompleto = null;

    proveedorSeleccionadoId = null;
    proveedorSeleccionadoTexto = null;
    proveedorSeleccionadoCompleto = null;

    isleroSeleccionadoId = null;
    isleroSeleccionadoTexto = null;
    isleroSeleccionadoCompleto =null;

    ubicacionPuntoTanqueo = "--";
    stock = "0";
    tipoCombustible = "";
    volumen = 0.0;
    factura = "";
    guia = "";
    conductor = "";
    placa = "";
    observacion = "NINGUNO";
    imagen = null;
    base64string ="";
    mensajeAdjuntoDocumentos="";
    notifyListeners();
  }

}