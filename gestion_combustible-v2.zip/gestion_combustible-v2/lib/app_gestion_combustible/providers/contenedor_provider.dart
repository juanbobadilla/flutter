
import 'package:flutter/material.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/models/conexion_model.dart';

class ContenedorProvider extends ChangeNotifier{
  
  var datoUser = [];

  /*
   *@method obtenerConsecutivoIngreso
   *@funcionalidad Se encarga de obtener el consecutivo de los datos
   */
  void obtenerSession() async{
    var documento = await DB.obtenerDocumentoSesion();
    datoUser = await DB.obtenerSesionUsuario(documento[0]['documento']);
    notifyListeners();
  }

  /*
   *@method: tienePermisoComponente
   *@funcionalidad: se encarga de recorrer los permisos del subcomponente. 
   */
  bool tienePermisoComponente( List permisos ){
    var resultadoPermiso = false;
    if (datoUser.isNotEmpty) {
      var datosFormateados;
      datosFormateados = datoUser[0]["permisosComponente"];
      var datosFormat = datosFormateados.split(','); 
      for (var i = 0; i < datosFormat.length; i++) {

        var permisosFound = permisos.map((e) => { datosFormat[i].toString() == e.toString() });
        if(permisosFound.first.first){
          resultadoPermiso = true;
          break; 
        }
      }
    }
    return resultadoPermiso;
  }

  /*
   *@method: tienePermisoSubComponente
   *@funcionalidad: se encarga de recorrer los permisos del subcomponente. 
   */
  bool tienePermisoSubComponente( List permisos ){
    var resultadoPermiso = false;
    if (datoUser.isNotEmpty) {
      var datosFormateados;
      datosFormateados = datoUser[0]["permisosSubComponente"];
      var datosFormat = datosFormateados.split(','); 
      for (var i = 0; i < datosFormat.length; i++) {
        var permisosFound = permisos.map((e) => { datosFormat[i].toString() == e.toString() });
        if(permisosFound.first.first){
          resultadoPermiso = true;
          break; 
        }
      }
    }
    return resultadoPermiso;
  }

}