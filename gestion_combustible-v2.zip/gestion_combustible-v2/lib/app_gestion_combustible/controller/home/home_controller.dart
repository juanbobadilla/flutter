import 'package:flutter/material.dart';

class HomeController {

  /*
   * @method irPagina
   * @funcionalidad Se encarga de redirigir al usuario cuando presiona una tarjeta.
   */
  irPagina(BuildContext context, nombreRuta){
    return Navigator.pushNamed(context, nombreRuta);

  }

  /*
   * @method volverPagina
   * @funcionalidad Se encarga de devolver a la pagina anterior
   */
  volverPagina(BuildContext context){
    return Navigator.pop(context, true);
  }

}