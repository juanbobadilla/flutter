import 'package:flutter/material.dart';

class NavigationBarcontenedorInferiorIngresoEgresosTransferenciaController {

  /*
   *@method botonNavigationBarPresionado
   *@funcionalidad Se encarga de detectar el indice del boton presionado y redirigirlo
  */
  botonNavigationBarPresionado(value, BuildContext context){

    switch(value) {
      case 0:
        //Navigator.pop(context);
        //break;
        return Navigator.pushNamed(context, 'StockPuntoTanqueo');
        
      case 1:
        return Navigator.pushNamed(context, 'Home');
      
      case 2:
        return Navigator.pushNamed(context, 'listadoHitorial');
    }

  }


}