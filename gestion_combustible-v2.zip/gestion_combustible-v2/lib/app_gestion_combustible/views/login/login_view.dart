import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';


class Login extends StatefulWidget{
  @override
  State<Login> createState() {
    // TODO: implement createState
    return StateLogin();
  }
}


class StateLogin extends State<Login>{

  var passwordVisible = false;
  var valorNumeroIdentificacion = TextEditingController();
  var valorPassword = TextEditingController();

  /*
   * @method: mostrarContrasena
   * @funcionalidad: se encarga de mostrar u ocultar la contraseña 
   */
  mostrarContrasena(){
    return passwordVisible = !passwordVisible;
  }

  @override
  Widget build(BuildContext context) {

    //importo el provider
    final loginProvider = Provider.of<LoginProvider>(context);
    //importo el provider
    final sincronizarProvider = Provider.of<SincronizarProvider>(context);
    //llave del formulario
    final keyFormLogin = GlobalKey<FormState>();

    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) {
            return alertaSalir(context);
          },
        );
        return shouldPop!;
      },

      

      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          resizeToAvoidBottomInset: false,
          body: Container(
            decoration: const BoxDecoration(
              
              image: DecorationImage(
                image: AssetImage("lib/app_gestion_combustible/sources/home/fondo.png",), 
                fit: BoxFit.cover,
                )
            ),
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color.fromARGB(192, 4, 4, 4), 
                    Color.fromARGB(72, 255, 255, 255),
                    Color.fromARGB(132, 0, 0, 0), 
                    Color.fromARGB(255, 0, 0, 0)
                    ]
                )
              ),
              child: Form(
                key: keyFormLogin,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    
                      Center(//TITULO
                      child: Text(
                        "Iniciar Sesión",
                        style: GoogleFonts.quicksand(
                          color: const Color.fromRGBO(255, 255, 255, 1),
                          fontSize: 40,
                          fontWeight: FontWeight.w700,
                          )
                        ),
                      ),

                      SizedBox(height: 50),//ESPACIO

                      Padding(//LABEL SUPERIOR USUARIO
                        padding:const EdgeInsets.symmetric( horizontal:  40.0),
                        child: Text(
                          "Usuario",
                          style: GoogleFonts.quicksand(
                            color: const Color.fromRGBO(255, 255, 255, 1),
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            height: 2
                            )
                          ),
                      ),
                    
                      Center(//INPUT USUARIO
                      child: Padding(
                        padding: const EdgeInsets.symmetric( horizontal:  40.0),
                        child: TextFormField(
                          controller:valorNumeroIdentificacion,
                          validator: (value){
                            if(value!.isEmpty){
                              return 'Debe ingresar el documento.';
                            }
                            return null;
                          },
                          keyboardType: TextInputType.number,
                          style:  const  TextStyle(
                            color:  Color.fromARGB(255, 83, 82, 82), 
                            fontSize: 20, 
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.3,
                            fontFamily: 'quicksand'
                            ),
                          decoration:  InputDecoration(
                             hintText: 'Usuario',
                             hintStyle: const TextStyle(
                              color: Color.fromARGB(255, 160, 159, 153),
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                              letterSpacing: 1.3,
                              fontFamily: 'quicksand'
                             ),
                             //labelText: 'Usuario',
                             //floatingLabelBehavior: FloatingLabelBehavior.always,
                             border:  OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide.none
                             ),
                             filled: true,
                             fillColor: Colors.white,
                             errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: const BorderSide(
                                color: Color.fromARGB(255, 255, 0, 0),
                                width: 2
                              )
                             ) ,
                             errorStyle: const TextStyle( 
                              color: Color.fromARGB(255, 255, 0, 0),
                              letterSpacing: 2.2,
                              fontWeight: FontWeight.w400,
                              fontSize: 15
                              )
                            ),
                          ),
                        ),
                      ),

                      Padding(//LABEL SUPER CONTRASEÑA
                          padding:const EdgeInsets.symmetric( horizontal:  40.0),
                          child: Text(
                            "Contraseña",
                            style: GoogleFonts.quicksand(
                              color: const Color.fromRGBO(255, 255, 255, 1),
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              height: 2
                              )
                            ),
                      ),

                      Center(//INPUT CONTRASEÑA
                        child: Padding(
                          padding: const EdgeInsets.symmetric( horizontal:  40.0),
                          child: TextFormField(
                            controller: valorPassword ,
                            validator: (value){
                              if(value!.isEmpty){
                                return 'Debe ingresar la contraseña.';
                              }
                              return null;
                            },
                            obscureText: passwordVisible == false ? true : false,
                            keyboardType: TextInputType.number,
                            style:  const  TextStyle(
                              color:  Color.fromARGB(255, 83, 82, 82), 
                              fontSize: 20, 
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.3,
                              fontFamily: 'quicksand'
                              ),
                            decoration:  InputDecoration(
                              suffixIcon: GestureDetector(
                                child: Icon( passwordVisible == true ? Icons.visibility : Icons.visibility_off) ,
                                onTap: (){
                                  setState(() {
                                    mostrarContrasena();
                                  });
                                },
                              )
                              ,
                              hintText: 'Contraseña',
                              hintStyle: const TextStyle(
                                color: Color.fromARGB(255, 160, 159, 153),
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                letterSpacing: 1.3,
                                fontFamily: 'quicksand'
                              ),
                              border:  OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide.none
                              ),
                              filled: true,
                              fillColor: Colors.white,
                              errorStyle: const TextStyle( 
                                color: Color.fromARGB(255, 255, 0, 0),
                                letterSpacing: 2.2,
                                fontWeight: FontWeight.w400,
                                fontSize: 15
                              ),
                               errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: const BorderSide(
                                color: Color.fromARGB(255, 255, 0, 0),
                                width: 2
                              )
                             ) 
                              ),
                            ),



                        ),
                      ),

                      SizedBox(height: 90),//ESPACIO

                      Padding(//BOTON DE LOGIN
                        padding:  const EdgeInsets.symmetric( horizontal:  90.0),
                        child:  TextButton(
                          onPressed: ()async{

                            if(keyFormLogin.currentState!.validate()){
                            EasyLoading.show(status: 'Cargando...');
                            var respuesta = await loginProvider.ingresarUsuario( valorNumeroIdentificacion.text , valorPassword.text, context);
                            if(respuesta == 1){ //ingresó con conexion a internet
                              var respuestaSincronizar = await sincronizarProvider.importarLosDatos();

                              if(respuestaSincronizar == 1){//error al importar
                                alerta(context, "Error al importar (1)", false);
                                EasyLoading.dismiss();
                              }else if(respuesta == 2){//error al borrar las tablas
                                alerta(context, "Se produjo un error al momento de borrar las tablas por favor llamar al administrador (2).", false);
                                EasyLoading.dismiss();
                              }else if(respuestaSincronizar == 3){//error al subir los datos
                                alerta(context, "Error al subir los datos (3).", false);
                                EasyLoading.dismiss();
                              }else if(respuestaSincronizar == 4){// error al borrar o al importar los datos
                                alerta(context, "Error al borrar o al importar los datos (4).", false);
                                EasyLoading.dismiss();
                              }else if(respuestaSincronizar == 5){//error al subir datos
                                alerta(context, "Error al subir datos (5).", false);
                                EasyLoading.dismiss();
                              }else if(respuestaSincronizar == 6){//error, no existe ningun documento
                                alerta(context, "Error, no existe ningun documento del usuario (6).", false);
                                EasyLoading.dismiss();
                              }else if(respuestaSincronizar == 7){//no existe conexion con datasseqv2
                                alerta(context, "Error, no existe conexion con datasseqv2 (7).", false);
                                EasyLoading.dismiss();
                              }else if(respuestaSincronizar == 8){//definitivament no existe conexion con datasseqv2
                                alerta(context, "Error, definitivament no existe conexion con datasseqv2 (8).", false);
                                EasyLoading.dismiss();
                              }else{//todo funcionando
                                alerta(context, "Sincronizado completo", true);
                                keyFormLogin.currentState?.reset();
                                EasyLoading.dismiss();
                                Navigator.pushReplacementNamed(context, 'Home');                
                              }
                              /* var respuestaSincronizar = await sincronizarProvider.importarDatos(); //sincronizo los datos
                              if(respuestaSincronizar == 200 ){
                                alerta(context, "Sincronizado completo", true);
                                
                                keyFormLogin.currentState?.reset();
                                EasyLoading.dismiss();
                                Navigator.pushReplacementNamed(context, 'Home');
                              }else{
                                alerta(context, "Recuerde que para sincronizar necesita estar conectado a una red.", false);
                                EasyLoading.dismiss();
                              } */
                            }else if(respuesta == 2){ // ingrese sin internet pero con los datos guardados en memoria
                              keyFormLogin.currentState?.reset();
                              EasyLoading.dismiss();
                              Navigator.pushReplacementNamed(context, 'Home');
                            }else if(respuesta == 3){ // no tengo internet
                              keyFormLogin.currentState?.reset();
                              EasyLoading.dismiss();
                              EasyLoading.showError(
                                'Error de autentificación.', 
                                duration: 
                                  const Duration(
                                    days: 0, 
                                    hours: 0, 
                                    minutes: 0, 
                                    seconds: 0,
                                    milliseconds: 3500, 
                                    microseconds: 0) 
                                  );
                              return;
                            }else{
                              keyFormLogin.currentState?.reset();
                              EasyLoading.dismiss();
                              EasyLoading.showError(
                                'Recuerda estar conectado a internet.', 
                                duration: 
                                  const Duration(
                                    days: 0, 
                                    hours: 0, 
                                    minutes: 0, 
                                    seconds: 0,
                                    milliseconds: 3500, 
                                    microseconds: 0) 
                                  );
                              return;
                            }
                          }


                          }, 
                          child: Text(
                            "Login", 
                            style: GoogleFonts.quicksand(
                              color:  Color.fromRGBO(255, 255, 255, 1),
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              fontStyle: FontStyle.normal
                            ),
                            ),
                          style: const ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll( Color.fromARGB(255, 242, 103, 34) ),
                            padding: MaterialStatePropertyAll(EdgeInsets.only(top: 15,bottom: 15) )
                          ),
                          ),
                        ),

                      SizedBox(height: 60),//ESPACIO

                      Padding(//LINEA HORIZONTAL , TEXTO , LINEA HORIZONTAL
                        padding: const EdgeInsets.symmetric( horizontal:  0.0),
                        child: Row(
                          children: <Widget> [
                           const Expanded(
                              child: Image(
                                image: AssetImage("lib/app_gestion_combustible/sources/home/RectangleIzquierda.png"),
                                fit: BoxFit.cover,
                                )
                              ),
                            const SizedBox(width: 13,), 
                            Text(
                              "Redes Sociales",
                                style: GoogleFonts.quicksand(
                                  color: const Color.fromRGBO(255, 255, 255, 1),
                                  fontSize: 19,
                                  fontWeight: FontWeight.w500,
                                  )
                                ),
                            const SizedBox(width: 13,), 
                            const Expanded(
                              child: Image(
                                image: AssetImage("lib/app_gestion_combustible/sources/home/RectangRight.png"),
                                fit: BoxFit.cover,
                                )
                              ),
                            const SizedBox(height: 2,)
                            ]
                          ), 
                        ),

                      SizedBox(height: 20),//ESPACIO

                      Padding(//BOTONERIA DE REDES SOCIALES
                        padding:const EdgeInsets.symmetric( horizontal:  40.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children:<Widget> [

                            TextButton(//BOTON DE TIKTOK
                              onPressed: (){}, 
                              style: ButtonStyle(
                                 backgroundColor:const MaterialStatePropertyAll( Color.fromARGB(255, 72, 72, 72) ),
                                 shape: MaterialStateProperty.all(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(100)
                                    )
                                  ),
                                   padding: MaterialStatePropertyAll(EdgeInsets.only(top: 15,bottom: 15, left: 40, right: 40) )
                              ),
                              child: const Image(
                                image: AssetImage("lib/app_gestion_combustible/sources/home/tik-tok.png"),
                                width: 25,
                                fit: BoxFit.cover,
                                )
                              ),
                            
                            SizedBox(width: 10),//ESPACIO

                            TextButton(//BOTON DE INSTAGRAM
                              onPressed: (){}, 
                              style: ButtonStyle(
                                 backgroundColor:const MaterialStatePropertyAll( Color.fromARGB(255, 72, 72, 72) ),
                                 shape: MaterialStateProperty.all(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(100)
                                    )
                                  ),
                                   padding: MaterialStatePropertyAll(EdgeInsets.only(top: 15,bottom: 15, left: 40, right: 40) )
                              ),
                              child: const Image(
                                image: AssetImage("lib/app_gestion_combustible/sources/home/instagram.png"),
                                width: 25,
                                fit: BoxFit.cover,
                                )
                              ),
                            
                            SizedBox(width: 10),//ESPACIO

                            TextButton(//BOTON DE FACEBOOK
                              onPressed: (){}, 
                              style: ButtonStyle(
                                 backgroundColor:const MaterialStatePropertyAll( Color.fromARGB(255, 72, 72, 72) ),
                                 shape: MaterialStateProperty.all(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(100)
                                    )
                                  ),
                                   padding: MaterialStatePropertyAll(EdgeInsets.only(top: 15,bottom: 15, left: 40, right: 40) )
                              ),
                              child: const Image(
                                image: AssetImage("lib/app_gestion_combustible/sources/home/facebook.png"),
                                width: 25,
                                fit: BoxFit.cover,
                                )
                              )
                          ],
                        ),
                        
                        )

                    ],
                  ),
                ),
            ),
           ),
        ),
        builder: EasyLoading.init(),
        
      ),
    );
  }

  //widget de alertas
  Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }


  Widget alertaSalir (BuildContext context){
    return AlertDialog(
              //title: const Text('¿ Desea cerrar la aplicación ?', textAlign: TextAlign.center,),
              actionsAlignment: MainAxisAlignment.center,
              content: Container(
                height: 100,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset('lib/app_gestion_combustible/sources/salir_app/question.png', height: 60),
                      const SizedBox(height: 20),
                      const Text(
                        '¿ Desea salir de la aplicación ?', 
                        textAlign: TextAlign.center, 
                        style: TextStyle( color: Colors.black54 )
                      ),
                    ],
                  ),
              ),
              actions: [
                TextButton(
                  style: const ButtonStyle( 
                    backgroundColor: MaterialStatePropertyAll<Color>(Color.fromARGB(255, 243, 121, 21)),
                  ),
                  onPressed: () {
                    Navigator.pop(context, true);
                  },
                  child: const Text('SI', style: TextStyle( color: Colors.white )),
                ),
              ],
            );
  }
 
  


}