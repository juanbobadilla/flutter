import 'package:com_gestioncombustible_app/app_gestion_combustible/controller/menu_inferior_stock_puntos_tanqueo/menu_inferior_controller.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/stock_puntos_tanqueo_provider.dart';
import 'package:flutter/material.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class StockPuntoTanqueo extends StatefulWidget{
  @override
  State<StockPuntoTanqueo>createState(){
    return StateStockPuntoTanqueo();
  }
}

class StateStockPuntoTanqueo extends State<StockPuntoTanqueo>{
  
  //instacio el controlador para el navigationBar
  var navigationBarController = new NavigationBarController();

  @override
  void initState() {
      final stockProvider   = Provider.of<StockPuntosTanqueoProvider>(context, listen: false);
      //stockProvider.mostrarStockPuntosTanqueo();
      stockProvider.obtenerFechaSincronizada();
      stockProvider.galonesSaliente();
      super.initState();
  }

  @override
  Widget build(BuildContext context) {

    late List<dynamic> listado =[];
    listado = context.watch<StockPuntosTanqueoProvider>().listaStockPuntosTanqueos;
    var fechaUltimaSincronizacion = context.watch<StockPuntosTanqueoProvider>().fechaUltimaSincronizacion;


    return MaterialApp(
      title: 'GestionCombustible',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('GestionCombustible'),
          iconTheme: const IconThemeData(color: Colors.white),
          flexibleSpace: const Image(
              image: AssetImage('lib/app_gestion_combustible/sources/home/background_appBar_combustible.png'),
              alignment: Alignment.centerRight,
              width: double.infinity,
              fit: BoxFit.cover,
          ),
          bottom: PreferredSize(
                preferredSize: const Size.fromHeight(90.0),
                child: Transform.translate(
                  offset: const Offset(0, 2),
                  child: containerSuperior(fechaUltimaSincronizacion),
                ),
            ),
        ),
        body: context.watch<StockPuntosTanqueoProvider>().loading == true ? 
          const Center(
            child: CircularProgressIndicator(
              color: Colors.amber,
              strokeWidth: 3,
            ),
          ) :     
         ListView(
           children: listado.map((item) => tarjeta(item)).toList()
        ),
        drawer: menuLateral(context),
        bottomNavigationBar: bottomNavigationBarInferior(context),
      ),
    );
  }

  

  //container
  Widget containerSuperior(fechaUltimaSincronizacion){


    return Stack(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0.0),
          child: Container(
            width: double.infinity,
            height: 50.0,
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 30, 42, 120),
              borderRadius: BorderRadius.circular(0),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children:  <Widget>[
                const Text('STOCK PUNTOS DE TANQUEO', style: TextStyle( color: Colors.white , fontWeight: FontWeight.bold, fontSize: 15.0)),
                Text('Ultima sincronización : ${fechaUltimaSincronizacion.toString()}', style: TextStyle( color: Colors.white ))
              ],
            ),
          ),
        ),
      ],
    );
  }
  //tarjeta
  Widget tarjeta(item){
    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.only( top: 20.0, left: 60.0, right: 40.0 ),
          child: Container( //contenedor primario
            width: double.infinity,
            height: 130.0,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.orange,
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.56),
                  spreadRadius: 0,
                  blurRadius: 7,
                  offset: Offset(0, 5)
                ),
              ]
            ),
            child: Column( // texto dentro del container
                  mainAxisAlignment: MainAxisAlignment.center,
                  children:  <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(70, 0, 0, 0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          item["nombre"].toString(),
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 21.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ) ,
                    ),
                    SizedBox( height: 8.0, ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Stock: ${item["stockDisponible"].toString()}',
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontWeight: FontWeight.w400,
                          ),
                        ) ,
                      ),
                    ),
                    const SizedBox( height: 5.0, ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(70, 0, 1, 0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Ultima calibración: ${item["fechaUltimaCalibracion"].toString() }',
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontWeight: FontWeight.w400,
                          ),
                        ) ,
                      ),
                    ),
                    SizedBox( height: 5.0, ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Gls salientes: ${item["galonesSalientes"].toString()}',
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontWeight: FontWeight.w400,
                          ),
                        ) ,
                      ),
                    ),
                  ],
                ),
          ),
        ),
        Positioned(
          top: 37.0,
          left: 26.0,
          child: Image.asset(
            'lib/app_gestion_combustible/sources/home/combustible.png',
            height: 100.0,
          ),
        ),
      ],
    );
  }
  //navbar inferior
  Widget bottomNavigationBarInferior(BuildContext context){
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: Color.fromARGB(255, 250, 250, 250),
      showSelectedLabels: false,
      showUnselectedLabels: false,
      onTap: (value) {
        navigationBarController.botonNavigationBarPresionado(value, context);
      },
      items: const <BottomNavigationBarItem>[
         BottomNavigationBarItem(
          icon: Icon(
            Icons.add_circle, 
            color: Color.fromARGB(255, 243, 121, 21),
            size: 40.0,
          ),
          label: 'Agregar',
          
        ),
         BottomNavigationBarItem(
          icon: Icon(
            Icons.home,
            color: Color.fromARGB(255, 243, 121, 21),
            size: 40.0,
          ),
          label: 'Inicio',
        ),
        BottomNavigationBarItem(
          icon: Icon(
            Icons.list,
            color: Color.fromARGB(255, 243, 121, 21),
            size: 40.0,
          ),
          label: 'Historial',
        )
      ],
    );
  }
  //menu lateral
  Widget menuLateral(BuildContext context){
    
    //importo el provider
        //importo el provider
    final loginProvider = Provider.of<LoginProvider>(context);
    final sincronizarProvider = Provider.of<SincronizarProvider>(context);
    var usuario = context.watch<LoginProvider>().nombreUsuario;
    var documento = context.watch<LoginProvider>().documento;
    var cargo = context.watch<LoginProvider>().cargo;

    return Drawer(
        child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
            //icono y datos del usuario
            Container(
              height: 280.0,
              decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.centerRight,
                    colors: <Color>[Color.fromARGB(255, 255, 128, 0), Colors.yellow]
                  ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Icon(Icons.account_circle, size: 130.0, color: Colors.white),
                  Text(usuario.toString(), textAlign: TextAlign.center ,style: TextStyle(color: Colors.white, fontSize: 16.0, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(documento.toString(), style: TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.bold),),
                  const SizedBox(height: 5),
                  Text(cargo.toString(), style: TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.bold))
                ],
              ),
            ),
            //cuerpo del Drawer
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: (){
                  //Navigator.pop(context);
                  //Navigator.pushReplacementNamed(context, 'Login');
                  Navigator.of(context).pushNamedAndRemoveUntil('Login', (Route<dynamic> route) => false);
                }, 
                icon: const Icon(Icons.logout, color: Colors.black,), 
                label: const Text('Salir', style: TextStyle( color: Colors.black, fontSize: 20.0 ),)
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () async{
                  var respuesta = await sincronizarProvider.importarLosDatos();

                  if(respuesta == 1){//error al importar
                    alerta(context, "Error al importar", false);
                  }else if(respuesta == 2){//error al borrar las tablas
                    alerta(context, "Se produjo un error al momento de borrar las tablas por favor llamar al administrador.", false);
                  }else if(respuesta == 3){//error al subir los datos
                    alerta(context, "Error al subir los datos.", false);
                  }else if(respuesta == 4){// error al borrar o al importar los datos
                    alerta(context, "Error al borrar o al importar los datos.", false);
                  }else if(respuesta == 5){//error al subir datos
                    alerta(context, "Error al subir datos.", false);
                  }else if(respuesta == 6){//error, no existe ningun documento
                    alerta(context, "Error, no existe ningun documento del usuario.", false);
                  }else if(respuesta == 7){//no existe conexion con datasseqv2
                    alerta(context, "Error, no existe conexion con datasseqv2.", false);
                  }else if(respuesta == 8){//definitivament no existe conexion con datasseqv2
                    alerta(context, "Error, definitivament no existe conexion con datasseqv2.", false);
                  }else{//todo funcionando
                    alerta(context, "Sincronizado completo", true);                
                  }
                  /* var respuesta = await sincronizarProvider.importarDatos();
                  respuesta == 200 ?
                  alerta(context, "Sincronizado completo", true) : 
                  alerta(context, "Recuerde que para sincronizar necesita estar conectado a una red.", false); */
                }, 
                icon: sincronizarProvider.loadingPeticion == true ? 
                 Container(
                  padding: const EdgeInsets.all(1),
                  width: 20,
                  height: 20,
                  child: const CircularProgressIndicator(
                    color: Colors.amber,
                    strokeWidth: 3,
                  )
                ) : const Icon(Icons.sync , color: Colors.black),
                label: const Text('Sincronizar', style: TextStyle( color: Colors.black, fontSize: 20.0 ),)
              ),
            ),
             Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: (){
                  sincronizarProvider.descargarDatosLocales();
                }, 
                icon: const Icon(Icons.download , color: Colors.black), 
                label: const Text('Copia de seguridad', style: TextStyle( color: Colors.black, fontSize: 20.0 ),)
              ),
            ),
          ],
        ),
      );
  }


  //widget de alertas
  Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }


}