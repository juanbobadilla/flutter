import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/transferencia_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:dropdown_search/dropdown_search.dart';


class TranferenciaFormulario extends StatefulWidget{
  const TranferenciaFormulario({super.key});


  @override
  State<TranferenciaFormulario>createState(){
    return StateTranferenciaFormulario();
  }

}

class StateTranferenciaFormulario extends State<TranferenciaFormulario>{

  final keyFormularioTransferencia = GlobalKey<FormState>();

  @override
  void initState() {

    final transferenciaProvider  = Provider.of<TransferenciaProvider>(context, listen: false);

    transferenciaProvider.obtenerSession();
    transferenciaProvider.obtenerConsecutivoIngreso();
    transferenciaProvider.obtenerPuntosTanqueoEgreso();
      
    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {

    final transferenciaProvider = Provider.of<TransferenciaProvider>(context);

    late List<dynamic> listaPuntoTanquoEgreso =[];
    listaPuntoTanquoEgreso = transferenciaProvider.listaPuntoTanquoEgreso;
    
    late List<dynamic> listaPuntoTanquoIngreso =[];
    listaPuntoTanquoIngreso = transferenciaProvider.listaPuntoTanquoIngreso;

    late List<dynamic> listaProyectos = [];
    listaProyectos = context.watch<TransferenciaProvider>().listaProyectos;

    transferenciaProvider.desacoplaFecha();

    return ListView(
      children: [
        Form( 
        key:keyFormularioTransferencia,
        child: Column(
          children: [
          const SizedBox(height: 30.0),
          //primera fila
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[

              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: const Color.fromARGB(255, 30, 42, 120),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(1),
                        spreadRadius: 1,
                        blurRadius: 2,
                        offset: const Offset(3, 2)
                      )
                    ]
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Text( transferenciaProvider.fechaDia.toString(), 
                        style: const TextStyle( 
                          color: Colors.white, 
                          fontSize: 40.0, 
                          fontWeight: FontWeight.w600,
                          
                        )
                      ),
                      Text(
                          transferenciaProvider.fechaMes.toString() == '1' ? 'Ene' : 
                          transferenciaProvider.fechaMes.toString() == '2' ? 'Feb' :
                          transferenciaProvider.fechaMes.toString() == '3' ? 'Mar' :
                          transferenciaProvider.fechaMes.toString() == '4' ? 'Abr' :
                          transferenciaProvider.fechaMes.toString() == '5' ? 'May' : 
                          transferenciaProvider.fechaMes.toString() == '6' ? 'Jun' :
                          transferenciaProvider.fechaMes.toString() == '7' ? 'Jul' : 
                          transferenciaProvider.fechaMes.toString() == '8' ? 'Ago' :
                          transferenciaProvider.fechaMes.toString() == '9' ? 'Sep' :
                          transferenciaProvider.fechaMes.toString() ==  '10' ? 'Oct' :
                          transferenciaProvider.fechaMes.toString() ==  '11' ? 'Nov' :
                          transferenciaProvider.fechaMes.toString() ==  '12' ? 'Dic' : '', 
                        style: const TextStyle( 
                          color: Colors.white, 
                          fontSize: 15.0, 
                          fontWeight: FontWeight.w400 
                        )
                      )
                    ],
                  ),
                )
              ),
              Flexible(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    const Text('Consecutivo transfrencia: ', style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18, fontWeight: FontWeight.bold )),
                    const SizedBox(height: 10),
                    Text('MSQ-${transferenciaProvider.consecutivo.toString()}',style: TextStyle( color: Color.fromARGB(255, 103, 102, 102), fontSize: 18, fontWeight: FontWeight.bold ))
                  ],
                )
              ),
              
            ],
          ),
          //segunda fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              children: [
                Flexible(
                  child: DropdownSearch(
                                validator: (value) {
                                  if(listaPuntoTanquoEgreso.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaPuntoTanquoEgreso,
                                showClearButton: true,
                                clearButtonProps: transferenciaProvider.spinnerPuntoTanqueo == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Punto de tanqueo egreso',
                                ),
                                selectedItem: transferenciaProvider.puntoTanquoEgresoSeleccionadoCompleto,
                                onChanged: (e) {
                                  transferenciaProvider.setPuntoTanquoEgresoSeleccionado(e);
                                },
                              ),
                ),
              ],
            ),
          ),
          
           Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: DropdownSearch(
                                validator: (value) {
                                  if(listaProyectos.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaProyectos,
                                showClearButton: true,
                                clearButtonProps: transferenciaProvider.spinnerProyecto == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Proyectos',
                                ),
                                selectedItem: transferenciaProvider.proyectoSeleccionadoCompleto,
                                onChanged: (e) {
                                  transferenciaProvider.setProyectoSeleccionado(e);
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
          
          //tercera fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            child: Container(
                height: 60.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color.fromARGB(255, 30, 42, 120),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(1),
                      spreadRadius: 1,
                      blurRadius: 2,
                      offset: Offset(3, 3)
                    )
                  ]
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text('Stock disponible (gls): ${transferenciaProvider.stockPuntoTanqueEgreso.toString()}', style: TextStyle( color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold )),
                  ],
                ),
            ),
          ),
          //cuarta fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              children: [
                Flexible(
                  child: DropdownSearch(
                                validator: (value) {
                                  if(listaPuntoTanquoIngreso.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaPuntoTanquoIngreso,
                                showClearButton: true,
                                clearButtonProps: transferenciaProvider.spinnerPuntoTanqueo == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Punto de tanqueo ingreso',
                                ),
                                selectedItem: transferenciaProvider.puntoTanquoIngresoSeleccionadoCompleto,
                                onChanged: (e) {
                                  transferenciaProvider.setPuntoTanquoIngresoSeleccionado(e);
                                },
                              ),
                ),
              ],
            ),
          ),
          //mensaje de alerta para los tipos de combustible
          transferenciaProvider.mostrarMensajeAlertaTipoCombustible == true ?
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
            child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: const  <Widget>[
                    FaIcon( FontAwesomeIcons.triangleExclamation , color: Colors.amber, size: 15),
                    SizedBox(width: 10),
                    Expanded(
                      child:Text('No se puede ingresar ese tipo de combustible.', 
                      style: TextStyle( color: Color.fromARGB(255, 211, 24, 24), fontSize: 15, fontWeight: FontWeight.bold )
                      ),)
                  ],
                ),
          ) : const SizedBox(height: 0, width: 0),
          //quinta fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            child: Container(
                height: 60.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color.fromARGB(255, 30, 42, 120),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(1),
                      spreadRadius: 1,
                      blurRadius: 2,
                      offset: const Offset(3, 3)
                    )
                  ]
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text('Stock disponible (gls): ${transferenciaProvider.stockPuntoTanqueIngreso.toString()}', style: TextStyle( color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold )),
                  ],
                ),
            ),
          ),
          //sexta fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              children: [
                Flexible(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Align(
                        alignment: Alignment.centerLeft,
                        child:  Text('Volumen (Gls):' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                      ),
                      const SizedBox(height: 10.0),
                      TextFormField(
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Campo requerido";
                          }
                          return null;
                        },
                        onChanged: (value) {
                          transferenciaProvider.setVolumen(value);
                        },
                        maxLength: 6,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9.]')),],
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(17.0)),
                          ),
                        ),
                        textAlign: TextAlign.center,
                        style: const TextStyle( fontSize: 100, fontWeight: FontWeight.bold ),
                        )
                    ],
                  ) 
                )
              ],
            ),
          ),
          //septima fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            child: Container(
                height: 60.0,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color.fromARGB(255, 30, 42, 120),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(1),
                      spreadRadius: 1,
                      blurRadius: 2,
                      offset: Offset(3, 3)
                    )
                  ]
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text('Tipo de combustible: ${transferenciaProvider.tipoCombustibleEgreso.toString()} ', style: TextStyle( color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold )),
                  ],
                ),
            ),
          ),
          //Ooctava fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              children: [
                Flexible(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Align(
                        alignment: Alignment.centerLeft,
                        child:  Text('Conductor:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                      ),
                      const SizedBox(height: 10.0),
                      TextFormField(
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Campo requerido";
                          }
                          return null;
                        },
                        onChanged: (value) {
                          transferenciaProvider.setConductor(value);
                        },
                        maxLength: 60,
                        keyboardType: TextInputType.text,
                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[a-zA-Zñ ]')),],
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(17.0)),
                            ),
                            labelText: 'Ecriba el responsable del punto de tanqueo',
                          ),
                        )
                    ],
                  ) 
                )
              ],
            ),
          ),
          //novena fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              children: [
                Flexible(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Align(
                        alignment: Alignment.centerLeft,
                        child:  Text('N° Contador tanque egreso post tanquo:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                      ),
                      const SizedBox(height: 10.0),
                      TextFormField(
                        onChanged: (value) {
                          transferenciaProvider.setContador(value);
                        },
                        maxLength: 10,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9.]')),],
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(17.0)),
                            ),
                            labelText: 'Ecriba el contador del vehiculo que tiene el punto de tanqueo',
                          ),
                        )
                    ],
                  ) 
                )
              ],
            ),
          ),
          // decima fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              children: [
                Flexible(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Align(
                        alignment: Alignment.centerLeft,
                        child:  Text('Placa de vehículo punto de tanqueo:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                      ),
                      const SizedBox(height: 10.0),
                      TextFormField(
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Campo requerido";
                          }
                          return null;
                        },
                        onChanged: (value) {
                          transferenciaProvider.setPlaca(value);
                        },
                        maxLength: 6,
                          keyboardType: TextInputType.text,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[a-zA-Z0-9ñ]')),],
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(17.0)),
                            ),
                            labelText: 'Ecriba la placa del vehiculo que tiene el punto de tanqueo',
                          ),
                        )
                    ],
                  ) 
                )
              ],
            ),
          ),
          //adjuntar archivo
          Padding(
          padding:
            const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Row(
                  children: [
                    const Text('Adjuntar archivo',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            color: Color.fromARGB(255, 243, 121, 21),
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold)),
                    const SizedBox(width: 1.0),
                    TextButton(
                      onPressed: () {
                        Scaffold.of(context).showBottomSheet<void>(
                          (BuildContext context) {
                            return Container(
                                height: 150,
                                decoration: const BoxDecoration(
                                  color: Color.fromARGB(255, 255, 255, 255),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color.fromARGB(255, 99, 99, 99),
                                      offset: Offset(5.0, 5.0),
                                      blurRadius: 10.0,
                                      spreadRadius: 2.0,
                                    ),
                                  ],
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(10),
                                    topRight: Radius.circular(10),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        TextButton(
                                            onPressed: () async {
                                              var resultado =
                                                  await transferenciaProvider
                                                      .seleccionarImagen(
                                                          0, context);
                                              if (resultado) {
                                                alerta(
                                                    context,
                                                    transferenciaProvider
                                                        .mensajeAdjuntoDocumentos
                                                        .toString(),
                                                    true);
                                              } else {
                                                alerta(
                                                    context,
                                                    transferenciaProvider
                                                        .mensajeAdjuntoDocumentos
                                                        .toString(),
                                                    false);
                                              }
                                            },
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Image.asset(
                                                    'lib/app_gestion_combustible/sources/adjuntar/camara.png',
                                                    width: 35),
                                                const Text(
                                                  "Cámara",
                                                  style: TextStyle(
                                                      color: Colors.black),
                                                )
                                              ],
                                            )),
                                        TextButton(
                                            onPressed: () async {
                                              var resultado =
                                                  await transferenciaProvider
                                                      .seleccionarImagen(
                                                          1, context);

                                              if (resultado) {
                                                alerta(
                                                    context,
                                                    transferenciaProvider
                                                        .mensajeAdjuntoDocumentos
                                                        .toString(),
                                                    true);
                                              } else {
                                                alerta(
                                                    context,
                                                    transferenciaProvider
                                                        .mensajeAdjuntoDocumentos
                                                        .toString(),
                                                    false);
                                              }
                                            },
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Image.asset(
                                                    'lib/app_gestion_combustible/sources/adjuntar/documento.png',
                                                    width: 35),
                                                const Text("Documento",
                                                    style: TextStyle(
                                                        color: Colors.black))
                                              ],
                                            ))
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    ElevatedButton(
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                      child: Text(
                                        "Cancelar",
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 106, 106, 106),
                                            fontSize: 18),
                                      ),
                                      style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStateProperty.all(
                                          Color.fromARGB(255, 255, 255, 255),
                                        ),
                                        padding: MaterialStateProperty.all(
                                          const EdgeInsets.only(
                                              left: 100, right: 100),
                                        ),
                                        shape: MaterialStateProperty.all(
                                          RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ));
                          },
                        );
                      },
                      child: Icon(Icons.attach_file),
                    ),
                    transferenciaProvider.imagen == null || transferenciaProvider.imagen == ""
                        ? SizedBox()
                        : Image.memory(transferenciaProvider.imagen, width: 100),
                  ],
                )),


          //onceava fila
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              children: [
                Flexible(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Align(
                            alignment: Alignment.centerLeft,
                            child:  Text('Observaciones:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                          ),
                          const SizedBox(height: 10.0),
                          TextFormField(
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Campo requerido";
                              }
                              return null;
                            },
                            onChanged: (value) {
                              transferenciaProvider.setObservaciones(value);
                            },
                            maxLines: null,
                            keyboardType: TextInputType.multiline,
                            decoration: const InputDecoration( 
                              contentPadding: EdgeInsets.all(30),                     
                              border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(17.0)),
                             ),
                             labelText: 'Escriba las observaciones',
                            ),
                          )
                        ],
                      ) 
                    ),
              ],
            )
          ),
          //doceava fila
          transferenciaProvider.mostrarMensajeAlertaTipoCombustible == false ?
          Padding(
            padding: const EdgeInsets.only(bottom: 5, top: 20, left: 110, right: 110),
            child: TextButton(
              onPressed: ( ) async {
                
                if (keyFormularioTransferencia.currentState!.validate()) {
                  
                  bool resultado = await transferenciaProvider.guardarFormularioTransferencia();
                    
                  if (resultado) {
                     alerta(context, 'Información guardada correctamente.', resultado);
                     transferenciaProvider.reiniciarFormulario();
                     keyFormularioTransferencia.currentState!.reset();
                  } else {
                     alerta(context, 'No hay suficiente combustible, \n stock disponible: ${transferenciaProvider.stockPuntoTanqueEgreso} ', resultado);
                  }
                }else{
                  return;
                }



              }, 
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(Color.fromARGB(255, 243, 121, 21)),
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                child: Text(
                  'Guardar',
                  style: TextStyle( color: Colors.white , fontSize: 20.0, fontWeight: FontWeight.bold),
                ),
              )
            ),
          ) : const SizedBox( height: 10,),
          //boton de cancelar
          Padding(
            padding: const EdgeInsets.only(bottom: 10, top: 5, left: 110, right: 110),
              child: TextButton(
                onPressed: () {
                  keyFormularioTransferencia.currentState!.reset();
                  transferenciaProvider.reiniciarFormulario();
                  keyFormularioTransferencia.currentState!.reset();
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.0),
                  child: Text(
                    'Cancelar',
                    style: TextStyle( color: Colors.black , fontSize: 15.0),
                  ),
                )
              ),
            ),
            
          ]
        )),
      ]
    );
  }


  //widget de alertas
    Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

}