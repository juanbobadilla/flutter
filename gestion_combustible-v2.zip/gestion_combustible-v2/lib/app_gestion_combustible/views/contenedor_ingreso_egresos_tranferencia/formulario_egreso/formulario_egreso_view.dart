import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/egreso_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';


class EgresoFormulario extends StatefulWidget{
  const EgresoFormulario({super.key});

  @override
  State<EgresoFormulario>createState(){
    return StateEngresoFormulario();
  }
}

class StateEngresoFormulario extends State<EgresoFormulario>{

    final keyFormularioEgreso = GlobalKey<FormState>();

    @override
    void initState() {
      final egresoProvider  = Provider.of<EgresoProvider>(context, listen: false);
      
      egresoProvider.obtenerSession();
      egresoProvider.obtenerPuntosTanqueo();
      egresoProvider.obtenerActivos();
      egresoProvider.obtenerConductores();
      
      super.initState();
    }
  

    @override
    Widget build(BuildContext context) {
      
      final egresoProvider  = Provider.of<EgresoProvider>(context);

      late List<dynamic> listaProyectos = [];
      listaProyectos = context.watch<EgresoProvider>().listaProyectos;

      late List<dynamic> listaFrentes = [];
      listaFrentes = context.watch<EgresoProvider>().listaFrentes;

      late List<dynamic> listaPuntoTanquo =[];
      listaPuntoTanquo = context.watch<EgresoProvider>().listaPuntoTanquo;

      late List<dynamic> listaActivos =[];
      listaActivos = context.watch<EgresoProvider>().listaActivos;

      late List listaConductores =[];
      listaConductores = context.watch<EgresoProvider>().listaConductores;

      egresoProvider.desacoplaFecha();

      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
            resizeToAvoidBottomInset: false,
            body:SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                children: [
                Form(
                  key:keyFormularioEgreso,
                  autovalidateMode: AutovalidateMode.disabled,
                  child: Column(
                    children: [
                      const SizedBox(height: 30.0),
                      //fecha y punto de tanqueo
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          //fecha
                          Flexible(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: const Color.fromARGB(255, 30, 42, 120),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(1),
                                    spreadRadius: 1,
                                    blurRadius: 2,
                                    offset: const Offset(3, 2)
                                  )
                                ]
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: <Widget>[
                                  Text( egresoProvider.fechaDia.toString(), 
                                    style: const TextStyle( 
                                      color: Colors.white, 
                                      fontSize: 40.0, 
                                      fontWeight: FontWeight.w600,
                                      
                                    )
                                  ),
                                  Text(
                                    egresoProvider.fechaMes.toString() == '1' ? 'Ene' : 
                                    egresoProvider.fechaMes.toString() == '2' ? 'Feb' :
                                    egresoProvider.fechaMes.toString() == '3' ? 'Mar' :
                                    egresoProvider.fechaMes.toString() == '4' ? 'Abr' :
                                    egresoProvider.fechaMes.toString() == '5' ? 'May' : 
                                    egresoProvider.fechaMes.toString() == '6' ? 'Jun' :
                                    egresoProvider.fechaMes.toString() == '7' ? 'Jul' : 
                                    egresoProvider.fechaMes.toString() == '8' ? 'Ago' :
                                    egresoProvider.fechaMes.toString() == '9' ? 'Sep' :
                                    egresoProvider.fechaMes.toString() ==  '10' ? 'Oct' :
                                    egresoProvider.fechaMes.toString() ==  '11' ? 'Nov' :
                                    egresoProvider.fechaMes.toString() ==  '12' ? 'Dic' : '', 
                                    style: const TextStyle( 
                                      color: Colors.white, 
                                      fontSize: 15.0, 
                                      fontWeight: FontWeight.w400 
                                    )
                                  )
                                ],
                              ),
                            )
                          
                          ),
                          //punto de tanqueo
                          Flexible(
                            child: DropdownSearch(
                                validator: (value) {
                                  if(listaPuntoTanquo.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaPuntoTanquo,
                                showClearButton: true,
                                clearButtonProps: egresoProvider.spinnerPuntoTanqueo == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Puntos de tanqueo',
                                ),
                                selectedItem: egresoProvider.puntoTanquoSeleccionadoCompleto,
                                onChanged: (e) {
                                  egresoProvider.setPuntoTanquoSeleccionado(e);
                                },
                              ),
                          ),
                          
                        ],
                      ),
                      //stock lugar y stock
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                        child: Container(
                            height: 60.0,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: const Color.fromARGB(255, 30, 42, 120),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(1),
                                  spreadRadius: 1,
                                  blurRadius: 2,
                                  offset: const Offset(3, 3)
                                )
                              ]
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text( egresoProvider.ubicacionPuntoTanqueo , style: TextStyle( color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold )),
                                Text('Stock (gls): ${egresoProvider.stock.toString()} ',style: TextStyle( color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold ))
                              ],
                            ),
                        ),
                      ),
                      //proyectos
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: DropdownSearch(
                                validator: (value) {
                                  if(listaProyectos.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaProyectos,
                                showClearButton: true,
                                clearButtonProps: egresoProvider.spinnerProyecto == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Proyectos',
                                ),
                                selectedItem: egresoProvider.proyectoSeleccionadoCompleto,
                                onChanged: (e) {
                                  egresoProvider.setProyectoSeleccionado(e);
                                },
                              ),
                            ),
                          ],
                        ),
                      ),

                      //frentes
                      listaFrentes.isEmpty ? const SizedBox() :
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: DropdownSearch(
                                validator: (value) {
                                  if(listaFrentes.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaFrentes,
                                showClearButton: true,
                                clearButtonProps: egresoProvider.spinnerFrente == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Frentes',
                                ),
                                selectedItem: egresoProvider.frenteSeleccionadoCompleto,
                                onChanged: (e) {
                                  egresoProvider.setFrenteSeleccionado(e);
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      //tipo de combustible
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                        child: Container(
                            height: 60.0,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: const Color.fromARGB(255, 30, 42, 120),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(1),
                                  spreadRadius: 1,
                                  blurRadius: 2,
                                  offset: const Offset(3, 3)
                                )
                              ]
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text('Tipo de combustible: ${egresoProvider.tipoCombustible.toString()}', style: TextStyle( color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold )),
                              ],
                            ),
                        ),
                      ),
                      //Islero
                      /* Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: DropdownSearch(
                                validator: (value) {
                                  if(listaConductores.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode: Mode.MENU,
                                items: listaConductores,
                                selectedItem: egresoProvider.isleroSeleccionadoCompleto,
                                onChanged: (value) {
                                  egresoProvider.setIsleroSeleccionado(value);
                                },
                                clearButtonProps: egresoProvider.spinnerConductor == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)) ,
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Islero',
                                ),
                                showSearchBox: true,
                                showClearButton: true,
                              ),
                            ),
                          ],
                        ),
                      ), */       
                      //activos
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child:DropdownSearch(
                                validator: (value) {
                                  if(listaActivos.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode: Mode.MENU,
                                items: listaActivos,
                                selectedItem: egresoProvider.activoSeleccionadoCompleto,
                                onChanged: (value) {
                                  egresoProvider.setActivosSeleccionado(value);
                                },
                                clearButtonProps: egresoProvider.spinnerActivos == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)) ,
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Activos',
                                ),
                                showSearchBox: true,
                                showClearButton: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                      //conductores
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: DropdownSearch(
                                validator: (value) {
                                  if(listaConductores.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode: Mode.MENU,
                                items: listaConductores,
                                selectedItem: egresoProvider.conductoresSeleccionadoCompleto,
                                onChanged: (value) {
                                  egresoProvider.setConductoresSeleccionado(value);
                                },
                                clearButtonProps: egresoProvider.spinnerConductor == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)) ,
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Conductor',
                                ),
                                showSearchBox: true,
                                showClearButton: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                      //radio buton tanqueo / lavador de filtro
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: Column(
                                children:[
                                  RadioListTile(
                                    title: const Text('Tanqueo'),
                                    value: 2008, 
                                    groupValue: egresoProvider.radioButton,
                                    activeColor: const Color.fromARGB(255, 30, 42, 120),
                                    onChanged: (value) {
                                      egresoProvider.setRadioButton(value);
                                    },
                                  ),
                                  RadioListTile(
                                    title: const Text('Lavado de filtro'),
                                    value: 2010,
                                    activeColor: const Color.fromARGB(255, 30, 42, 120),
                                    groupValue: egresoProvider.radioButton,
                                    onChanged: (value) {
                                      egresoProvider.setRadioButton(value);
                                    },
                                  ),
                                  RadioListTile(
                                    title: const Text('Inicia a operar'),
                                    value: 2284,
                                    activeColor: const Color.fromARGB(255, 30, 42, 120),
                                    groupValue: egresoProvider.radioButton,
                                    onChanged: (value) {
                                      egresoProvider.setRadioButton(value);
                                    },
                                  ),
                                ],
                              ),
                            ),
                            egresoProvider.mostrarCheckFullNoFull == true ?
                            Flexible(
                              child: SwitchListTile(
                                title: Text( egresoProvider.checkFullNoFull == true ? 'FULL':'NO FULL' , style:  const TextStyle( fontSize: 20.0, fontWeight: FontWeight.bold ), ),
                                contentPadding:const EdgeInsets.all(25),
                                activeColor:const Color.fromARGB(255, 30, 42, 120),
                                activeTrackColor: const Color.fromARGB(157, 30, 42, 120),
                                value: egresoProvider.checkFullNoFull, 
                                onChanged: (value) {
                                  egresoProvider.setCheckFullNoFull(value);
                                },
                                controlAffinity : ListTileControlAffinity.leading
                              ),
                            ) : SizedBox()
                          ],
                        ),
                      ),
                      //volumen
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text('Volumen (Gls):' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  TextFormField(
                                      validator: (value) {
                                        if (value!.isEmpty) {
                                          return "campo requerido";
                                        }
                                        return null;
                                      },
                                      maxLength: 6,
                                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9.]')),],
                                      decoration: const InputDecoration(
                                        errorStyle: TextStyle(
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(17.0)),
                                        ),
                                      ),
                                      onChanged: (value){
                                        egresoProvider.setVolumen(value);
                                      },
                                      textAlign: TextAlign.center,
                                      style: const TextStyle( fontSize: 100, fontWeight: FontWeight.bold ),
                                    ),
                                ],
                              ) 
                            )
                          ],
                        ),
                      ),
                      //numero del contador post tanqueo
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text('N° Contador post tanqueo:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  TextFormField(
                                     /*  validator: (value) {
                                        if (value!.isEmpty) {
                                          return "campo requerido";
                                        }
                                      }, */
                                      onChanged: (value){
                                        egresoProvider.setCOntadorPostTanqueo(value);
                                      },
                                      maxLength: 10,
                                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9.]')),],
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                        errorStyle: TextStyle(
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(17.0)),
                                        ),
                                        labelText: 'Ecriba el número del contador despues del tanqueo',
                                      ),
                                    )
                                ],
                              ) 
                            )
                          ],
                        ),
                      ),
                      //check inicio a operar
                      /* Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: CheckboxListTile(
                            contentPadding: const EdgeInsets.only(left: 10,right: 220) ,
                            title: const Text('Inició a operar'),
                            activeColor:const Color.fromARGB(255, 30, 42, 120),
                            value: egresoProvider.checkInicioOperar,
                            onChanged: (value) {
                              egresoProvider.setCheckInicioOperar(value);
                            },
                          ),
                      ), */
                      //sello anterior
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: Column(
                                children: [
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text("Sello anterior:" , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  egresoProvider.spinnerDatosAnteriores == true ?
                                  const SizedBox(
                                    width: 10,
                                    height: 10,
                                    child: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  ))
                                  :
                                  TextFormField(
                                    enabled: false,
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      labelText: egresoProvider.radioButton != 2008 ? '--' : egresoProvider.selloAnterior.toString(),
                                    ),
                                  ),
                                ],
                              )
                            ),
                            Flexible(
                              child: Column(
                                children: [
                                  //SizedBox(height: 20),
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text('Sello actual:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  TextFormField(
                                      /* validator: (value) {
                                        if (value!.isEmpty) {
                                          return "campo requerido";
                                        }
                                      }, */
                                      onChanged: (value){
                                        egresoProvider.setSelloActual(value);
                                      },
                                      maxLength: 20,
                                      keyboardType: TextInputType.text,
                                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[A-Za-z0-9-]')),],
                                      decoration: const InputDecoration(
                                        errorStyle: TextStyle(
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(17.0)),
                                        ),
                                        labelText: 'Número del sello',
                                    ),
                                  ),
                                ],
                              )
                            )
                          ],
                        )
                      ),
                      //horometro anterior
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: Column(
                                children: [
                                  //SizedBox(height: 20),
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text('Horometro ant:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  egresoProvider.spinnerDatosAnteriores == true ?
                                  const SizedBox(
                                    width: 10,
                                    height: 10,
                                    child: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  ))
                                  :
                                  TextFormField(
                                    enabled: false,
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      labelText: egresoProvider.radioButton != 2008 ? '--' : egresoProvider.horometroAnterior.toString(),
                                    ),
                                  ),
                                ],
                              )
                            ),
                            Flexible(
                              child: Column(
                                children: [
                                  //SizedBox(height: 20),
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text('Horometro actual:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  TextFormField(
                                      validator: (value) {
                                        print(egresoProvider.estadoHorometro);
                                        if (egresoProvider.estadoHorometro == true) {
                                          if(value == ""){
                                            return "campo requerido";
                                          }else{
                                            return null;
                                          }
                                        }else{
                                          return null;
                                        }
                                      },
                                      onChanged: (value){
                                        egresoProvider.setHorometroActual(value);
                                      },
                                      maxLength: 10,
                                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9.]')),],
                                      decoration: const InputDecoration(
                                        errorStyle: TextStyle(
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(17.0)),
                                        ),
                                        labelText: 'Número del horometro',
                                    ),
                                  ),
                                ],
                              )
                            )
                          ],
                        )
                      ),
                      //kilometraje anterior
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: Column(
                                children: [
                                  //SizedBox(height: 20),
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text('Kilometraje ant:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  egresoProvider.spinnerDatosAnteriores == true ?
                                  const SizedBox(
                                    width: 10,
                                    height: 10,
                                    child: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  ))
                                  :
                                  TextFormField(
                                    enabled: false,
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      labelText: egresoProvider.radioButton != 2008 ? '--' : egresoProvider.kilometrajeAnterior.toString(),
                                    ),
                                  ),
                                ],
                              )
                            ),
                            Flexible(
                              child: Column(
                                children: [
                                  //SizedBox(height: 20),
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child:  Text('Kilometraje actual:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                  ),
                                  const SizedBox(height: 10.0),
                                  TextFormField(
                                      validator: (value) {
                                        print(egresoProvider.estadoOdometro);
                                        if (egresoProvider.estadoOdometro == true) {
                                          if(value == ""){
                                            return "campo requerido";
                                          }else{
                                            return null;
                                          }
                                        }else{
                                          return null;
                                        }
                                      },
                                      onChanged: (value){
                                        egresoProvider.setKilometrajeActual(value);
                                      },
                                      maxLength: 10,
                                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9.]')),],
                                      decoration: const InputDecoration(
                                        errorStyle: TextStyle(
                                          color: Color.fromARGB(255, 255, 0, 0),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(17.0)),
                                        ),
                                        labelText: 'Número del kilometraje',
                                    ),
                                  ),
                                ],
                              )
                            )
                          ],
                        )
                      ),
                      //calculo del galon/hr -- km/galon
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: Container(
                                  height: egresoProvider.checkInicioOperar == true ? 50.0 : egresoProvider.alertaGalHr == true ? 100.0 : 50.0,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: egresoProvider.checkInicioOperar == true ? const Color.fromARGB(255, 30, 42, 120) : egresoProvider.alertaGalHr == true ? const Color.fromARGB(255, 248, 248, 248) : const Color.fromARGB(255, 30, 42, 120) ,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(1),
                                        spreadRadius: 1,
                                        blurRadius: 2,
                                        offset: const Offset(3, 3)
                                      )
                                    ]
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text(  'Galon / Hr:', style: TextStyle( color: egresoProvider.checkInicioOperar == true ? Colors.white : egresoProvider.alertaGalHr == true ? Colors.black : Colors.white, fontSize: 18, fontWeight: FontWeight.bold )),
                                      Text( egresoProvider.checkInicioOperar == true ? '--' : egresoProvider.valorGalonHr.toString(), style: TextStyle( color: egresoProvider.checkInicioOperar == true ? Colors.white : egresoProvider.alertaGalHr == true ? Colors.black : Colors.white, fontSize: 18, fontWeight: FontWeight.bold )),
                                      if(egresoProvider.checkInicioOperar != true)
                                        egresoProvider.alertaGalHr == true ?
                                        Padding(
                                          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                                          child: Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: const <Widget>[
                                                  FaIcon( FontAwesomeIcons.triangleExclamation , color: Colors.amber, size: 15),
                                                  SizedBox(width: 10),
                                                  Expanded(
                                                    child:Text('El total no debe ser un número negativo.', 
                                                    style: TextStyle( color: Color.fromARGB(255, 211, 24, 24), fontSize: 15, fontWeight: FontWeight.bold )
                                                    ),),
                                                ],
                                              ),
                                        ) : const SizedBox(height: 0, width: 0),
                                      
                                    ],
                                  ),
                              ),
                            ),
                            
                            const SizedBox(width: 10),
                            Flexible(
                              child: Container(
                                  height: egresoProvider.checkInicioOperar == true ? 50.0 : egresoProvider.alertaKmGl == true ? 100.0 : 50.0,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color:  egresoProvider.checkInicioOperar == true ? const Color.fromARGB(255, 30, 42, 120) : egresoProvider.alertaKmGl == true ? const Color.fromARGB(255, 248, 248, 248) : const Color.fromARGB(255, 30, 42, 120),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(1),
                                        spreadRadius: 1,
                                        blurRadius: 2,
                                        offset: const Offset(3, 3)
                                      )
                                    ]
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text('Km / Gal:', style: TextStyle( color: egresoProvider.checkInicioOperar == true ? Colors.white : egresoProvider.alertaKmGl == true ? Colors.black : Colors.white, fontSize: 18, fontWeight: FontWeight.bold )),
                                      Text( egresoProvider.checkInicioOperar == true ? '--' : egresoProvider.valorKilometroHr.toString(), style: TextStyle( color: egresoProvider.checkInicioOperar == true ? Colors.white : egresoProvider.alertaKmGl == true ? Colors.black : Colors.white, fontSize: 18, fontWeight: FontWeight.bold )),
                                       if(egresoProvider.checkInicioOperar != true)
                                        egresoProvider.alertaKmGl == true ?
                                        Padding(
                                          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                                          child: Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: const  <Widget>[
                                                  FaIcon( FontAwesomeIcons.triangleExclamation , color: Colors.amber, size: 15),
                                                  SizedBox(width: 10),
                                                  Expanded(
                                                    child:Text('El total no debe ser un número negativo.', 
                                                    style: TextStyle( color: Color.fromARGB(255, 211, 24, 24), fontSize: 15, fontWeight: FontWeight.bold )
                                                    ),)
                                                ],
                                              ),
                                        ) : const SizedBox(height: 0, width: 0),
                                      
                                    ],
                                  ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      Padding(
                          padding:
                              const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                          child: Row(
                            children: [
                              const Text('Adjuntar archivo', 
                              textAlign: TextAlign.left,
                                        style: TextStyle(
                                            color: Color.fromARGB(255, 243, 121, 21),
                                            fontSize: 18.0,
                                            fontWeight: FontWeight.bold)),  
                              const SizedBox(width: 1.0),
                              TextButton(
                                    onPressed: (){
                                      Scaffold.of(context).showBottomSheet<void>(
                                        (BuildContext context) {
                                          return Container(
                                            height: 150,
                                            decoration: const BoxDecoration(
                                              color: Color.fromARGB(255, 255, 255, 255),
                                              boxShadow:  [
                                                BoxShadow(
                                                  color: Color.fromARGB(255, 99, 99, 99),
                                                  offset:  Offset(5.0, 5.0),
                                                  blurRadius: 10.0,
                                                  spreadRadius: 2.0,
                                                ),
                                              ],
                                              borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(10),
                                                topRight: Radius.circular(10),
                                              ),
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(height: 20,),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceAround ,
                                                  children: [
                                                  
                                                    TextButton(
                                                      onPressed: ()async{ 
                                                        var resultado = await egresoProvider.seleccionarImagen(0, context); 
                                                        if (resultado) {
                                                          alerta(context,egresoProvider.mensajeAdjuntoDocumentos.toString(),true);
                                                        }else{
                                                          alerta(context,egresoProvider.mensajeAdjuntoDocumentos.toString(),false);
                                                        }
                                                      }, 
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        children: [
                                                          Image.asset( 'lib/app_gestion_combustible/sources/adjuntar/camara.png', width: 35),
                                                          const Text("Cámara", style: TextStyle(color: Colors.black),)
                                                        ],
                                                      )
                                                    ),
                                                    TextButton(
                                                      onPressed: ()async{ 
                                                      var resultado = await egresoProvider.seleccionarImagen(1, context);

                                                        if (resultado) {
                                                          alerta(context,egresoProvider.mensajeAdjuntoDocumentos.toString(),true);
                                                        }else{
                                                          alerta(context,egresoProvider.mensajeAdjuntoDocumentos.toString(),false);
                                                        }
                                                      
                                                      }, 
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        children: [
                                                          Image.asset( 'lib/app_gestion_combustible/sources/adjuntar/documento.png', width: 35),
                                                          const Text("Documento",style: TextStyle(color: Colors.black))
                                                        ],
                                                      )
                                                      
                                                    )
                                                  ],
                                                ),
                                                const SizedBox(height: 10,),
                                                ElevatedButton(
                                                  onPressed: (){ Navigator.pop(context);}, 
                                                  child: Text(
                                                    "Cancelar",  
                                                    style: TextStyle( color: Color.fromARGB(255, 106, 106, 106), fontSize: 18),
                                                  ), 
                                                  style: ButtonStyle(
                                                    backgroundColor: MaterialStateProperty.all(
                                                      Color.fromARGB(255, 255, 255, 255),
                                                    ),
                                                    padding: MaterialStateProperty.all(
                                                      const EdgeInsets.only( left: 100, right: 100 ),
                                                    ),

                                                    shape: MaterialStateProperty.all(
                                                      RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(10),
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              ],
                                            )

                                          );
                                        },
                                      );
                                    }, 
                                    child: Icon(Icons.attach_file),
                                  ),
                              egresoProvider.imagen == null || egresoProvider.imagen == "" ? SizedBox() : 
                              Image.memory(egresoProvider.imagen, width: 100),
                            ],
                          )
                      ),

                      //observaciones
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      const Align(
                                        alignment: Alignment.centerLeft,
                                        child:  Text('Observaciones:' , textAlign: TextAlign.left, style: TextStyle( color: Color.fromARGB(255, 243, 121, 21), fontSize: 18.0, fontWeight: FontWeight.bold ))
                                      ),
                                      const SizedBox(height: 10.0),
                                      TextFormField(
                                        validator: (value) {
                                          if (value!.isEmpty) {
                                            return "campo requerido";
                                          }
                                        },
                                        initialValue: egresoProvider.observaciones.toString(),
                                        onChanged: (value){
                                          egresoProvider.setObservaciones(value);
                                        },
                                        maxLines: 3,
                                        keyboardType: TextInputType.multiline,
                                        decoration: const InputDecoration(       
                                          errorStyle: TextStyle(
                                            color: Color.fromARGB(255, 255, 0, 0),
                                            fontSize: 15,
                                            fontWeight: FontWeight.w400),              
                                          border: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(17.0)),
                                        ),
                                        labelText: 'Escriba las observaciones',
                                        ),
                                      )
                                    ],
                                  ) 
                                ),
                          ],
                        )
                      ),
                      //boton de guardar
                      Padding(
                        padding: const EdgeInsets.only(bottom:8, top: 20, left: 110, right: 110),
                        child: TextButton(
                          onPressed: () async {
                            
                            if (keyFormularioEgreso.currentState!.validate()) {
                              EasyLoading.show(status: 'Cargando...');
                              bool resultado = await egresoProvider.guardarFormularioEgreso();
                    
                              if (resultado) {
                                EasyLoading.dismiss();
                                alerta(context, 'Información guardada correctamente.', resultado);
                                await Future.delayed(Duration(seconds: 1));
                                keyFormularioEgreso.currentState!.reset();
                                egresoProvider.reiniciarFormulario();
                              } else {
                                EasyLoading.dismiss();
                                alerta(context, 'No hay suficiente combustible, \n stock disponible: ${egresoProvider.stock} ', resultado);
                                //keyFormularioEgreso.currentState!.reset();
                                //egresoProvider.reiniciarFormulario();
                              }
                              
                            }else{
                              return;
                            }
                          }, 
                          style: const ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll<Color>(Color.fromARGB(255, 243, 121, 21)),
                          ),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.0),
                            child: Text(
                              'Guardar',
                              style: TextStyle( color: Colors.white , fontSize: 20.0, fontWeight: FontWeight.bold),
                            ),
                          )
                        ),
                      ),
                      //boton de cancelar
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10, top: 5, left: 110, right: 110),
                        child: TextButton(
                          onPressed: () {
                          
                            keyFormularioEgreso.currentState!.reset();
                            egresoProvider.reiniciarFormulario();
                          },
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.0),
                            child: Text(
                              'Cancelar',
                              style: TextStyle( color: Colors.black , fontSize: 15.0),
                            ),
                          )
                        ),
                      ),
                      
                    ],
                  )
                )
              ],
              ),
            ),
          ),
          builder: EasyLoading.init(),
        );
    }

    //widget de alertas
  Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

}