import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/ingreso_provider.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:dropdown_search/dropdown_search.dart';

class IngresoFormulario extends StatefulWidget{
  const IngresoFormulario({super.key});


  @override
  State<IngresoFormulario>createState(){
    return StateIngresoFormulario();
  }

}

class StateIngresoFormulario extends State<IngresoFormulario>{

  final keyFormularioIngreso = GlobalKey<FormState>();


  @override
  void initState() {

    final ingresoProvider  = Provider.of<IngresoProvider>(context, listen: false);
    
    ingresoProvider.obtenerSession();
    ingresoProvider.obtenerConsecutivoIngreso();
    ingresoProvider.obtenerPuntosTanqueo();
    ingresoProvider.obtenerProveedores();
      
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    //importo el provider
    final ingresoProvider = Provider.of<IngresoProvider>(context);

    late List<dynamic> listaPuntoTanquo =[];
    listaPuntoTanquo = ingresoProvider.listaPuntoTanquo;

    late List<dynamic> listaProveedores =[]; 
    listaProveedores = ingresoProvider.listaProvedores;

    late List<dynamic> listaUsuarios =[]; 
    listaUsuarios = ingresoProvider.listaUsuarios;

    ingresoProvider.desacoplaFecha();

    return ListView(
      children: [
        Form(
          key: keyFormularioIngreso,
          child: Column(
            children: [
              const SizedBox(height: 30.0),
              //primera fila
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Flexible(
                      child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: const Color.fromARGB(255, 30, 42, 120),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.grey.withOpacity(1),
                              spreadRadius: 1,
                              blurRadius: 2,
                              offset: const Offset(3, 2))
                        ]),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        Text( ingresoProvider.fechaDia.toString() ,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 40.0,
                              fontWeight: FontWeight.w600,
                            )),
                        Text( 
                          ingresoProvider.fechaMes.toString() == '1' ? 'Ene' : 
                          ingresoProvider.fechaMes.toString() == '2' ? 'Feb' :
                          ingresoProvider.fechaMes.toString() == '3' ? 'Mar' :
                          ingresoProvider.fechaMes.toString() == '4' ? 'Abr' :
                          ingresoProvider.fechaMes.toString() == '5' ? 'May' : 
                          ingresoProvider.fechaMes.toString() == '6' ? 'Jun' :
                          ingresoProvider.fechaMes.toString() == '7' ? 'Jul' : 
                          ingresoProvider.fechaMes.toString() == '8' ? 'Ago' :
                          ingresoProvider.fechaMes.toString() == '9' ? 'Sep' :
                          ingresoProvider.fechaMes.toString() ==  '10' ? 'Oct' :
                          ingresoProvider.fechaMes.toString() ==  '11' ? 'Nov' :
                          ingresoProvider.fechaMes.toString() ==  '12' ? 'Dic' : '',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15.0,
                                fontWeight: FontWeight.w400))
                      ],
                    ),
                  )),
                  Flexible(
                      child: SwitchListTile(
                    title: Text(
                      ingresoProvider.checkCompraRemanente == true ? 'COMPRA' : 'REMANENTE',
                      style:
                          const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                    ),
                    contentPadding: const EdgeInsets.all(22),
                    activeColor: const Color.fromARGB(255, 30, 42, 120),
                    activeTrackColor: const Color.fromARGB(157, 30, 42, 120),
                    value: ingresoProvider.checkCompraRemanente,
                    onChanged: (value) {
                      ingresoProvider.setCheckCompraRemanente(value);
                    },
                  )),
                ],
              ),
              //segunda fila
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Text(
                        ingresoProvider.checkCompraRemanente == true
                            ? 'Consecutivo ingreso:'
                            : 'Consecutivo remanente',
                        style: const TextStyle(
                            color: Color.fromARGB(255, 243, 121, 21),
                            fontSize: 18,
                            fontWeight: FontWeight.bold)),
                    Text(ingresoProvider.checkCompraRemanente == true ? 'INC-${ingresoProvider.consecutivo}' : 'REM-${ingresoProvider.consecutivo}',
                        style: const TextStyle(
                            color: Color.fromARGB(255, 103, 102, 102),
                            fontSize: 18,
                            fontWeight: FontWeight.bold))
                  ],
                ),
              ),
              //Islero
              /* Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Row(
                          children: [
                            Flexible(
                              child: DropdownSearch(
                                validator: (value) {
                                  if(listaUsuarios.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode: Mode.MENU,
                                items: listaUsuarios,
                                selectedItem: ingresoProvider.isleroSeleccionadoCompleto,
                                onChanged: (value) {
                                  ingresoProvider.setIsleroSeleccionado(value);
                                },
                                clearButtonProps: ingresoProvider.spinnerIslero == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)) ,
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Islero',
                                ),
                                showSearchBox: true,
                                showClearButton: true,
                              ),
                            ),
                          ],
                        ),
                      ), 
              */ //punto de tanqueo
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Row(
                  children: [
                    Flexible(
                      child: 
                      DropdownSearch(
                                validator: (value) {
                                  if(listaPuntoTanquo.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaPuntoTanquo,
                                showClearButton: true,
                                clearButtonProps: ingresoProvider.spinnerPuntoTanqueo == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                    semanticsLabel: "asd",
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Puntos de tanqueo',
                                ),
                                selectedItem: ingresoProvider.puntoTanquoSeleccionadoCompleto,
                                onChanged: (e) {
                                  ingresoProvider.setPuntoTanquoSeleccionado(e);
                                },
                              ),
                  )],
                ),
              ),
              //cuarta fila
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                child: Container(
                  height: 60.0,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: const Color.fromARGB(255, 30, 42, 120),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.grey.withOpacity(1),
                            spreadRadius: 1,
                            blurRadius: 2,
                            offset: Offset(3, 3))
                      ]),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text( ingresoProvider.ubicacionPuntoTanqueo.toString() ,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold)),
                      Text('Stock anterior (Gls): ${ingresoProvider.stock.toString()} ',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold))
                    ],
                  ),
                ),
              ),
              //quinta fila
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Row(
                  children: [
                    Flexible(
                        child: DropdownSearch(
                                validator: (value) {
                                  if(listaProveedores.isEmpty){
                                    return null;
                                  }else if(value == null){
                                    return "campo requerido";
                                  }
                                  return null;
                                },
                                mode : Mode.MENU,
                                showSearchBox: true,
                                items: listaProveedores,
                                showClearButton: true,
                                clearButtonProps: ingresoProvider.spinnerPuntoProveedor == true ? const IconButtonProps(
                                  icon: CircularProgressIndicator(
                                    color: Colors.amber,
                                    strokeWidth: 3,
                                  )
                                ) : const IconButtonProps(icon: Icon(Icons.clear)),
                                dropdownSearchDecoration: const InputDecoration(
                                  labelText: 'Proveedor',
                                ),
                                selectedItem: ingresoProvider.proveedorSeleccionadoCompleto,
                                onChanged: (e) {
                                  ingresoProvider.setProveedorSeleccionado(e);
                                },
                              ),
                        
                        /* DropdownButtonFormField(
                      validator: (value) {
                        if (value == null) {
                          return "campo requerido";
                        }
                      },
                      decoration: const InputDecoration(
                        hintText: 'Proveedor',
                        errorStyle: TextStyle(
                                color: Color.fromARGB(255, 255, 0, 0),
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                      ),
                      items: listaProveedor.map((value) {
                        return DropdownMenuItem(
                          value: value,
                          child: Text(value["nombre"].toString()),
                        );
                      }).toList(),
                      onChanged: (value) {
                        ingresoProvider.setProveedorSeleccionado(value);
                      },
                    ) */
                    ),
                  ],
                ),
              ),
              //sexta fila
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                child: Container(
                  height: 60.0,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: const Color.fromARGB(255, 30, 42, 120),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.grey.withOpacity(1),
                            spreadRadius: 1,
                            blurRadius: 2,
                            offset: Offset(3, 3))
                      ]),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       Text('Tipo de combustible: ${ingresoProvider.tipoCombustible.toString()}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold
                          )
                      ),
                    ],
                  ),
                ),
              ),
              //septima fila
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Row(
                  children: [
                    Flexible(
                        child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Text('Volumen que ingresa(Gls):',
                              textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Color.fromARGB(255, 243, 121, 21),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold
                                )
                            )
                        ),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            ingresoProvider.setVolumen(value);
                          },
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "campo requerido";
                            }
                          },
                          maxLength: 6,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9.]')),],
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(17.0)),
                            ),
                            errorStyle: TextStyle(
                                color: Color.fromARGB(255, 255, 0, 0),
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                          ),
                          textAlign: TextAlign.center,
                          style: const TextStyle( fontSize: 100, fontWeight: FontWeight.bold ),
                        ),
                        
                      ],
                    ))
                  ],
                ),
              ),
              //octava fila
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Row(
                  children: [
                    Flexible(
                      child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const Align(
                            alignment: Alignment.centerLeft,
                            child: Text('Factura:',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Color.fromARGB(255, 243, 121, 21),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold
                                )
                            )
                        ),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            ingresoProvider.setFactura(value.toString());
                          },
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Campo requerido";
                            }
                          },
                          maxLength: 20,
                          keyboardType: TextInputType.text,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[A-Za-z0-9]')),],
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(17.0)),
                            ),
                            errorStyle: TextStyle(
                                color: Color.fromARGB(255, 255, 0, 0),
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                            labelText: "Número factura",
                          ),
                        )
                      ],
                      )
                    ),
                    const SizedBox(width: 15 ),                  
                    Flexible(
                        child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const Align(
                            alignment: Alignment.centerLeft,
                            child: Text('Guía:',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Color.fromARGB(255, 243, 121, 21),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold))),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            ingresoProvider.setGuia(value.toString());
                          },
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Campo requerido";
                            }
                          },
                          maxLength: 20,
                          keyboardType: TextInputType.text,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[A-Za-z0-9]')),],
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(17.0)),
                            ),
                            labelText: 'Número de guía',
                            errorStyle: TextStyle(
                                color: Color.fromARGB(255, 255, 0, 0),
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                          ),
                        )
                      ],
                    ))
                  ],
                ),
              ),
              //novena fila
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),  
                child: Row(
                  children: <Widget>[
                    Flexible(
                        child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                        const Align(
                            alignment: Alignment.centerLeft,
                            child: Text('Conductor:',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Color.fromARGB(255, 243, 121, 21),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold)
                              )
                          ),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            ingresoProvider.setConductor(value.toString());
                          },
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Campo requerido";
                            }
                          },
                          maxLength: 60,
                          keyboardType: TextInputType.text,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[A-Za-z ]')),],
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(17.0)),
                            ),
                            labelText: 'Nombre del conductor',
                            errorStyle: TextStyle(
                                color: Color.fromARGB(255, 255, 0, 0),
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                          ),
                        )
                      ],
                    )),
                    const SizedBox(width: 15),
                    Flexible(
                        child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const Align(
                            alignment: Alignment.centerLeft,
                            child: Text('Placa de vehículo:',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Color.fromARGB(255, 243, 121, 21),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold))),
                        const SizedBox(height: 10.0),
                        TextFormField(
                          onChanged: (value) {
                            ingresoProvider.setPlacaVehiculo(value.toString());
                          },
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Campo requerido";
                            }
                          },
                          maxLength: 6,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[A-Za-z0-9]')),],
                          keyboardType: TextInputType.text,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(17.0)),
                            ),
                            labelText: 'Placa',
                            errorStyle: TextStyle(
                                color: Color.fromARGB(255, 255, 0, 0),
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                          ),
                        )
                      ],
                    ))
                  ],
                ),
              ),
              //adjuntar archivo
              Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  child: Row(
                    children: [
                      const Text('Adjuntar archivo', 
                      textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Color.fromARGB(255, 243, 121, 21),
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold)),  
                      const SizedBox(width: 1.0),
                      TextButton(
                            onPressed: (){
                              Scaffold.of(context).showBottomSheet<void>(
                                (BuildContext context) {
                                  return Container(
                                    height: 150,
                                    decoration: const BoxDecoration(
                                      color: Color.fromARGB(255, 255, 255, 255),
                                      boxShadow:  [
                                        BoxShadow(
                                          color: Color.fromARGB(255, 99, 99, 99),
                                          offset:  Offset(5.0, 5.0),
                                          blurRadius: 10.0,
                                          spreadRadius: 2.0,
                                        ),
                                      ],
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(10),
                                        topRight: Radius.circular(10),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        const SizedBox(height: 20,),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceAround ,
                                          children: [
                                          
                                            TextButton(
                                              onPressed: ()async{ 
                                                var resultado = await ingresoProvider.seleccionarImagen(0, context); 
                                                if (resultado) {
                                                  alerta(context,ingresoProvider.mensajeAdjuntoDocumentos.toString(),true);
                                                }else{
                                                  alerta(context,ingresoProvider.mensajeAdjuntoDocumentos.toString(),false);
                                                }
                                              }, 
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Image.asset( 'lib/app_gestion_combustible/sources/adjuntar/camara.png', width: 35),
                                                  const Text("Cámara", style: TextStyle(color: Colors.black),)
                                                ],
                                              )
                                            ),
                                            TextButton(
                                              onPressed: ()async{ 
                                              var resultado = await ingresoProvider.seleccionarImagen(1, context);

                                                if (resultado) {
                                                  alerta(context,ingresoProvider.mensajeAdjuntoDocumentos.toString(),true);
                                                }else{
                                                  alerta(context,ingresoProvider.mensajeAdjuntoDocumentos.toString(),false);
                                                }
                                              
                                              }, 
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Image.asset( 'lib/app_gestion_combustible/sources/adjuntar/documento.png', width: 35),
                                                  const Text("Documento",style: TextStyle(color: Colors.black))
                                                ],
                                              )
                                              
                                            )
                                          ],
                                        ),
                                        const SizedBox(height: 10,),
                                        ElevatedButton(
                                          onPressed: (){ Navigator.pop(context);}, 
                                          child: Text(
                                            "Cancelar",  
                                            style: TextStyle( color: Color.fromARGB(255, 106, 106, 106), fontSize: 18),
                                          ), 
                                          style: ButtonStyle(
                                            backgroundColor: MaterialStateProperty.all(
                                              Color.fromARGB(255, 255, 255, 255),
                                            ),
                                            padding: MaterialStateProperty.all(
                                               const EdgeInsets.only( left: 100, right: 100 ),
                                            ),

                                            shape: MaterialStateProperty.all(
                                              RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    )

                                  );
                                },
                              );
                            }, 
                            child: Icon(Icons.attach_file),
                          ),
                      ingresoProvider.imagen == null || ingresoProvider.imagen == "" ? SizedBox() : 
                      Image.memory(ingresoProvider.imagen, width: 100),
                    ],
                  )
              ),
              //decima fila
              Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  child: Row(
                    children: [
                      Flexible(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Align(
                              alignment: Alignment.centerLeft,
                              child: Text('Observaciones:',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                      color: Color.fromARGB(255, 243, 121, 21),
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.bold))),
                          const SizedBox(height: 10.0),
                          TextFormField(
                            onChanged: (value) {
                              ingresoProvider.setObservaciones(value.toString());
                            },
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Campo requerido";
                              }
                            },
                            maxLines: 2,
                            keyboardType: TextInputType.multiline,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(17.0)),
                              ),
                              labelText: 'Escriba las observaciones',
                              errorStyle: TextStyle(
                                  color: Color.fromARGB(255, 255, 0, 0),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400
                              ),  
                            ),
                          )
                        ],
                      )),
                    ],
                  )),
              //onceava fila
              Padding(
                padding: const EdgeInsets.only(bottom: 5, top: 20, left: 110, right: 110),
                child: TextButton(
                    onPressed: () async {
                      if (keyFormularioIngreso.currentState!.validate()) {
                          bool resultado = await ingresoProvider.guardarFormularioIngreso();
                    
                          if (resultado) {
                            keyFormularioIngreso.currentState!.reset();
                            ingresoProvider.reiniciarFormulario();
                            alerta(context, 'Información guardada correctamente.', resultado);                            
                          } else {
                            alerta(context, 'La información no se pudo guardar, intentelo de nuevo.', resultado);
                          }
                              
                      }else{
                        return;
                      }
                    },
                    style: const ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll<Color>(
                          Color.fromARGB(255, 243, 121, 21)),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.0),
                      child: Text(
                        'Guardar',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold),
                      ),
                    )),
              ),
              //boton de cancelar
              Padding(
                        padding: const EdgeInsets.only(bottom: 10, top: 5, left: 110, right: 110),
                        child: TextButton(
                          onPressed: () {
                            keyFormularioIngreso.currentState!.reset();
                            ingresoProvider.reiniciarFormulario();
                          },
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.0),
                            child: Text(
                              'Cancelar',
                              style: TextStyle( color: Colors.black , fontSize: 15.0),
                            ),
                          )
                        ),
                      ),
                      
            ],
          ),
        )
        
      ]
    );
  }

  /*
   *@wiged alerta
   *funcionalidad Se encarga de mostrar un mensaje 
   */
  Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 100,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  

}