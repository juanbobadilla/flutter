import 'package:com_gestioncombustible_app/app_gestion_combustible/views/login/login_view.dart';
import 'package:flutter/material.dart';

class MenuLateral extends StatefulWidget{
  const MenuLateral({super.key});

  @override
  State<MenuLateral>createState(){
    return StateMenuLateral();
  }
}

class StateMenuLateral extends State<MenuLateral>{

  @override
    Widget build(BuildContext context) {
      return Drawer(
        child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          //icono y datos del usuario
          Container(
            height: 280.0,
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.centerRight,
                  colors: <Color>[Color.fromARGB(255, 255, 128, 0), Colors.yellow]
                ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const <Widget>[
                Icon(Icons.account_circle, size: 130.0, color: Colors.white),
                Text('Ana Victoria Perdomo Fajardo', style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.bold)),
                Text('1075123456', style: TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.bold),),
                Text('Professional I+D', style: TextStyle(color: Colors.white, fontSize: 15.0, fontWeight: FontWeight.bold))
              ],
            ),
          ),
          //cuerpo del Drawer
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: (){
                Navigator.of(context).pushNamedAndRemoveUntil('Login', (Route<dynamic> route) => false);
              }, 
              icon: const Icon(Icons.logout, color: Colors.black,), 
              label: const Text('Salir', style: TextStyle( color: Colors.black, fontSize: 20.0 ),)
            ),
          ),
        ],
      ),
        );
    }
}