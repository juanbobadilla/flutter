import 'package:com_gestioncombustible_app/app_gestion_combustible/controller/home/home_controller.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/sincronizar_provider.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:com_gestioncombustible_app/app_gestion_combustible/providers/login_provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => StateHome();
}

class StateHome extends State<Home> {
  //instancio el controlador del home
  var homeController = HomeController();

  @override
    void initState() {
      final loginProvider = Provider.of<LoginProvider>(context, listen: false);
      final sincronizarProvider = Provider.of<SincronizarProvider>(context, listen: false);

      loginProvider.obtenerSesion();
      sincronizarProvider.obtenerSesion();
    
      super.initState();
    }

  @override
  Widget build(BuildContext context) {

    //importo el provider
    final sincronizarProvider = Provider.of<SincronizarProvider>(context);
  

    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) {
            return alertaSalir(context);
          },
        );
        return shouldPop!;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          iconTheme: const IconThemeData(color: Color.fromARGB(255, 242, 103, 33)),
          centerTitle: true,
          title: Text(
            'REPORSSEQ',
            style: GoogleFonts.quicksand(
                color: Color.fromARGB(255, 35, 35, 35),
                fontSize: 20,
                fontWeight: FontWeight.w500,
              )
            //style: TextStyle(color: Color.fromARGB(255, 30, 42, 120), fontSize: 20.0),
          ),
          actions: <Widget> [
            Image(
              width: 45,
              image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
              fit: BoxFit.fitWidth, 
            ),
            SizedBox(width: 5,)
          ],
        ),
        drawer: menuLateral(context),
        body: 
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            
            /* const SizedBox(height: 60.0),  
            tarjeta(), */
            const SizedBox(height: 20.0),  
            tarjetaReporteObras(context),
            const SizedBox(height: 20.0), 
            tarjetaControlCombustible(context),
            
              /* const SizedBox(height: 60.0),  
              tarjeta(),
              const SizedBox(height: 40.0),
              tarjetaReporteObras(context),
              const SizedBox(height: 40.0),
              tarjetaControlCombustible(context), */
              //const SizedBox(height: 40.0),
            ], //tarjetaControlCombustible(),
          ),
        bottomNavigationBar: CurvedNavigationBar(
          index: 0,
          onTap: (index){
            if(index == 0){
              homeController.irPagina(context, 'Home');
            }
            if(index == 1){
              homeController.irPagina(context, 'Menu4');
            }
          },
          animationDuration : Duration(milliseconds: 300),
          height:75,
          buttonBackgroundColor:Color.fromARGB(255, 242, 103, 34),
          backgroundColor: Color.fromARGB(0, 255, 255, 255),
          color: Color.fromARGB(255, 0, 77, 150),
          items: const [
            Icon( //ICONO
                  FontAwesomeIcons.rotate,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
          ],
         ),

        ),
    );
  }

  //widget tarjeta sin nombre
  Widget tarjeta(){
    /* return  GestureDetector(
      // Cuando el hijo reciba un tap, muestra un snackbar
      /* onTap: () {
        homeController.irPagina();
      }, */
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50.0),
            child: Container( //contenedor primario
              width: double.infinity,
              height: 150.0,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 31, 166, 112),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(1),
                    spreadRadius: 2,
                    blurRadius: 7,
                    offset: Offset(5, 5)
                  ),
                ]
              ),
              child: const Align( 
                alignment: Alignment.centerRight,
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      'Nombre sin definir',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 35.0
                      ),
                    ),
                  ),
                ), 
              ),
            ),
          ),
          /* Positioned(
              top: 25,
              left: 20.0,
              child: Image.asset(
                'lib/sources/home/combustible.png',
                height: 100.0,
            ),
          ), */
        ],
      )
    ); */
    return Padding(
      padding: const EdgeInsets.only(left: 30, right: 30),
      child: GestureDetector(
        onTap: (){

        },
        child: Container(
          decoration: BoxDecoration(
                color: Color.fromARGB(255, 244, 210, 210),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(1),
                    spreadRadius: 1,
                    blurRadius: 7,
                    offset: Offset(0, 0)
                  ),
                ]
              ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              Padding(
                padding: const EdgeInsets.all(10),
                child: Container(
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 244, 94, 94),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: EdgeInsets.all(10),
                  child: const Icon(
                    Icons.device_unknown,
                    size: 80,
                    color: Colors.white,
                    ),
                ),
              ),
              const SizedBox(width: 50,),
              Text(
                "Desconocida",
                style: GoogleFonts.quicksand(
                    color: Color.fromARGB(181, 51, 50, 50),
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                ),
              )

            ],
          ),
        ),
      ),
    );
  }

  //widget tarjeta reporte personal
  Widget tarjetaReporteObras(BuildContext context){
    /* return  GestureDetector(
      onTap: () {
        homeController.irPagina(context, "Menu1");
      },
      child: Stack(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 50.0),
            child: Container( //contenedor primario
              width: double.infinity,
              height: 150.0,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 30, 42, 120),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(1),
                    spreadRadius: 2,
                    blurRadius: 7,
                    offset: Offset(5, 5)
                  ),
                ]
              ),
              child: const Align( 
                alignment: Alignment.centerRight,
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      'Reporte de obras',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 35.0
                      ),
                    ),
                  ),
                ), 
              ),
            ),
          ),
          /* Positioned(
              top: 25,
              left: 20.0,
              child: Image.asset(
                'lib/sources/home/combustible.png',
                height: 100.0,
            ),
          ), */
        ],
      )
    ); */
    
    return Padding(
      padding: EdgeInsets.only(left: 30, right: 30),
        child: GestureDetector(
          onTap: (){
            homeController.irPagina(context, "Menu1");
          },
          child: Container(
                  decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.center,
                          colors: <Color>[Color.fromARGB(255, 0, 120, 189), Color.fromARGB(255, 31, 93, 169)]
                        ),
                        //color: Color.fromARGB(255, 255, 175, 135),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(1),
                            spreadRadius: 1,
                            blurRadius: 7,
                            offset: Offset(0, 0)
                          ),
                        ]
                      ),
                  child: Row(
                    
                    children: [
              
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color.fromARGB(255, 13, 82, 166),
                            //borderRadius: BorderRadius.circular(20),
                          ),
                          padding: EdgeInsets.all(10),
                          child:const Icon(
                            Icons.note_alt,
                            size: 80,
                            color: Color.fromARGB(255, 255, 255, 255),
                            ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Control Obra",
                          style: GoogleFonts.quicksand(
                              color: Color.fromARGB(255, 255, 255, 255),
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                          ),
                        ),
                      )
              
                    ],
                  ),
                ),
        ),
      );
    
  }

  //widget tarjeta control de combustible
  Widget tarjetaControlCombustible(BuildContext context){
    /* return  GestureDetector(
      onTap: () {
        homeController.irPagina(context, "StockPuntoTanqueo");
      },
      child: Stack(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 50.0),
            child: Container( //contenedor primario
              width: double.infinity,
              height: 150.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  begin: Alignment.center,
                  colors: <Color>[Color.fromARGB(255, 255, 128, 0), Colors.yellow]
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(1),
                    spreadRadius: 2,
                    blurRadius: 7,
                    offset: Offset(5, 5)
                  ),
                ]
              ),
              child: const Align( 
                alignment: Alignment.centerRight,
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      'Control Combustible',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontSize: 35.0
                      ),
                    ),
                  ),
                ), 
              ),
            ),
          ),
          Positioned(
              top: 25,
              left: 20.0,
              child: Image.asset(
                'lib/app_gestion_combustible/sources/home/combustible.png',
                height: 100.0,
            ),
          ),
        ],
      )
    ); */
    return  Padding(
      padding: EdgeInsets.only(left: 30, right: 30),
        child: GestureDetector(
          onTap: () {
            homeController.irPagina(context, "StockPuntoTanqueo");
          },
          child: Container(
              decoration: BoxDecoration(
                    gradient: const LinearGradient(
                          begin: Alignment.center,
                          colors: <Color>[Color.fromARGB(255, 253, 184, 46), Color.fromARGB(255, 248, 159, 50)]
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(1),
                        spreadRadius: 1,
                        blurRadius: 7,
                        offset: Offset(0, 0)
                      ),
                    ]
                  ),
              child: Row(
                
                children: [

                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color.fromARGB(255, 255, 145, 11),
                        //borderRadius: BorderRadius.circular(20),
                      ),
                      padding: EdgeInsets.all(10),
                      child: const Icon(
                        Icons.local_gas_station,
                        size: 80,
                        color: Colors.white,
                        ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Gestion Combustible",
                      style: GoogleFonts.quicksand(
                          color: Color.fromARGB(255, 255, 255, 255),
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                      ),
                    ),
                  )

                ],
              ),
            ),

        ),
      );
    
  }

  //menu lateral
  Widget menuLateral(BuildContext context){

    //importo el provider
    final sincronizarProvider = Provider.of<SincronizarProvider>(context);

    var usuario = context.watch<LoginProvider>().nombreUsuario;
    var documento = context.watch<LoginProvider>().documento;
    var cargo = context.watch<LoginProvider>().cargo;

    return Drawer(
        child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
            //icono y datos del usuario
            Container(
              height: 200.0,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Color.fromARGB(27, 0, 0, 0)
                  )
                )
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Image(
                    width: 65,
                    image: AssetImage("lib/app_gestion_combustible/sources/home/iconoUsario.png",),
                    fit: BoxFit.cover, 
                    ),
                  SizedBox(height: 10),
                  Text(usuario.toString(), textAlign: TextAlign.center ,style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 5),
                  Text(cargo.toString(), style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontSize: 15.0, fontWeight: FontWeight.w400))
                ],
              ),
            ),
            
            Column(//CUERPO DEL DRAWER
              children: <Widget>[
                SizedBox(//BOTON DE COPIA DE SEGURIDAD
                    width: double.infinity,
                    child: TextButton.icon(
                        style: ButtonStyle(
                            overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                            padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                            alignment: Alignment.centerLeft 
                        ),
                        onPressed: (){
                          sincronizarProvider.descargarDatosLocales();
                        }, 
                        icon: const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/copia.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Copia de seguridad', style: TextStyle( color: Colors.black, fontSize: 20.0, fontWeight: FontWeight.w300 ),)
                  
                      ),
                  ),

                SizedBox(//BOTON DE SINCRONIZAR
                  width: double.infinity,
                    child: TextButton.icon(
                       style: ButtonStyle(
                          overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                          padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                          alignment: Alignment.centerLeft 
                        ),
                        onPressed: ()async{
                          var respuesta = await sincronizarProvider.importarLosDatos();

                          if(respuesta == 1){//error al importar
                            alerta(context, "Error al importar", false);
                          }else if(respuesta == 2){//error al borrar las tablas
                            alerta(context, "Se produjo un error al momento de borrar las tablas por favor llamar al administrador.", false);
                          }else if(respuesta == 3){//error al subir los datos
                            alerta(context, "Error al subir los datos.", false);
                          }else if(respuesta == 4){// error al borrar o al importar los datos
                            alerta(context, "Error al borrar o al importar los datos.", false);
                          }else if(respuesta == 5){//error al subir datos
                            alerta(context, "Error al subir datos.", false);
                          }else if(respuesta == 6){//error, no existe ningun documento
                            alerta(context, "Error, no existe ningun documento del usuario.", false);
                          }else if(respuesta == 7){//no existe conexion con datasseqv2
                            alerta(context, "Error, no existe conexion con datasseqv2.", false);
                          }else if(respuesta == 8){//definitivament no existe conexion con datasseqv2
                            alerta(context, "Error, definitivament no existe conexion con datasseqv2.", false);
                          }else{//todo funcionando
                            alerta(context, "Sincronizado completo", true);                
                          }
                        }, 
                        icon: sincronizarProvider.loadingPeticion == true ? 
                        Container(
                          padding: const EdgeInsets.all(1),
                          width: 20,
                          height: 20,
                          child: const CircularProgressIndicator(
                            color: Colors.amber,
                            strokeWidth: 3,
                          )
                        ) : const Image(
                                width: 15,
                                image: AssetImage("lib/app_gestion_combustible/sources/home/sincronizar.png"),
                                fit: BoxFit.cover,
                                ), 
                        label: const Text('Sincronizar', style: TextStyle( color: Colors.black, fontSize: 20.0,fontWeight: FontWeight.w300 ),)
                
                      ),
                  ),

                SizedBox(//BOTON DE SALIR
                  width: double.infinity,
                   child: TextButton.icon(
                    style: ButtonStyle(
                      overlayColor: MaterialStateProperty.all(Color.fromARGB(255, 255, 238, 238)),
                      padding: MaterialStateProperty.all(EdgeInsets.only(left: 50)),
                      alignment: Alignment.centerLeft 
                    ),
                      onPressed: (){
                        Navigator.of(context).pushNamedAndRemoveUntil('Login', (Route<dynamic> route) => false);
                      }, 
                      icon: const Image(
                              width: 15,
                              image: AssetImage("lib/app_gestion_combustible/sources/salir_app/salir.png"),
                              fit: BoxFit.cover,
                              ), 
                      label: const Text('Salir', style: TextStyle( color: Colors.black, fontSize: 20.0 , fontWeight: FontWeight.w300),)
                 
                      ),
                 ),
              ],
            ),            
          ],
        ),
      );
  }

  //alerta para salir
  Widget alertaSalir (BuildContext context){
    return AlertDialog(
              //title: const Text('¿ Desea salir de la aplicación ?', textAlign: TextAlign.center,),
              actionsAlignment: MainAxisAlignment.center,
              content: Container(
                height: 100,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset('lib/app_gestion_combustible/sources/salir_app/question.png', height: 60),
                      SizedBox(height: 20),
                      const Text(
                        '¿ Desea cerrar sesión ?', 
                        textAlign: TextAlign.center, 
                        style: TextStyle( color: Colors.black54 )
                      ),
                    ],
                  ),
              ),
              actions: [
                TextButton(
                  style: const ButtonStyle( 
                    backgroundColor: MaterialStatePropertyAll<Color>(Color.fromARGB(255, 243, 121, 21)),
                  ),
                  onPressed: () {
                    //Navigator.pop(context, true);
                    Navigator.of(context).pushNamedAndRemoveUntil('Login', (Route<dynamic> route) => false);
                  },
                  child: const Text('SI', style: TextStyle( color: Colors.white )),
                ),
              ],
            );
  }

  //widget de alertas
  Future alerta(BuildContext context, String mensaje, bool resultado){
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          actionsAlignment: MainAxisAlignment.center,
          content: Container(
            height: 120,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset( resultado ? 'lib/app_gestion_combustible/sources/ok_app/ok.png' : 'lib/app_gestion_combustible/sources/error_app/error.png', height: 60),
                const SizedBox(height: 20),
                Text( mensaje.toString()  ,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: const ButtonStyle(
                backgroundColor: MaterialStatePropertyAll<Color>(
                    Color.fromARGB(255, 243, 121, 21)),
              ),
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SI', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

}

