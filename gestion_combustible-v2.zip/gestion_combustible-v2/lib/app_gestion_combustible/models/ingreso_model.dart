class IngresoModel {

  late String fecha;
  late String puntoTanqueo;
  late String proveedor;
  late double volumen;
  late int numFactura;
  late int numGuia;
  late String nombreConductor;
  late String placa;
  late String observacion;

  IngresoModel({fecha, puntoTanqueo, proveedor, volumen, numFactura, numGuia, nombreConductor, placa, observacion} );

  Map<String , dynamic> datos(){
    return {
      "fecha":fecha,
      "punto_tanqueo" :puntoTanqueo,
      "proveedor" : proveedor,
      "volumen" : volumen,
      "num_factura" : numFactura,
      "num_guia" : numGuia,
      "nombre_conductor" : nombreConductor,
      "placa" : placa,
      "observaciones": observacion,
    };
  }

}