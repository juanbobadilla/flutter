import 'dart:convert';

import 'package:sqflite/sqflite.dart';
//import 'package:com_gestioncombustible_app/models/ingreso_model.dart';
import 'package:path/path.dart';
import 'package:intl/intl.dart';
import 'dart:developer' as developer;

class DB {

  /*
   * @crearTablaActivo
   * @funcionalidad Se encarga de crear la base de datos y la tabla activo
   */
  static Future<Database> crearTabla() async{
    return openDatabase(join( await getDatabasesPath(), 'datasseq2v.db'),
      onCreate:(db, version) {
        db.execute(
          '''
          CREATE TABLE IF NOT EXISTS fechaSincronizado(
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, 
            fecha TEXT NULL
            );
          '''
        );
        db.execute(
          'CREATE TABLE IF NOT EXISTS activo(id INTEGER NOT NULL, clasificacion TEXT NOT NULL, categoria TEXT NOT NULL, placa TEXT NOT NULL);'
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS informacionActivo(
              id                INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              idInformacion     INTEGER,
              sello_actual      TEXT,
              horometro_actual  TEXT,
              kilometro_actual  TEXT,
              estadoHorometro   INTEGER,
              estadoOdometro    INTEGER,
              id_activo         INTEGER,
              foreign key(id_activo) references activo(id)
               )  ;
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS conductores(
              id INTEGER NOT NULL, 
              name TEXT NOT NULL, 
              numero_identificacion TEXT NOT NULL
              );
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS proveedores(
              id    INTEGER PRIMARY KEY NOT NULL, 
              name  TEXT NOT NULL, 
              numero_identificacion TEXT NOT NULL,
              tipo_persona_id_codigo TEXT NOT NULL
              );
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS puntoTanqueo(
              id            INTEGER PRIMARY KEY NOT NULL,
              nombre        TEXT NOT NULL,
              ficha_tecnica TEXT,
              created_at    TEXT,
              updated_at    TEXT,
              tipo_tanque   TEXT,
              name          TEXT,
              fechaUltimaCalibracion TEXT
               )  ;
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS informacionPuntoTanqueo(
              id                INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              id_punto_tanqueo  INTEGER,
              municipio         TEXT,
              tipo_combustible  TEXT,
              total_ingreso     TEXT,
              total_egreso      TEXT,
              stock             REAL,
              foreign key(id_punto_tanqueo) references puntoTanqueo(id)
               )  ;
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS proyectosPuntoTanqueo(
              id                    INTEGER,
              id_punto_tanqueo      INTEGER,
              proyecto_id           INTEGER,
              proyecto_nombre       TEXT,
              foreign key(id_punto_tanqueo) references puntoTanqueo(id)
               )  ;
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS frente(
              id                    INTEGER PRIMARY KEY NOT NULL,
              proyecto_id           INTEGER,
              nombre                TEXT NULL,
              estado                INTEGER NULL,
              frente_principal      INTEGER NULL,
              foreign key(proyecto_id) references proyectosPuntoTanqueo(id)
               );
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS ingresos(
              id            INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              fecha         TEXT NULL,
              fechaFiltro   TEXT NULL,
              consecutivo   TEXT NULL,
              punto_tanqueo_id      TEXT NULL,
              punto_tanqueo_texto   TEXT NULL,
              proveedor_id      TEXT NULL,
              proveedor_texto   TEXT NULL,
              volumen   TEXT NULL,
              factura   TEXT NULL,
              guia      TEXT NULL,
              conductor TEXT NULL,
              placa     TEXT NULL,
              observacion     TEXT NULL,
              tecnico_id      TEXT NULL,
              tecnico_texto   TEXT NULL,
              usuario_registra_id     TEXT NULL,
              usuario_registra_texto  TEXT NULL,
              tipo_registro_id TEXT NULL,
              tipo_ingreso_egreso_texto TEXT NULL,
              proyecto_id TEXT NULL,
              tanque_proyecto_id TEXT NULL,
              proyecto_texto TEXT NULL,
              frente_id TEXT NULL,
              frente_texto TEXT NULL,
              activo_id TEXT NULL,
              activo_texto TEXT NULL,
              conductor_egreso_id TEXT NULL,
              conductor_egreso_texto TEXT NULL,
              tanque_full TEXT NULL,
              numero_contador TEXT NULL,
              inicio_operar TEXT NULL,
              sello TEXT NULL,
              horometro TEXT NULL,
              kilometraje TEXT NULL,
              adjunto BLOB NULL,
              nombreArchivo TEXT NULL,
              extension TEXT NULL,
              tipo_combustible_texto TEXT NULL,
              galones_texto TEXT NULL,
              estado_id TEXT NULL,
              estado_texto TEXT NULL
               )  ;
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS sesiones(
              id                 INTEGER NOT NULL,
              nombreUsuario      TEXT NULL,
              documento          TEXT NULL,
              tipoDocumento      TEXT NULL,
              cargo              TEXT NULL,
              token              TEXT NULL,
              permisosComponente TEXT NULL,
              permisosSubComponente TEXT NULL
               )  ;
          '''
        );
        db.execute(
          '''
            CREATE TABLE IF NOT EXISTS documentoSesion(
              id                    INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              documento             INTEGER
               );
          '''
        );
      }, version: 1 );
  }

    /*
   *@method insertarDocumentoSesion
   *@funcionalidad Se encarga de insertar el documento de sesion
   */
  static Future<void> insertarDocumentoSesion(documento)async{

    Database database = await crearTabla();

    try {

      await database.rawInsert(
      '''INSERT INTO documentoSesion
      (
        documento
        )
        VALUES
        (
          '$documento'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: obtenerDocumentoSesion
   *@funcionalidad: Se encarga de traer el utlimo docuemnto que inicio sesion.
   */
  static Future<List<Map<String, Object?>>> obtenerDocumentoSesion()async{
    Database database = await crearTabla();
    return await database.rawQuery("SELECT * FROM documentoSesion");
    //return await database.rawQuery("SELECT * FROM documentoSesion ORDER BY id DESC LIMIT 1");
  }


  /*
   *@method insertarDatosFechasSincronizada
   *@funcionalidad Se encarga de insertar las fechas a la tabla
   */
  static Future<void> insertarDatosFechas(fecha)async{

    Database database = await crearTabla();

    try {

      await database.rawInsert(
      '''INSERT INTO fechaSincronizado
      (
        fecha
        )
        VALUES
        (
          '$fecha'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: obtenerFechasSincronizado
   *@funcionalidad: Se encarga de traer la ultima fecha de sincronizado.
   */
  static Future<List<Map<String, Object?>>> obtenerFechas()async{
    Database database = await crearTabla();
    return await database.rawQuery("SELECT fechaSincronizado.fecha FROM fechaSincronizado ORDER BY id DESC LIMIT 1");
  }

  /*
   *@method insertarDatosIngresos
   *@funcionalidad Se encarga de insertar los datos a la tabla ingresos
   */
  static Future<bool> insertarDatosIngresosEgresos(
      fecha,
      fechaFiltro,
      consecutivo,
      punto_tanqueo_id,
      punto_tanqueo_texto,
      proveedor_id,
      proveedor_texto,
      volumen,
      factura,
      guia,
      conductor,
      placa,
      observacion,
      tecnico_id,
      tecnico_texto,
      usuario_registra_id,
      usuario_registra_texto,
      tipo_registro_id,
      tipo_ingreso_egreso_texto ,
      proyecto_id,
      tanque_proyecto_id,
      proyecto_texto ,
      frente_id,
      frente_texto,
      activo_id,
      activo_texto ,
      conductor_egreso_id,
      conductor_egreso_texto ,
      tanque_full,
      numero_contador ,
      inicio_operar,
      sello ,
      horometro ,
      kilometraje,
      adjunto,
      nombreArchivo,
      extension,
      tipo_combustible,
      galones,
      estado_id,
      estado_texto
    )async{

    Database database = await crearTabla();

    try {

      //await database.delete("ingresos");

      await database.rawInsert(
      '''INSERT INTO ingresos
      (
        fecha,
        fechaFiltro,
        consecutivo,
        punto_tanqueo_id,
        punto_tanqueo_texto,
        proveedor_id,
        proveedor_texto,
        volumen,
        factura,
        guia,
        conductor,
        placa,
        observacion,
        tecnico_id,
        tecnico_texto,
        usuario_registra_id,
        usuario_registra_texto,
        tipo_registro_id,
        tipo_ingreso_egreso_texto ,
        proyecto_id,
        tanque_proyecto_id,
        proyecto_texto ,
        frente_id,
        frente_texto,
        activo_id,
        activo_texto ,
        conductor_egreso_id,
        conductor_egreso_texto ,
        tanque_full,
        numero_contador ,
        inicio_operar,
        sello ,
        horometro ,
        kilometraje,
        adjunto,
        nombreArchivo,
        extension,
        tipo_combustible_texto,
        galones_texto,
        estado_id,
        estado_texto
        )
        VALUES
        (
          '$fecha',
          '$fechaFiltro',
          '${consecutivo}',
          '$punto_tanqueo_id',
          '${punto_tanqueo_texto.toUpperCase().trim()}',
          '$proveedor_id',
          '${proveedor_texto.toUpperCase().trim()}',
          '$volumen',
          '${factura.toUpperCase().trim()}',
          '${guia.toUpperCase().trim()}',
          '${conductor.toUpperCase().trim()}',
          '${placa.toUpperCase().trim()}',
          '${observacion.toUpperCase().trim()}',
          '$tecnico_id',
          '${tecnico_texto.toUpperCase().trim()}',
          '$usuario_registra_id',
          '${usuario_registra_texto.toUpperCase().trim()}',
          '$tipo_registro_id',
          '${tipo_ingreso_egreso_texto.toUpperCase().trim()}' ,
          '${proyecto_id}',
          '${tanque_proyecto_id}',
          '${proyecto_texto.toUpperCase().trim()}' ,
          '$frente_id',
          '${frente_texto.toUpperCase().trim()}' ,
          '${activo_id}',
          '${activo_texto.toUpperCase().trim()}' ,
          '${conductor_egreso_id}',
          '${conductor_egreso_texto.toUpperCase().trim()}' ,
          '${tanque_full}',
          '${numero_contador}' ,
          '${inicio_operar}',
          '${sello.toUpperCase().trim()}' ,
          '${horometro}' ,
          '${kilometraje}',
          '${adjunto.trim()}',
          '${nombreArchivo.toUpperCase().trim()}',
          '${extension.trim()}',
          '${tipo_combustible.toUpperCase().trim()}',
          '${galones.toUpperCase().trim()}',
          '${estado_id.toUpperCase().trim()}',
          '${estado_texto.toUpperCase().trim()}'
          )
          ''');
        return true;
    } catch (e) {
      print(e.toString());
      return false;
    }
  }


  /*
   *@method: mostrarTodosIngresos
   *@funcionalidad: Se encarga de traer todos los ingresos de la base de datos.
   */
  static Future<List<Map<String, Object?>>> mostrarTodosIngresos( fechaIncial, fechaFinal, puntoTanqueoId, activoId )async{
    Database database = await crearTabla();

    var fechaInicialFormateada  = fechaIncial.toString().substring(0,10);
    var fechaFinalFormateada    = fechaFinal.toString().substring(0,10);

    if(fechaInicialFormateada != null && fechaFinalFormateada != null && puntoTanqueoId != null && activoId != null){
      return await database.rawQuery(
        '''
        SELECT * 
        FROM 
          ingresos
        WHERE ingresos.fechaFiltro BETWEEN '${fechaInicialFormateada.toString()}' AND '${fechaFinalFormateada.toString()}'
        AND ingresos.punto_tanqueo_id = '${puntoTanqueoId.toString()}'
        AND ingresos.activo_id = '${activoId.toString()}'
        ORDER BY id DESC; 
        '''
      );
    }else if(fechaInicialFormateada != null && fechaFinalFormateada != null && puntoTanqueoId != null){
      return await database.rawQuery(
        '''
        SELECT * 
        FROM 
          ingresos
        WHERE ingresos.fechaFiltro BETWEEN '${fechaInicialFormateada.toString()}' AND '${fechaFinalFormateada.toString()}'
        AND ingresos.punto_tanqueo_id = '${puntoTanqueoId.toString()}'
        ORDER BY id DESC; 
        '''
      );
    }else if(fechaInicialFormateada != null && fechaFinalFormateada != null && activoId != null){
      return await database.rawQuery(
        '''
        SELECT * 
        FROM 
          ingresos
        WHERE ingresos.fechaFiltro BETWEEN '${fechaInicialFormateada.toString()}' AND '${fechaFinalFormateada.toString()}'
        AND ingresos.activo_id = '${activoId.toString()}'
        ORDER BY id DESC; 
        '''
      );
    }
    else {
      return await database.rawQuery(
        '''
        SELECT * 
        FROM 
          ingresos
        WHERE ingresos.fechaFiltro BETWEEN '${fechaInicialFormateada.toString()}' AND '${fechaFinalFormateada.toString()}' 
        ORDER BY id DESC ; 
        '''
      );
    }
  }

  /*
   *@method: obtenerConsecutivoIngreso
   *@funcionalidad: Se encarga de traer el ultimo registro del consecutivo.
   */
  static Future<List<Map<String, Object?>>> obtenerConsecutivoIngreso()async{
    Database database = await crearTabla();
    return await database.rawQuery(
      '''
      SELECT 
        ingresos.consecutivo 
      FROM 
        ingresos 
      WHERE
        tipo_ingreso_egreso_texto = 'INGRESO'
      ORDER BY 
        consecutivo DESC LIMIT 1;
      ''');
  }

  
  /*
   *@method insertarDatosActivos
   *@funcionalidad Se necarga de insertar datos a la tabla de activos
   */
  static Future<void> insertarDatosActivos(id, clasificacion, categoria, placa)async{

    Database database = await crearTabla();

    try {

      await database.delete("activo");

      await database.rawInsert(
      '''INSERT INTO activo
      (
        id,
        clasificacion,
        categoria,
        placa
        )
        VALUES
        (
          '$id',
          '${clasificacion.toUpperCase().trim()}',
          '${categoria.toUpperCase().trim()}',
          '${placa.toUpperCase().trim()}'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: mostrarTodosActivos
   *@funcionalidad: Se encarga de traer todos los activos de la base de datos.
   */
  static Future<List<Map<String, Object?>>> mostrarTodosActivos()async{
    Database database = await crearTabla();
    return await database.rawQuery("SELECT * FROM activo ORDER BY clasificacion ASC");
  }

  /*
   *@method insertarDatosInformacionActivo
   *@funcionalidad Se encarga de insertar datos a la tabla de informacion de activos
   */
  static Future<void> insertarDatosInformacionActivo(
    id,
    sello_actual,
    horometro_actual,
    kilometro_actual,
    estadoHorometro,
    estadoOdometro,
    idActivo
    )async{

    Database database = await crearTabla();

    try {

      await database.delete("informacionActivo");

      await database.rawInsert(
      '''INSERT INTO informacionActivo
      (
        idInformacion,
        sello_actual,
        horometro_actual,
        kilometro_actual,
        estadoHorometro,
        estadoOdometro,
        id_activo
        )
        VALUES
        (
          '$id',
          '$sello_actual',
          '$horometro_actual',
          '$kilometro_actual',
          '$estadoHorometro',
          '$estadoOdometro',
          '$idActivo'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }


  /*
   *@method: mostrarSelloHoromotroKilometrajeAnterior
   *@funcionalidad: Se encarga de traer los sellos, horometro y kilometraje anterior del activo.
   */
  static Future<List<Map<String, Object?>>> mostrarSelloHoromotroKilometrajeAnterior(idActivo)async{
    Database database = await crearTabla();
    return await database.rawQuery(
      '''
      SELECT 
        informacionActivo.sello_actual, 
        informacionActivo.horometro_actual,
        informacionActivo.kilometro_actual,
        informacionActivo.estadoHorometro,
        informacionActivo.estadoOdometro
      FROM 
        informacionActivo  
      INNER JOIN 
        activo ON activo.id = informacionActivo.id_activo 
      WHERE 
        activo.id = $idActivo ;
      '''
    );
  }


  /*
   *@method insertarDatosConductores
   *@funcionalidad Se necarga de insertar datos a la tabla de conductores
   */
  static Future<void> insertarDatosConductores(id, name, numeroIdentificacion)async{

    Database database = await crearTabla();

    try {
      await database.delete("conductores");

      await database.rawInsert(
      '''INSERT INTO conductores
      (
        id,
        name,
        numero_identificacion
        )
        VALUES
        (
          '$id',
          '${name.toUpperCase().trim()}',
          '${numeroIdentificacion.toUpperCase().trim()}'
          )
          ''');
    } catch (e) {
      print(e.toString());
      developer.log((e).toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: mostrarTodosConductores
   *@funcionalidad: Se encarga de traer todos los conductores.
   */
  static Future<List<Map<String, Object?>>> mostrarTodosConductores()async{
    Database database = await crearTabla();
    var data = await database.rawQuery("SELECT * FROM conductores ORDER BY name ASC");
    var valoresRepetidos = await database.rawQuery("SELECT * FROM conductores GROUP BY id HAVING COUNT(*)>1");//extraigo todos los datos repetidos
    
    List<Map<String, Object?>> array = [];

    if(valoresRepetidos.isEmpty){
      array = data;
    }else{

      for (var i = 0; i < data.length; i++) {
        for (var f = 0; f < valoresRepetidos.length; f++) {
            if(data[i]["id"] != valoresRepetidos[f]["id"]){
              array.add(data[i]);
          }
        }
      }

      for (var i = 0; i < valoresRepetidos.length; i++) {
        array.add(valoresRepetidos[i]);
      }

    }
    
    return array;
  }

  /*
   *@method insertarDatosProveedores
   *@funcionalidad Se necarga de insertar datos a la tabla de proveedores
   */
  static Future<void> insertarDatosProveedores(id, name, numeroIdentificacion, tipo_persona_id_codigo)async{

    Database database = await crearTabla();

    try {
      await database.delete("proveedores");

      await database.rawInsert(
      '''INSERT INTO proveedores
      (
        id,
        name,
        numero_identificacion,
        tipo_persona_id_codigo
        )
        VALUES
        (
          '$id',
          '${name.toUpperCase().trim()}',
          '${numeroIdentificacion.toUpperCase().trim()}',
          '${tipo_persona_id_codigo.toUpperCase().trim()}'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: mostrarTodosProveedores
   *@funcionalidad: Se encarga de traer todos los proveedores.
   */
  static Future<List<Map<String, Object?>>> mostrarTodosProveedores()async{
    Database database = await crearTabla();
    return await database.rawQuery("SELECT * FROM proveedores ORDER BY name ASC");
  }

  /*
   *@method insertarDatosPuntoTanqueo
   *@funcionalidad Se necarga de insertar datos a la tabla de punto de tanqueo
   */
  static Future<void> insertarDatosPuntoTanqueo(
    id,
    nombre,
    ficha_tecnica,
    created_at,
    updated_at,
    tipo_tanque,
    name,
    fechaUltimaCalibracion
    )async{

    Database database = await crearTabla();

    try {
      //await database.delete("puntoTanqueo");

      await database.rawInsert(
      '''INSERT INTO puntoTanqueo
      (
        id,
        nombre,
        ficha_tecnica,
        created_at,
        updated_at,
        tipo_tanque,
        name,
        fechaUltimaCalibracion
        )
        VALUES
        (
          '$id',
          '${nombre.toUpperCase().trim()}',
          '${ficha_tecnica.toUpperCase().trim()}',
          '${created_at.toUpperCase().trim()}',
          '${updated_at.toUpperCase().trim()}',
          '${tipo_tanque.toUpperCase().trim()}',
          '${name.toUpperCase().trim()}',
          '$fechaUltimaCalibracion'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<List<Map<String, Object?>>> mostrarTodosPuntosTanqueo()async{
    Database database = await crearTabla();
    return await database.rawQuery("SELECT * FROM puntoTanqueo ORDER BY nombre ASC");
  }

  /*
   *@method insertarDatosInformacionPuntoTanqueo
   *@funcionalidad Se necarga de insertar datos a la tabla de informacionPuntosTanqueo
   */
  static Future<bool> insertarDatosInformacionPuntoTanqueo(
    id_punto_tanqueo,
    municipio,
    tipo_combustible,
    total_ingreso,
    total_egreso,
    stock
    )async{

    Database database = await crearTabla();

    try {
      //await database.delete("informacionPuntoTanqueo");

      await database.rawInsert(
      '''INSERT INTO informacionPuntoTanqueo
      (
        id_punto_tanqueo,
        municipio,
        tipo_combustible,
        total_ingreso,
        total_egreso,
        stock
        )
        VALUES
        (
          '$id_punto_tanqueo',
          '${municipio.toUpperCase().trim()}',
          '${tipo_combustible.toUpperCase().trim()}',
          '${total_ingreso.toUpperCase().trim()}',
          '${total_egreso.toUpperCase().trim()}',
          '$stock'
          )
          ''');
      return true;
    } catch (e) {
      print(e.toString());
      return false;
    }
  }


    /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<List<Map<String, Object?>>> mostrarTodosInformacionPorPuntosTanqueo(idPuntoTanqueo)async{
    Database database = await crearTabla();
    return await database.rawQuery(
      '''
      SELECT 
        informacionPuntoTanqueo.municipio, 
        informacionPuntoTanqueo.stock,
        informacionPuntoTanqueo.tipo_combustible
      FROM 
        informacionPuntoTanqueo  
      INNER JOIN 
        puntoTanqueo ON puntoTanqueo.id = informacionPuntoTanqueo.id_punto_tanqueo 
      WHERE 
        puntoTanqueo.id = $idPuntoTanqueo 
      ORDER BY informacionPuntoTanqueo.id DESC LIMIT 1;
      '''
    );
  }

  /*
   *@method: mostrarStockPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los stock de los puntos de tanqueo de la base de datos.
   */
  static Future<List<Map<String, Object?>>> mostrarStockPuntosTanqueo()async{
    Database database = await crearTabla();
    return await database.rawQuery(
      '''
      SELECT 
        puntoTanqueo.nombre, 
        informacionPuntoTanqueo.stock,
        informacionPuntoTanqueo.tipo_combustible
      FROM 
        puntoTanqueo  
      INNER JOIN 
        informacionPuntoTanqueo ON informacionPuntoTanqueo.id_punto_tanqueo = puntoTanqueo.id ;
      '''
    );
  }


  /*
   *@method: mostrarTodosIngresos
   *@funcionalidad: Se encarga de traer todos los ingresos de la base de datos.
   */
  static Future<List<Map<String, Object?>>> sumarEgresos(id_punto_tanqueo_egreso)async{
    Database database = await crearTabla();
    return await database.rawQuery(
        '''
          SELECT SUM(ingresos.volumen) FROM ingresos WHERE ingresos.punto_tanqueo_id = ${id_punto_tanqueo_egreso} 
          AND ingresos.tipo_ingreso_egreso_texto = 'EGRESO'
        ''');
  }


  /*
   *@method insertarDatosPuntoTanqueo
   *@funcionalidad Se necarga de insertar datos a la tabla de punto de tanqueo
   */
  static Future<void> insertarDatosProyectosPuntoTanqueo( 
    id,
    id_punto_tanqueo,
    proyecto_id,
    proyecto_nombre
    )async{

    Database database = await crearTabla();

    try {
      //await database.delete("proyectosPuntoTanqueo");

      await database.rawInsert(
      '''INSERT INTO proyectosPuntoTanqueo
      (
        id,
        id_punto_tanqueo,
        proyecto_id,
        proyecto_nombre
        )
        VALUES
        (
          '$id',
          '$id_punto_tanqueo',
          '$proyecto_id',
          '${proyecto_nombre.toUpperCase().trim()}'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

    /*
   *@method insertarDatosFrentes
   *@funcionalidad Se encarga de insertar datos a la tabla de frentes
   */
  static Future<void> insertarDatosFrentes( 
    id,
    proyecto_id,
    nombre,
    estado,
    frente_principal,
    )async{

    Database database = await crearTabla();

    try {

      await database.rawInsert(
      '''INSERT INTO frente
      (
        id,
        proyecto_id,
        nombre,
        estado,
        frente_principal
        )
        VALUES
        (
          '$id',
          '$proyecto_id',
          '${nombre.toUpperCase().trim()}',
          '$estado',
          '$frente_principal'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<List<Map<String, Object?>>> mostrarTodosProyectoPorPuntosTanqueo(idPuntoTanqueo)async{
    Database database = await crearTabla();
    return await database.rawQuery(
      
      '''
      SELECT 
        proyectosPuntoTanqueo.id,
        proyectosPuntoTanqueo.proyecto_id,
        proyectosPuntoTanqueo.proyecto_nombre 
      FROM 
        puntoTanqueo 
      INNER JOIN 
        proyectosPuntoTanqueo ON proyectosPuntoTanqueo.id_punto_tanqueo = puntoTanqueo.id 
      WHERE 
        puntoTanqueo.id = $idPuntoTanqueo ORDER BY proyectosPuntoTanqueo.proyecto_nombre ASC ;
      '''
    );
  }

    /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<List<Map<String, Object?>>> mostrarFrentesPorProyecto(idPuntoTanqueo)async{
    Database database = await crearTabla();
    return await database.rawQuery(
      '''
      SELECT 
        frente.id, 
        frente.nombre 
      FROM 
        frente 
      INNER JOIN 
        proyectosPuntoTanqueo ON proyectosPuntoTanqueo.id = frente.proyecto_id
      WHERE 
        proyectosPuntoTanqueo.id = ${idPuntoTanqueo} 
      AND
        frente.frente_principal = 1;
      '''
    );
  }

  /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<List> galonesSaliente()async{
    Database database = await crearTabla();

    var puntoTanqueo = await database.rawQuery(
      '''
        SELECT 
        pt.id,
        pt.nombre,
        ift.id_punto_tanqueo,
        ift.stock,
        pt.fechaUltimaCalibracion
      FROM 
        informacionPuntoTanqueo ift
      INNER JOIN 
      (
        SELECT puntoTanqueo.id, puntoTanqueo.nombre, puntoTanqueo.fechaUltimaCalibracion FROM puntoTanqueo GROUP BY puntoTanqueo.id
      ) pt ON ift.id_punto_tanqueo = pt.id GROUP BY ift.id_punto_tanqueo ORDER BY pt.nombre ASC;
      '''
    );

    //print(puntoTanqueo);
    
    var ingresosEgresos = await database.rawQuery(
      '''SELECT 
          ingresos.punto_tanqueo_id, 
          ingresos.punto_tanqueo_texto,
          ingresos.volumen, 
          ingresos.tipo_registro_id, 
          ingresos.tipo_ingreso_egreso_texto 
        from 
          ingresos
        WHERE ingresos.tipo_ingreso_egreso_texto = 'EGRESO' ORDER BY ingresos.punto_tanqueo_texto ASC ;
      ''');

    //print(ingresosEgresos);

    if(ingresosEgresos.isEmpty || puntoTanqueo.isEmpty ){
      List valor = [];

      for (var i = 0; i < puntoTanqueo.length; i++) {
        valor.add(
          {
            "nombre":"${puntoTanqueo[i]["nombre"]}",
            "galonesSalientes":'',
            "stockDisponible": double.parse(puntoTanqueo[i]["stock"].toString()).toStringAsFixed(2),
            "fechaUltimaCalibracion" : "${puntoTanqueo[i]["fechaUltimaCalibracion"]}"
          }
        );
      }

      return valor;
      
    }else{

      List valor = [];

      for (var i = 0; i < puntoTanqueo.length; i++) {
        double resultado = 0.0;

        valor.add(
          {
            "nombre":'',
            "galonesSalientes":'',
            "stockDisponible":'',
            "fechaUltimaCalibracion":''
          }
        );

        for (var f = 0; f < ingresosEgresos.length; f++) {
        
          if(puntoTanqueo[i]["id"].toString() == ingresosEgresos[f]["punto_tanqueo_id"].toString()){
              resultado = resultado + double.parse(ingresosEgresos[f]["volumen"].toString());
              
              valor[i]["nombre"] = ingresosEgresos[f]["punto_tanqueo_texto"].toString().substring(1).trim();
              valor[i]["galonesSalientes"] = resultado.toString();
              valor[i]["stockDisponible"] = double.parse(puntoTanqueo[i]["stock"].toString()).toStringAsFixed(2);
              valor[i]["fechaUltimaCalibracion"] =  puntoTanqueo[i]["fechaUltimaCalibracion"].toString();
          }else{
        
              valor[i]["nombre"] = puntoTanqueo[i]["nombre"].toString();
              valor[i]["galonesSalientes"] = resultado.toString();
              valor[i]["stockDisponible"] = double.parse(puntoTanqueo[i]["stock"].toString()).toStringAsFixed(2);
              valor[i]["fechaUltimaCalibracion"] =  puntoTanqueo[i]["fechaUltimaCalibracion"].toString();
          }
        }
      }
      return valor;
    }  
  }


  /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<List<Map<String, Object?>>> listarTodaTablaIngresos()async{
    Database database = await crearTabla();
    return await database.rawQuery(
      '''
      SELECT 
        *
      FROM 
        ingresos ;
      '''
    );
  }

  /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<List<Map<String, Object?>>> listarTodaTablaIngresosLocal()async{
    Database database = await crearTabla();
    return await database.rawQuery(
      '''
      SELECT 
        *
      FROM 
        ingresos WHERE estado_texto = 'LOCAL' ;
      '''
    );
  }

  /*
   *@method: mostrarTodosPuntosTanqueo
   *@funcionalidad: Se encarga de traer todos los puntos de tanqueo de la base de datos.
   */
  static Future<void> cambiarEstadoLocalASincronizado(datos)async{
  
    Database database = await crearTabla();

    if (datos["ingresos"].isNotEmpty) {
      for (var i = 0; i < datos["ingresos"].length; i++) {
        await database.rawQuery(
          '''
          UPDATE 
            ingresos
          SET
            estado_id = '1', 
            estado_texto = 'SERVIDOR'
          WHERE ingresos.id = ${datos["ingresos"][i]["id"]};
          '''
        );
      }
    }
    
    if(datos["egresos"].isNotEmpty){
      for (var i = 0; i < datos["egresos"].length; i++) {
        await database.rawQuery(
          '''
          UPDATE 
            ingresos
          SET
            estado_id = '1',
            estado_texto = 'SERVIDOR'
          WHERE ingresos.id = ${datos["egresos"][i]["id"]};
          '''
        );
      }
    }


  } 


  /*
   *@method insertarDatoSesionUsuario
   *@funcionalidad Se encarga de insertar datos a la tabla que guarda las sessiones del usuario
   */
  static Future<void> insertarDatoSesionUsuario(
    id,
    nombreUsuario,
    documento,
    tipoDocumento,
    cargo,
    token,
    permisosComponente,
    permisosSubComponente
    )async{

    Database database = await crearTabla();

    try {

      await database.rawInsert(
      '''INSERT INTO sesiones
      (
        id,
        nombreUsuario,
        documento,
        tipoDocumento,
        cargo,
        token,
        permisosComponente,
        permisosSubComponente
        )
        VALUES
        (
          '$id',
          '$nombreUsuario',
          '$documento',
          '$tipoDocumento',
          '$cargo',
          '$token',
          '$permisosComponente',
          '$permisosSubComponente'
          )
          ''');
    } catch (e) {
      print(e.toString());
      throw Exception('Falla en la consulta');
    }
  }

  /*
   *@method: obtenerSesionUsuario
   *@funcionalidad: Se encarga de traer la ultima sesion del usuario.
   */
  static Future<List<Map<String, Object?>>> obtenerSesionUsuario(documento)async{
    Database database = await crearTabla();
    //return await database.rawQuery("SELECT * FROM sesiones where documento = (SELECT MAX(${documento}) from sesiones)");
    return await database.rawQuery("SELECT * FROM sesiones  where documento = ${documento} ORDER BY id DESC LIMIT 1");
  }

  /*
   *@method: cerrarConexion
   *@funcionalidad: Se encarga de cerrar la conexion a la base de datos
   */
  Future<void> cerrarConexion()async{
    /* Database database = await openDB(); 
    database.close(); */
  }

  // Delete the database
  static Future<void> borrarBaseDatos()async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'prueba.db');
    await deleteDatabase(path);
  }

  // Delete the database
  static Future<bool> borrarTablas()async {
    Database database = await crearTabla();
    await database.delete('fechaSincronizado');
    await database.delete('activo');
    await database.delete('informacionActivo');
    await database.delete('conductores');
    await database.delete('proveedores');
    await database.delete('puntoTanqueo');
    await database.delete('informacionPuntoTanqueo');
    await database.delete("proyectosPuntoTanqueo");
    await database.delete("frente");
    return true;
    //await database.delete('ingresos');
  }

  //reinicia las secciones
  static Future<void> borrarSecciones(documento) async{
    Database database = await crearTabla();
    await database.rawQuery("DELETE FROM sesiones where documento <> ${documento}");
  }

  static Future<void> borrarDocumentoSesion()async{
    Database database = await crearTabla();
    await database.delete("documentoSesion");
  }


/*   void onUpgrade(db)
  {
    db.execSQL("DROP TABLE IF EXISTS" + TABLE_NAME);
    onCreate(db);
  } */

  
}